# Qyrox V4.6 - Installation Guide

## Quick Install

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run interactive setup
python setup.py

# 3. Start Qyrox
python main.py
```

## Detailed Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- Internet connection for API access

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

This will install:
- google-generativeai
- groq
- requests
- cryptography
- Other required packages

### Step 2: Interactive Setup

Run the setup wizard:

```bash
python setup.py
```

The wizard will guide you through:

#### 2.1 API Keys Configuration

Enter your API keys:
- Groq API Key (recommended)
- Google API Key (recommended)
- OpenAI API Key (optional)
- OpenRouter API Key (optional)

**How to paste API keys:**
- Windows: Use Ctrl+V or right-click and select Paste
- Mac/Linux: Use Ctrl+V or Cmd+V
- The input will be visible for easier pasting
- Press Enter to skip any key

Keys are stored securely in `api_key.txt`.

#### 2.2 Agent Configuration

- Agent Name: Default is "Qyrox"
- Primary Model: Choose from:
  1. llama-3.1-8b-instant (Groq - Fast)
  2. gemini-1.5-flash (Google - Balanced)
  3. gpt-3.5-turbo (OpenAI - Powerful)

#### 2.3 Feature Configuration

Enable/disable features:
- Multi-Agent System (recommended: yes)
- Advanced Context Management (recommended: yes)
- Request Batching (recommended: yes)
- Autonomous Mode (recommended: no for first time)

If enabling Autonomous Mode, select safety mode:
1. Safe (Require approval, 5 actions/hour)
2. Moderate (Require approval, 10 actions/hour)
3. Aggressive (Auto-execute, 20 actions/hour)

#### 2.4 Rate Limit Configuration

Set API rate limits (press Enter for defaults):
- Requests per minute: 50
- Requests per hour: 1000
- Requests per day: 10000

#### 2.5 Review and Confirm

Review your configuration and confirm to save.

Configuration is saved to `user_config.json`.

### Step 3: Start Qyrox

```bash
python main.py
```

You should see:
```
Qyrox V4.6 initialized successfully
Type /help for available commands
```

## Getting API Keys

### Groq API Key (Recommended)

1. Visit https://console.groq.com
2. Sign up for free account
3. Navigate to API Keys section
4. Create new API key
5. Copy the key

### Google API Key (Recommended)

1. Visit https://makersuite.google.com/app/apikey
2. Sign in with Google account
3. Create API key
4. Copy the key

### OpenAI API Key (Optional)

1. Visit https://platform.openai.com/api-keys
2. Sign up or log in
3. Create new secret key
4. Copy the key

### OpenRouter API Key (Optional)

1. Visit https://openrouter.ai/keys
2. Sign up or log in
3. Create API key
4. Copy the key

## Reconfiguration

To change your configuration:

```bash
python setup.py
```

This will run the setup wizard again. Your previous configuration will be overwritten.

Alternatively, edit `user_config.json` manually:

```json
{
  "agent_name": "Qyrox",
  "primary_model": "llama-3.1-8b-instant",
  "multi_agent_enabled": true,
  "context_management_enabled": true,
  "batching_enabled": true,
  "autonomous_enabled": false,
  "safety_mode": "safe",
  "rate_limits": {
    "requests_per_minute": 50,
    "requests_per_hour": 1000,
    "requests_per_day": 10000,
    "tokens_per_minute": 90000,
    "tokens_per_day": 2000000
  }
}
```

## Troubleshooting

### Issue: "No module named 'groq'"

Solution:
```bash
pip install -r requirements.txt
```

### Issue: "API key not found"

Solution:
1. Run `python setup.py` again
2. Enter your API keys
3. Ensure `api_key.txt` exists

### Issue: "Permission denied"

Solution:
```bash
# On Linux/Mac
chmod +x setup.py
chmod +x main.py

# On Windows
# Run as administrator
```

### Issue: "Configuration file not found"

Solution:
```bash
python setup.py
```

This will create `user_config.json`.

### Issue: "Rate limit exceeded"

Solution:
1. Edit `user_config.json`
2. Increase rate limits
3. Or wait for limits to reset

## Verification

After installation, verify everything works:

```bash
python main.py
```

Try these commands:
```
/help
/agents status
/context stats
/batch stats
/limiter stats
```

If all commands work, installation is successful!

## Uninstallation

To remove Qyrox:

```bash
# Remove configuration
rm user_config.json
rm api_key.txt

# Remove data
rm -rf data/

# Remove Python packages (optional)
pip uninstall -r requirements.txt
```

## Support

If you encounter issues:

1. Check this installation guide
2. Review error messages
3. Check GitHub Issues
4. Contact support@qyrox.ai

## Next Steps

After installation:

1. Read README.md for features
2. Try example commands
3. Explore multi-agent collaboration
4. Check USE_CASES.md for examples
5. Review DOCUMENTATION.md for details

---

Qyrox V4.6 - Professional AI Assistant with Interactive Setup
