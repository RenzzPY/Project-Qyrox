import os
import sys
import json
from pathlib import Path

class QyroxSetup:
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self.config_file = self.base_dir / "user_config.json"
        self.api_key_file = self.base_dir / "api_key.txt"
        
    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self):
        self.clear_screen()
        print("=" * 60)
        print("  Qyrox V4.6 - Interactive Setup Wizard")
        print("=" * 60)
        print()
    
    def get_input(self, prompt, default=None):
        if default:
            prompt = f"{prompt} [{default}]: "
        else:
            prompt = f"{prompt}: "
        
        value = input(prompt)
        return value if value else default
    
    def get_api_key(self, service_name):
        print(f"\n{service_name} API Key:")
        print("  Paste your key and press Enter (input will be visible)")
        print("  Or press Enter to skip")
        key = input("  > ").strip()
        return key if key else None
    
    def setup_api_keys(self):
        print("\n--- API Keys Configuration ---\n")
        print("You can paste your API keys using Ctrl+V or right-click paste")
        print("Keys will be visible during input for easier pasting\n")
        
        groq_key = self.get_api_key("Groq")
        google_key = self.get_api_key("Google")
        openai_key = self.get_api_key("OpenAI (optional)")
        openrouter_key = self.get_api_key("OpenRouter (optional)")
        
        keys = {}
        if groq_key:
            keys['groq'] = groq_key
        if google_key:
            keys['google'] = google_key
        if openai_key:
            keys['openai'] = openai_key
        if openrouter_key:
            keys['openrouter'] = openrouter_key
        
        if keys:
            with open(self.api_key_file, 'w') as f:
                for key, value in keys.items():
                    f.write(f'{key}: {value}\n')
            print("\n✓ API keys saved securely")
        else:
            print("\n⚠ No API keys provided. You can add them later in api_key.txt")
    
    def setup_agent_config(self):
        print("\n--- Agent Configuration ---\n")
        
        agent_name = self.get_input("Agent Name", "Qyrox")
        
        print("\nSelect Primary Model:")
        print("1. llama-3.1-8b-instant (Groq - Fast)")
        print("2. gemini-1.5-flash (Google - Balanced)")
        print("3. gpt-3.5-turbo (OpenAI - Powerful)")
        model_choice = self.get_input("Choice", "1")
        
        models = {
            "1": "llama-3.1-8b-instant",
            "2": "gemini-1.5-flash",
            "3": "gpt-3.5-turbo"
        }
        primary_model = models.get(model_choice, "llama-3.1-8b-instant")
        
        return {
            "agent_name": agent_name,
            "primary_model": primary_model
        }
    
    def setup_features(self):
        print("\n--- Feature Configuration ---\n")
        
        print("Enable Multi-Agent System? (5 specialized agents)")
        multi_agent = self.get_input("(y/n)", "y").lower() == 'y'
        
        print("\nEnable Advanced Context Management? (70% token reduction)")
        context_mgmt = self.get_input("(y/n)", "y").lower() == 'y'
        
        print("\nEnable Request Batching? (50% fewer API calls)")
        batching = self.get_input("(y/n)", "y").lower() == 'y'
        
        print("\nEnable Autonomous Mode? (Agent acts independently)")
        autonomous = self.get_input("(y/n)", "n").lower() == 'y'
        
        if autonomous:
            print("\nSelect Safety Mode:")
            print("1. Safe (Require approval, 5 actions/hour)")
            print("2. Moderate (Require approval, 10 actions/hour)")
            print("3. Aggressive (Auto-execute, 20 actions/hour)")
            safety_choice = self.get_input("Choice", "1")
            
            safety_modes = {
                "1": "safe",
                "2": "moderate",
                "3": "aggressive"
            }
            safety_mode = safety_modes.get(safety_choice, "safe")
        else:
            safety_mode = "safe"
        
        return {
            "multi_agent_enabled": multi_agent,
            "context_management_enabled": context_mgmt,
            "batching_enabled": batching,
            "autonomous_enabled": autonomous,
            "safety_mode": safety_mode
        }
    
    def setup_rate_limits(self):
        print("\n--- Rate Limit Configuration ---\n")
        print("Configure API rate limits (press Enter for defaults):\n")
        
        rpm = int(self.get_input("Requests per minute", "50") or 50)
        rph = int(self.get_input("Requests per hour", "1000") or 1000)
        rpd = int(self.get_input("Requests per day", "10000") or 10000)
        
        return {
            "requests_per_minute": rpm,
            "requests_per_hour": rph,
            "requests_per_day": rpd,
            "tokens_per_minute": 90000,
            "tokens_per_day": 2000000
        }
    
    def save_config(self, config):
        with open(self.config_file, 'w') as f:
            json.dump(config, f, indent=2)
        
        try:
            os.chmod(self.config_file, 0o644)
        except:
            pass
        
        print(f"\n✓ Configuration saved to {self.config_file}")
    
    def run(self):
        self.print_header()
        
        print("Welcome to Qyrox V4.6 Setup!\n")
        print("This wizard will help you configure Qyrox.\n")
        print("Tips:")
        print("  - You can paste text using Ctrl+V or right-click")
        print("  - Press Enter to use default values")
        print("  - Press Ctrl+C to cancel setup\n")
        input("Press Enter to continue...")
        
        self.print_header()
        self.setup_api_keys()
        
        self.print_header()
        agent_config = self.setup_agent_config()
        
        self.print_header()
        features = self.setup_features()
        
        self.print_header()
        rate_limits = self.setup_rate_limits()
        
        config = {
            **agent_config,
            **features,
            "rate_limits": rate_limits
        }
        
        self.print_header()
        print("\n--- Configuration Summary ---\n")
        print(f"Agent Name: {config['agent_name']}")
        print(f"Primary Model: {config['primary_model']}")
        print(f"Multi-Agent: {'Enabled' if config['multi_agent_enabled'] else 'Disabled'}")
        print(f"Context Management: {'Enabled' if config['context_management_enabled'] else 'Disabled'}")
        print(f"Request Batching: {'Enabled' if config['batching_enabled'] else 'Disabled'}")
        print(f"Autonomous Mode: {'Enabled' if config['autonomous_enabled'] else 'Disabled'}")
        if config['autonomous_enabled']:
            print(f"Safety Mode: {config['safety_mode']}")
        print(f"\nRate Limits:")
        print(f"  - {config['rate_limits']['requests_per_minute']} requests/minute")
        print(f"  - {config['rate_limits']['requests_per_hour']} requests/hour")
        print(f"  - {config['rate_limits']['requests_per_day']} requests/day")
        
        print("\n")
        confirm = self.get_input("Save this configuration? (y/n)", "y").lower()
        
        if confirm == 'y':
            self.save_config(config)
            
            self.print_header()
            print("\n✓ Setup completed successfully!\n")
            print("To start Qyrox, run:")
            print("  python main.py\n")
            print("To reconfigure, run:")
            print("  python setup.py\n")
            print("Press Enter to exit...")
            input()
        else:
            print("\nSetup cancelled.")
            print("Press Enter to exit...")
            input()
            sys.exit(0)

if __name__ == "__main__":
    setup = QyroxSetup()
    try:
        setup.run()
    except KeyboardInterrupt:
        print("\n\nSetup cancelled by user.")
        print("Press Enter to exit...")
        try:
            input()
        except:
            pass
        sys.exit(0)
    except Exception as e:
        print(f"\n\nError during setup: {e}")
        print("Press Enter to exit...")
        try:
            input()
        except:
            pass
        sys.exit(1)

# Qyrox V4.6 - Build ea931a7d
