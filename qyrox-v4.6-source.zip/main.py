"""
Main Entry Point - Proactive Super Agent AI Assistant
"""
import sys
import logging
from pathlib import Path
from core import ProactiveSuperAgent
from core.command_handler import CommandHandler
from config import Config

# Setup logging
Config.init_dirs()
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Config.LOGS_DIR / 'agent.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

# Fix Windows console encoding for emoji
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

logger = logging.getLogger(__name__)

def main():
    """Main function"""
    try:
        print("=" * 60)
        print(f"🤖 {Config.AGENT_NAME}")
        print("=" * 60)
        print(f"\nMode: 🔥 {Config.AGENT_NAME} 🔥")
        print("Model: Groq (Llama 3.1) + Google Gemini")
        print("\n✨ Features:")
        print("  📊 API Optimizer: Hemat API, hindari limit")
        print("  🧠 Self-Learning: Buat tools sendiri")
        print("  🔥 Autonomous: Bertindak mandiri")
        print("  💪 14+ Tools: file_search, backup, system_info, dll")
        print("\nCommands:")
        print("  /autonomous on   - Mode agresif & mandiri")
        print("  /stats           - Lihat API usage")
        print("  /goal <text>     - Tambah goal")
        print("  /help            - Bantuan lengkap")
        print("  /exit            - Keluar")
        print("=" * 60)
        
        # Initialize agent
        print("\n⏳ Initializing agent...")
        agent = ProactiveSuperAgent()
        command_handler = CommandHandler(agent)
        print("✓ Agent initialized successfully!")
        
        # Welcome message
        print("\n⏳ Generating welcome message...")
        welcome = agent.process("Perkenalkan dirimu sebagai ultimate autonomous AI assistant yang powerful.")
        print(f"\n🤖 {agent.name}:\n{welcome}\n")
        print("\n💡 TIP: Gunakan /autonomous on untuk mode agresif!")
        print("    Gunakan /stats untuk monitor API usage!\n")
        
    except ImportError as e:
        print("\n❌ ERROR: Missing dependencies!")
        print(f"   {e}")
        print("\n📦 Please install dependencies:")
        print("   pip install -r requirements.txt")
        print("\nPress Enter to exit...")
        input()
        return
    except FileNotFoundError as e:
        print("\n❌ ERROR: File not found!")
        print(f"   {e}")
        print("\n📁 Make sure you're running from the correct directory.")
        print("   Required files: config.py, api_key.txt, core/")
        print("\nPress Enter to exit...")
        input()
        return
    except Exception as e:
        print("\n❌ ERROR during initialization!")
        print(f"   {e}")
        print("\n🔍 Common issues:")
        print("   1. API keys not configured in api_key.txt")
        print("   2. Invalid API key format")
        print("   3. Missing core modules")
        print("\nPress Enter to exit...")
        input()
        import traceback
        traceback.print_exc()
        return
    
    # Main loop
    while True:
        try:
            user_input = input("\n👤 You: ").strip()
            
            if not user_input:
                continue
            
            # Handle commands
            if user_input.startswith('/'):
                should_exit = command_handler.handle(user_input)
                if should_exit:
                    sys.exit(0)
                continue
            
            # Process normal input
            response = agent.process(user_input)
            print(f"\n🤖 {agent.name}:\n{response}")
            
        except KeyboardInterrupt:
            print("\n\n👋 Sampai jumpa!")
            break
        except Exception as e:
            logger.error(f"Error: {e}")
            print(f"\n❌ Error: {e}")
            print("💡 Tip: Coba lagi atau ketik /help untuk bantuan")

# Command handling moved to core/command_handler.py

if __name__ == "__main__":
    main()

# Qyrox V4.6 - Build b86a4881
