# 🤖 Qyrox V4.2 - Complete Documentation

> Ultimate Autonomous AI Assistant - Lightweight, Secure, Powerful, Truly Autonomous

**Version:** V4.2  
**Rating:** 9.0/10 ⭐ (Reviewed by Gemini AI & DeepSeek AI)  
**Status:** Production-Ready

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [Features](#features)
4. [V4.2 True Autonomous Mode](#v42-true-autonomous-mode)
5. [Installation](#installation)
6. [Configuration](#configuration)
7. [Usage](#usage)
8. [Commands Reference](#commands-reference)
9. [Tools](#tools)
10. [Architecture](#architecture)
11. [Security](#security)
12. [Customization](#customization)
13. [Troubleshooting](#troubleshooting)
14. [Changelog](#changelog)

---

## 🎯 Overview

Qyrox adalah AI assistant otonom yang:
- 🔥 **Truly Autonomous** - Bertindak sendiri berdasarkan context (V4.2 NEW!)
- 🛡️ **Safety First** - 3 safety modes dengan guardrails (V4.2 NEW!)
- 🧠 **Self-Learning** - Bisa membuat tools sendiri jika diperlukan
- 💪 **Proactive** - Antisipasi kebutuhan sebelum diminta
- 🔒 **Secure** - Encrypted API keys, safe code execution
- 💰 **Cost-Effective** - Menggunakan free APIs dengan semantic caching (90% savings)

### Why Qyrox?

Dibandingkan dengan AI assistant lain:
- ✅ Lebih ringan dari OpenClaw
- ✅ Lebih aman (encrypted keys, command whitelist, safety guardrails)
- ✅ Lebih hemat (semantic caching)
- ✅ Lebih mandiri (self-learning, true autonomous mode)
- ✅ Lebih mudah dikustomisasi (personality system)
- ✅ Lebih terkontrol (approval system, action history)

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Setup API Keys

**Option A: Environment Variables (Recommended)**
```bash
export GROQ_API_KEY="gsk_xxx"
export GOOGLE_API_KEY="AIzaSyxxx"
```

**Option B: Encrypted Storage**
```bash
python migrate_to_v4.1.py
```

**Option C: Plaintext (Legacy)**
Create `api_key.txt`:
```
groq=gsk_xxx
google=AIzaSyxxx
```

### 3. Run
```bash
python main.py
# or double-click START.bat
```

### 4. Try True Autonomous Mode (V4.2)
```bash
/autonomous on safe      # Safe mode with approval
/autonomous on moderate  # Moderate mode
/autonomous on aggressive # Full autonomous
```

### 5. Test
```bash
python test_v4.1.py
```

---

## ✨ Features

### V4.2 New Features - True Autonomous Mode 🤖

**Self-Acting Agent**
- Bertindak sendiri tanpa perintah eksplisit
- Monitoring system health otomatis
- Auto-detect issues (memory, disk, CPU)
- Smart decision making based on context

**Autonomous Actions**
- `optimize_memory` - Auto clean memory & cache
- `clean_temp_files` - Remove old temp files
- `backup_important_files` - Auto backup data
- `update_context` - Refresh context awareness
- `check_system_health` - Monitor system
- `learn_from_patterns` - Analyze user patterns

**Safety Features**
- 3 Safety Modes: Safe / Moderate / Aggressive
- Action whitelist/blacklist
- User approval system (configurable)
- Rate limiting (max actions per hour)
- Cooldown system (prevent spam)
- Full action history & audit trail

**Commands**
```bash
/autonomous              # Show status
/autonomous on [mode]    # Enable (safe/moderate/aggressive)
/autonomous off          # Disable
/autonomous trigger <action>  # Manual trigger
/autonomous history      # Show action history
```

See [V4.2_AUTONOMOUS_GUIDE.md](V4.2_AUTONOMOUS_GUIDE.md) for complete guide.

### Core Features
- **Multi-Model Support**: Groq (Llama 3.1), Google Gemini, OpenRouter with auto-fallback
- **Semantic Caching**: 90% API call reduction
- **Memory System**: Short-term & long-term memory with goal tracking
- **14+ Built-in Tools**: File ops, web search, system commands, backup, etc.
- **API Optimizer**: Rate limiting, token tracking, smart optimization
- **Self-Learning**: Creates new tools when needed
- **Self-Repair**: Fixes itself when errors occur

### V4.1 Features
- 🔒 **Encrypted API Keys**: Fernet encryption for secure storage
- 🛡️ **Safe Code Execution**: subprocess instead of exec()
- ✅ **Command Whitelist**: Only safe system commands allowed
- 🔍 **Input Validation**: Sanitize all inputs
- 🔧 **Refactored Architecture**: Cleaner, more maintainable code

### V4.0 Features
- **Context Awareness**: Agent knows its own state
- **Sleep System**: Auto-sleep when API limit reached
- **Dream System**: Process memories during sleep
- **Multi-AI Discussion**: Simulate discussion between AI models
- **Activity Monitoring**: Track user patterns
- **Security Monitor**: Detect threats and backup files
- **Mistake Learner**: Learn from errors

---

## 📦 Installation

### Requirements
- Python 3.8+
- pip
- Internet connection

### Step-by-Step

1. **Clone/Download**
   ```bash
   git clone <repo-url>
   cd proactive-ai-assistant
   ```

2. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Get API Keys**
   - Groq: https://console.groq.com (Free)
   - Google Gemini: https://makersuite.google.com (Free)
   - OpenRouter: https://openrouter.ai (Optional)

4. **Configure Keys** (see Configuration section)

5. **Run**
   ```bash
   python main.py
   ```

---

## ⚙️ Configuration

### API Keys

**Method 1: Environment Variables (Most Secure)**
```bash
# Linux/Mac
export GROQ_API_KEY="your_key"
export GOOGLE_API_KEY="your_key"

# Windows PowerShell
$env:GROQ_API_KEY="your_key"
$env:GOOGLE_API_KEY="your_key"

# Windows CMD
set GROQ_API_KEY=your_key
set GOOGLE_API_KEY=your_key
```

**Method 2: Encrypted Storage**
```bash
# Create api_key.txt first
python migrate_to_v4.1.py
# Creates: data/api_keys.enc and .key
```

**Method 3: Plaintext (Not Recommended)**
Create `api_key.txt`:
```
groq=gsk_xxx
google=AIzaSyxxx
openrouter=sk-or-xxx
```

### Personality

Edit `personality.txt` to customize agent behavior:
```
Kamu adalah AI assistant yang sangat cerdas dan proaktif.
Kamu selalu mencari cara untuk membantu user.
Kamu berbicara dengan gaya casual tapi profesional.
```

Or use presets in `personality_presets/`:
- PRESET_1_PROFESSIONAL.txt
- PRESET_2_CASUAL_FRIEND.txt
- PRESET_3_TECHNICAL_EXPERT.txt
- PRESET_4_AGGRESSIVE_AUTONOMOUS.txt

### Config.py

Edit `config.py` for advanced settings:
```python
AGENT_NAME = "Qyrox"
MAX_MEMORY_SIZE = 50
CACHE_SIMILARITY_THRESHOLD = 0.85
API_RATE_LIMIT = 30  # requests per minute
```

---

## 💬 Usage

### Basic Chat
```
👤 You: Halo!
🤖 Qyrox: Halo! Ada yang bisa saya bantu?

👤 You: Cari file config.py
🤖 Qyrox: [Uses file_search tool]
```

### Commands
All commands start with `/`:
```
/help              - Show all commands
/autonomous on     - Enable autonomous mode
/stats             - Show API usage
/goal <text>       - Add a goal
/security status   - Check security
```

### Autonomous Mode
```
/autonomous on
```
In this mode, agent will:
- Act more aggressively
- Create tools if needed
- Execute system commands (with confirmation)
- Self-repair on errors

---

## 📖 Commands Reference

### Basic Commands
- `/help` - Show help
- `/exit` - Exit program
- `/stats` - API usage statistics
- `/tool [name]` - List/info about tools

### Goal Management
- `/goal <text>` - Add new goal
- `/goals` - View active goals
- `/proactive` - Manual proactive check

### Autonomous Mode
- `/autonomous on` - Enable autonomous mode
- `/autonomous off` - Disable autonomous mode
- `/learned` - View learned tools

### V4.0 Phase 1 (Context & Dreams)
- `/context` - Show agent self-awareness
- `/sleep` - Check sleep status
- `/wake` - Force wake up
- `/dream` - Trigger manual dream
- `/imagine <text>` - Imagination mode
- `/dreams` - View dream journal

### V4.0 Phase 2 (Monitoring & Security)
- `/monitor start` - Start activity monitoring
- `/monitor stop` - Stop monitoring
- `/monitor insights` - View activity insights
- `/monitor predict` - Predict next action
- `/monitor suggest` - Get proactive suggestions
- `/monitor signal` - Start signal monitoring

### Security Commands
- `/security status` - Security status
- `/security scan` - Scan for threats
- `/security backup` - Backup important files
- `/security alerts` - View security alerts

### Learning Commands
- `/mistakes stats` - View mistake statistics
- `/mistakes insights` - Learning insights

---

## 🛠️ Tools

### Built-in Tools (14+)

1. **web_search** - Search the web
   ```python
   web_search(query="Python tutorial")
   ```

2. **web_scrape** - Scrape website content
   ```python
   web_scrape(url="https://example.com")
   ```

3. **file_read** - Read file content
   ```python
   file_read(filepath="config.py")
   ```

4. **file_write** - Write to file
   ```python
   file_write(filepath="output.txt", content="Hello")
   ```

5. **file_search** - Search for files
   ```python
   file_search(filename="*.py", directory=".")
   ```

6. **execute_code** - Execute Python code (safe)
   ```python
   execute_code(code="print('Hello')")
   ```

7. **system_command** - Run system commands (whitelisted)
   ```python
   system_command(command="ls -la")
   ```

8. **get_system_info** - Get system information
   ```python
   get_system_info()
   ```

9. **create_backup** - Backup files/folders
   ```python
   create_backup(source="important_folder")
   ```

10. **calculate** - Mathematical calculations
    ```python
    calculate(expression="2 + 2 * 3")
    ```

11. **get_datetime** - Current date/time
    ```python
    get_datetime()
    ```

12. **remember** - Store in memory
    ```python
    remember(key="user_name", value="John")
    ```

13. **recall** - Retrieve from memory
    ```python
    recall(key="user_name")
    ```

14. **create_tool** - Self-learning (autonomous mode)
    ```python
    create_tool(name="new_tool", description="...", code="...")
    ```

### Tool Security

**Safe Commands Whitelist:**
- `ls`, `dir`, `pwd`, `echo`, `cat`, `type`
- `ping`, `ipconfig`, `systeminfo`, `tasklist`

**Dangerous commands require confirmation:**
- `shutdown`, `reboot`, `rm`, `del`, `format`

---

## 🏗️ Architecture

### Project Structure
```
proactive-ai-assistant/
├── core/                      # Core modules
│   ├── agent.py              # Main agent logic
│   ├── llm_manager.py        # LLM handling
│   ├── tools_manager.py      # Tool management
│   ├── memory.py             # Memory system
│   ├── semantic_cache.py     # Caching
│   ├── api_optimizer.py      # API optimization
│   ├── command_handler.py    # Command handling
│   ├── api_key_manager.py    # Secure key management
│   ├── context_awareness.py  # Self-awareness
│   ├── sleep_system.py       # Sleep/wake
│   ├── dream_system.py       # Dream processing
│   ├── activity_monitor.py   # Activity tracking
│   ├── security_monitor.py   # Security
│   └── mistake_learner.py    # Learning from errors
├── data/                      # Data storage
│   ├── memory/               # Memory files
│   ├── cache/                # Cache files
│   └── logs/                 # Log files
├── main.py                    # Entry point
├── config.py                  # Configuration
├── requirements.txt           # Dependencies
└── DOCUMENTATION.md           # This file
```

### Key Components

**ProactiveSuperAgent** (core/agent.py)
- Main agent class
- Orchestrates all components
- Handles user input/output

**LLMManager** (core/llm_manager.py)
- Manages multiple LLM providers
- Auto-fallback on errors
- Token tracking

**ToolsManager** (core/tools_manager.py)
- Manages all tools
- Safe execution
- Self-learning capability

**Memory** (core/memory.py)
- Short-term memory
- Long-term memory
- Goal tracking

**SemanticCache** (core/semantic_cache.py)
- Semantic similarity matching
- 90% cache hit rate
- Automatic cleanup

---

## 🔒 Security

### V4.1 Security Features

**1. Encrypted API Keys**
- Uses Fernet (symmetric encryption)
- Keys stored in `data/api_keys.enc`
- Encryption key in `.key` (add to .gitignore!)

**2. Safe Code Execution**
- Uses `subprocess` instead of `exec()`
- Timeout protection (30s default)
- Isolated environment
- No access to dangerous modules

**3. Command Whitelist**
- Only safe commands allowed
- Dangerous commands require confirmation
- Input validation and sanitization

**4. Input Validation**
- All user inputs sanitized
- Path traversal prevention
- Command injection prevention

### Security Best Practices

1. **Use environment variables in production**
   ```bash
   export GROQ_API_KEY="..."
   ```

2. **Never commit sensitive files**
   - `.key`
   - `data/api_keys.enc`
   - `api_key.txt`

3. **Keep .gitignore updated**
   Already configured in `.gitignore`

4. **Monitor security alerts**
   ```bash
   /security status
   /security alerts
   ```

5. **Regular backups**
   ```bash
   /security backup
   ```

---

## 🎨 Customization

### Change Agent Name

Edit `config.py`:
```python
AGENT_NAME = "YourName"
```

### Change Personality

Edit `personality.txt` or use presets:
```bash
cp personality_presets/PRESET_2_CASUAL_FRIEND.txt personality.txt
```

### Add Custom Tools

Edit `core/tools_manager.py`:
```python
def your_custom_tool(param1, param2):
    """Your tool description"""
    # Your code here
    return result

# Register in __init__
self.tools["your_custom_tool"] = your_custom_tool
```

### Adjust API Settings

Edit `config.py`:
```python
API_RATE_LIMIT = 30  # requests per minute
MAX_TOKENS = 4000
TEMPERATURE = 0.7
```

---

## 🐛 Troubleshooting

### Common Issues

**1. Import Error**
```
ImportError: No module named 'langchain'
```
**Solution:**
```bash
pip install -r requirements.txt
```

**2. API Key Error**
```
Error: API key not found
```
**Solution:**
- Check `api_key.txt` format
- Or use environment variables
- Or run `python migrate_to_v4.1.py`

**3. Unicode Error (Windows)**
```
UnicodeEncodeError: 'charmap' codec can't encode character
```
**Solution:** Already fixed in V3.1+. If still occurs:
```bash
chcp 65001
python main.py
```

**4. Rate Limit Error**
```
Error: Rate limit exceeded
```
**Solution:**
- Wait a few minutes
- Agent will auto-sleep and retry
- Check `/stats` for usage

**5. Tool Execution Error**
```
Error: Command not allowed
```
**Solution:**
- Check if command is in whitelist
- Use `/autonomous on` for more permissions
- Confirm dangerous operations

### Debug Mode

Enable detailed logging:
```python
# In config.py
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Test Installation

```bash
python test_v4.1.py
```

---

## 📝 Changelog

### [4.1.0] - 2024 🔒 SECURITY & REFACTORING

**Security:**
- ✅ Encrypted API key storage (Fernet)
- ✅ Safe code execution (subprocess)
- ✅ Command whitelist
- ✅ Input validation

**Code Quality:**
- ✅ Refactored main.py (400→100 lines)
- ✅ New CommandHandler module
- ✅ New APIKeyManager module
- ✅ Better testability

**Documentation:**
- ✅ Consolidated into DOCUMENTATION.md
- ✅ Migration guide
- ✅ Security guide

**Rating:** 8.25/10 → 8.75/10

### [3.1.0] - 2024 🔧 STABILITY

**Bug Fixes:**
- ✅ Removed speech engine (fixed errors)
- ✅ Fixed Unicode issues
- ✅ Fixed file_read parameters

**New Tools:**
- ✅ file_search
- ✅ get_system_info
- ✅ create_backup

### [4.0.0] - 2024 🧠 INTELLIGENCE

**Phase 1:**
- ✅ Context awareness
- ✅ Sleep system
- ✅ Dream system
- ✅ Multi-AI discussion

**Phase 2:**
- ✅ Activity monitoring
- ✅ Security monitor
- ✅ Mistake learner

### [3.0.0] - 2024 🚀 AUTONOMOUS

- ✅ Autonomous mode
- ✅ Self-learning
- ✅ Self-repair
- ✅ Semantic caching
- ✅ API optimizer

---

## 🎯 FAQ

**Q: Apakah Qyrox gratis?**
A: Ya! Menggunakan free APIs (Groq, Google Gemini).

**Q: Apakah aman?**
A: Ya! V4.1 memiliki encrypted keys, safe execution, dan command whitelist.

**Q: Berapa banyak API calls yang dihemat?**
A: Semantic caching menghemat ~90% API calls.

**Q: Bisa buat tools sendiri?**
A: Ya! Gunakan `/autonomous on` untuk self-learning mode.

**Q: Apakah bisa offline?**
A: Tidak, memerlukan internet untuk LLM APIs.

**Q: Bagaimana cara upgrade dari V4.0?**
A: 100% backward compatible. Cukup update code dan run `python migrate_to_v4.1.py`.

**Q: Apakah ada GUI?**
A: Belum. Saat ini terminal-based. GUI planned untuk V5.0.

**Q: Bagaimana cara kontribusi?**
A: Fork repo, buat changes, submit PR!

---

## 🚀 Roadmap

### V4.2 (Next)
- [ ] Comprehensive unit tests
- [ ] Integration tests
- [ ] CI/CD pipeline
- [ ] Performance benchmarks

### V5.0 (Future)
- [ ] Vector Database (FAISS/Qdrant) for RAG
- [ ] Web Dashboard (Flask/FastAPI)
- [ ] Plugin Marketplace
- [ ] Local LLM support (Ollama)
- [ ] Multi-user support
- [ ] Docker deployment

---

## 📞 Support

**Documentation:** This file (DOCUMENTATION.md)
**Test:** `python test_v4.1.py`
**Ask Qyrox:** It can explain its own features!

---

## 🙏 Credits

**Reviews by:**
- Gemini AI - Architecture & feature suggestions
- DeepSeek AI - Security & code quality analysis

**Inspired by:**
- OpenClaw (but lighter & more secure)
- LangChain Agent framework
- Autonomous AI research

---

## 📄 License

[Your License Here]

---

**Version:** V4.1  
**Status:** ✅ Production-Ready  
**Last Updated:** 2024

**Thank you for using Qyrox!** 🚀
