"""
Autonomous Engine V4.2 - True Autonomous Agent with Safety Guardrails
Agent yang bisa bertindak sendiri berdasarkan context, dengan keamanan ketat
"""
import logging
import time
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import threading

logger = logging.getLogger(__name__)

class AutonomousEngine:
    """
    True Autonomous Agent Engine
    - Bertindak sendiri berdasarkan context dan patterns
    - Safety guardrails untuk mencegah tindakan berbahaya
    - User approval untuk tindakan kritis
    """
    
    def __init__(self, agent):
        self.agent = agent
        self.enabled = False
        self.data_dir = Path(__file__).parent.parent / "data"
        self.autonomous_log = self.data_dir / "autonomous_actions.json"
        
        # Safety settings
        self.safety_mode = "safe"  # safe, moderate, aggressive
        self.require_approval = True  # Require user approval for actions
        self.max_actions_per_hour = 10
        self.action_cooldown = 300  # 5 minutes between autonomous actions
        
        # Whitelist untuk tindakan aman
        self.safe_actions = [
            "check_system_health",
            "optimize_memory",
            "clean_temp_files",
            "backup_important_files",
            "update_context",
            "learn_from_patterns"
        ]
        
        # Blacklist untuk tindakan berbahaya
        self.dangerous_actions = [
            "delete_system_files",
            "modify_registry",
            "install_software",
            "change_permissions",
            "execute_unknown_code"
        ]
        
        # Action history
        self.action_history = self._load_action_history()
        self.last_action_time = None
        
        # Monitoring thread
        self.monitoring_thread = None
        self.stop_monitoring = False
        
        logger.info("✓ Autonomous Engine initialized")
    
    def _load_action_history(self) -> List[Dict]:
        """Load action history"""
        if self.autonomous_log.exists():
            try:
                with open(self.autonomous_log, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def _save_action_history(self):
        """Save action history"""
        try:
            self.autonomous_log.parent.mkdir(parents=True, exist_ok=True)
            with open(self.autonomous_log, 'w', encoding='utf-8') as f:
                json.dump(self.action_history[-1000:], f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save action history: {e}")
    
    def enable(self, safety_mode: str = "safe"):
        """Enable autonomous mode"""
        self.enabled = True
        self.safety_mode = safety_mode
        
        # Adjust settings based on safety mode
        if safety_mode == "safe":
            self.require_approval = True
            self.max_actions_per_hour = 5
            self.action_cooldown = 600  # 10 minutes
        elif safety_mode == "moderate":
            self.require_approval = True
            self.max_actions_per_hour = 10
            self.action_cooldown = 300  # 5 minutes
        elif safety_mode == "aggressive":
            self.require_approval = False
            self.max_actions_per_hour = 20
            self.action_cooldown = 180  # 3 minutes
        
        # Start monitoring thread
        if not self.monitoring_thread or not self.monitoring_thread.is_alive():
            self.stop_monitoring = False
            self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitoring_thread.start()
        
        logger.info(f"✓ Autonomous mode enabled (safety: {safety_mode})")
        return f"🔥 Autonomous mode ENABLED (Safety: {safety_mode})"
    
    def disable(self):
        """Disable autonomous mode"""
        self.enabled = False
        self.stop_monitoring = True
        logger.info("✓ Autonomous mode disabled")
        return "🛑 Autonomous mode DISABLED"
    
    def _monitoring_loop(self):
        """Background monitoring loop"""
        logger.info("✓ Autonomous monitoring started")
        
        while not self.stop_monitoring and self.enabled:
            try:
                # Check if we should take autonomous action
                if self._should_take_action():
                    action = self._decide_action()
                    if action:
                        self._execute_autonomous_action(action)
                
                # Sleep for cooldown period
                time.sleep(self.action_cooldown)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(60)  # Wait 1 minute on error
        
        logger.info("✓ Autonomous monitoring stopped")
    
    def _should_take_action(self) -> bool:
        """Determine if agent should take autonomous action"""
        if not self.enabled:
            return False
        
        # Check cooldown
        if self.last_action_time:
            elapsed = (datetime.now() - self.last_action_time).total_seconds()
            if elapsed < self.action_cooldown:
                return False
        
        # Check hourly limit
        one_hour_ago = datetime.now() - timedelta(hours=1)
        recent_actions = [
            a for a in self.action_history
            if datetime.fromisoformat(a['timestamp']) > one_hour_ago
        ]
        if len(recent_actions) >= self.max_actions_per_hour:
            logger.warning("⚠️ Hourly action limit reached")
            return False
        
        return True
    
    def _decide_action(self) -> Optional[Dict]:
        """Decide what action to take based on context"""
        try:
            # Analyze current context
            context = self._analyze_context()
            
            # Determine best action
            action = None
            
            # Example: Check system health
            if context.get('memory_usage', 0) > 80:
                action = {
                    'type': 'optimize_memory',
                    'reason': 'High memory usage detected',
                    'priority': 'medium',
                    'safe': True
                }
            
            # Example: Backup if not done recently
            elif context.get('days_since_backup', 999) > 7:
                action = {
                    'type': 'backup_important_files',
                    'reason': 'No backup in 7 days',
                    'priority': 'low',
                    'safe': True
                }
            
            # Example: Clean temp files
            elif context.get('temp_files_size_mb', 0) > 1000:
                action = {
                    'type': 'clean_temp_files',
                    'reason': 'Large temp files detected',
                    'priority': 'low',
                    'safe': True
                }
            
            # Example: Update context awareness
            elif context.get('hours_since_context_update', 999) > 24:
                action = {
                    'type': 'update_context',
                    'reason': 'Context data is outdated',
                    'priority': 'low',
                    'safe': True
                }
            
            return action
            
        except Exception as e:
            logger.error(f"Error deciding action: {e}")
            return None
    
    def _analyze_context(self) -> Dict:
        """Analyze current context to determine needs"""
        context = {}
        
        try:
            import psutil
            
            # System metrics
            context['memory_usage'] = psutil.virtual_memory().percent
            context['cpu_usage'] = psutil.cpu_percent(interval=1)
            context['disk_usage'] = psutil.disk_usage('/').percent
            
            # Temp files
            import tempfile
            temp_dir = Path(tempfile.gettempdir())
            if temp_dir.exists():
                temp_size = sum(f.stat().st_size for f in temp_dir.rglob('*') if f.is_file())
                context['temp_files_size_mb'] = temp_size / (1024 * 1024)
            
            # Backup status
            backup_file = self.data_dir / "last_backup.json"
            if backup_file.exists():
                with open(backup_file, 'r') as f:
                    backup_data = json.load(f)
                    last_backup = datetime.fromisoformat(backup_data.get('timestamp', '2000-01-01'))
                    context['days_since_backup'] = (datetime.now() - last_backup).days
            else:
                context['days_since_backup'] = 999
            
            # Context update status
            context_file = self.data_dir / "context.json"
            if context_file.exists():
                mtime = datetime.fromtimestamp(context_file.stat().st_mtime)
                context['hours_since_context_update'] = (datetime.now() - mtime).total_seconds() / 3600
            else:
                context['hours_since_context_update'] = 999
            
        except Exception as e:
            logger.error(f"Error analyzing context: {e}")
        
        return context

    
    def _execute_autonomous_action(self, action: Dict):
        """Execute autonomous action with safety checks"""
        try:
            action_type = action['type']
            
            # Safety check
            if not self._is_action_safe(action_type):
                logger.warning(f"⚠️ Action blocked by safety check: {action_type}")
                return
            
            # Request approval if required
            if self.require_approval and not action.get('auto_approved', False):
                approved = self._request_approval(action)
                if not approved:
                    logger.info(f"❌ Action rejected by user: {action_type}")
                    return
            
            # Log action
            logger.info(f"🤖 Executing autonomous action: {action_type}")
            print(f"\n🤖 [AUTONOMOUS] Executing: {action_type}")
            print(f"   Reason: {action['reason']}")
            
            # Execute action
            result = self._perform_action(action_type)
            
            # Record action
            self.action_history.append({
                'timestamp': datetime.now().isoformat(),
                'action': action_type,
                'reason': action['reason'],
                'result': result,
                'safety_mode': self.safety_mode
            })
            self._save_action_history()
            
            self.last_action_time = datetime.now()
            
            print(f"   ✓ Result: {result}")
            
        except Exception as e:
            logger.error(f"Error executing autonomous action: {e}")
            print(f"   ❌ Error: {e}")
    
    def _is_action_safe(self, action_type: str) -> bool:
        """Check if action is safe to execute"""
        # Check blacklist
        if action_type in self.dangerous_actions:
            return False
        
        # In safe mode, only allow whitelisted actions
        if self.safety_mode == "safe":
            return action_type in self.safe_actions
        
        # In moderate mode, allow safe actions + some others
        if self.safety_mode == "moderate":
            return action_type not in self.dangerous_actions
        
        # In aggressive mode, allow most actions except blacklisted
        return action_type not in self.dangerous_actions
    
    def _request_approval(self, action: Dict) -> bool:
        """Request user approval for action"""
        print(f"\n🤖 [AUTONOMOUS REQUEST]")
        print(f"   Action: {action['type']}")
        print(f"   Reason: {action['reason']}")
        print(f"   Priority: {action['priority']}")
        
        try:
            response = input("   Approve? (y/n): ").strip().lower()
            return response in ['y', 'yes']
        except:
            return False
    
    def _perform_action(self, action_type: str) -> str:
        """Perform the actual action"""
        try:
            if action_type == "optimize_memory":
                return self._optimize_memory()
            
            elif action_type == "clean_temp_files":
                return self._clean_temp_files()
            
            elif action_type == "backup_important_files":
                return self._backup_important_files()
            
            elif action_type == "update_context":
                return self._update_context()
            
            elif action_type == "check_system_health":
                return self._check_system_health()
            
            elif action_type == "learn_from_patterns":
                return self._learn_from_patterns()
            
            else:
                return f"Unknown action: {action_type}"
                
        except Exception as e:
            return f"Error: {e}"
    
    def _optimize_memory(self) -> str:
        """Optimize memory usage"""
        try:
            import gc
            gc.collect()
            
            # Clear semantic cache if exists
            cache_file = self.data_dir / "cache" / "semantic_cache.json"
            if cache_file.exists():
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache = json.load(f)
                
                # Keep only recent entries
                if len(cache) > 100:
                    cache = cache[-100:]
                    with open(cache_file, 'w', encoding='utf-8') as f:
                        json.dump(cache, f, indent=2)
            
            return "Memory optimized, cache cleaned"
        except Exception as e:
            return f"Failed: {e}"
    
    def _clean_temp_files(self) -> str:
        """Clean temporary files"""
        try:
            import tempfile
            import shutil
            
            temp_dir = Path(tempfile.gettempdir())
            cleaned = 0
            
            # Only clean files older than 7 days
            cutoff = datetime.now() - timedelta(days=7)
            
            for file in temp_dir.rglob('*'):
                if file.is_file():
                    try:
                        mtime = datetime.fromtimestamp(file.stat().st_mtime)
                        if mtime < cutoff:
                            file.unlink()
                            cleaned += 1
                    except:
                        pass
            
            return f"Cleaned {cleaned} old temp files"
        except Exception as e:
            return f"Failed: {e}"
    
    def _backup_important_files(self) -> str:
        """Backup important files"""
        try:
            import shutil
            
            backup_dir = self.data_dir / "backups" / datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            # Backup important data files
            important_files = [
                self.data_dir / "context.json",
                self.data_dir / "user_patterns.json",
                self.data_dir / "memory" / "short_term.json"
            ]
            
            backed_up = 0
            for file in important_files:
                if file.exists():
                    shutil.copy2(file, backup_dir / file.name)
                    backed_up += 1
            
            # Record backup
            with open(self.data_dir / "last_backup.json", 'w') as f:
                json.dump({
                    'timestamp': datetime.now().isoformat(),
                    'files': backed_up
                }, f)
            
            return f"Backed up {backed_up} files to {backup_dir.name}"
        except Exception as e:
            return f"Failed: {e}"
    
    def _update_context(self) -> str:
        """Update context awareness"""
        try:
            if hasattr(self.agent, 'context_awareness'):
                self.agent.context_awareness._update_context()
                return "Context awareness updated"
            return "Context awareness not available"
        except Exception as e:
            return f"Failed: {e}"
    
    def _check_system_health(self) -> str:
        """Check system health"""
        try:
            import psutil
            
            health = {
                'memory': psutil.virtual_memory().percent,
                'cpu': psutil.cpu_percent(interval=1),
                'disk': psutil.disk_usage('/').percent
            }
            
            issues = []
            if health['memory'] > 90:
                issues.append("High memory usage")
            if health['cpu'] > 90:
                issues.append("High CPU usage")
            if health['disk'] > 90:
                issues.append("Low disk space")
            
            if issues:
                return f"Health issues: {', '.join(issues)}"
            return "System health: OK"
        except Exception as e:
            return f"Failed: {e}"
    
    def _learn_from_patterns(self) -> str:
        """Learn from user patterns"""
        try:
            # Analyze recent activities
            if hasattr(self.agent, 'context_awareness'):
                activities = self.agent.context_awareness.get_recent_activities(50)
                
                # Simple pattern detection
                patterns = {}
                for activity in activities:
                    hour = datetime.fromisoformat(activity['timestamp']).hour
                    patterns[hour] = patterns.get(hour, 0) + 1
                
                # Find peak hours
                if patterns:
                    peak_hour = max(patterns, key=patterns.get)
                    return f"Learned: Most active at {peak_hour}:00"
            
            return "No patterns detected yet"
        except Exception as e:
            return f"Failed: {e}"
    
    def get_status(self) -> Dict:
        """Get autonomous engine status"""
        recent_actions = self.action_history[-10:] if self.action_history else []
        
        return {
            'enabled': self.enabled,
            'safety_mode': self.safety_mode,
            'require_approval': self.require_approval,
            'max_actions_per_hour': self.max_actions_per_hour,
            'action_cooldown': self.action_cooldown,
            'total_actions': len(self.action_history),
            'recent_actions': recent_actions,
            'last_action': self.action_history[-1] if self.action_history else None
        }
    
    def manual_trigger(self, action_type: str, reason: str = "Manual trigger") -> str:
        """Manually trigger an autonomous action"""
        if not self._is_action_safe(action_type):
            return f"❌ Action not allowed: {action_type}"
        
        action = {
            'type': action_type,
            'reason': reason,
            'priority': 'manual',
            'safe': True,
            'auto_approved': True
        }
        
        self._execute_autonomous_action(action)
        return f"✓ Action executed: {action_type}"

# Qyrox V4.6 - Build 9b96ed1d
