"""
Tools Manager - Mengelola berbagai tools dan capabilities
"""
import requests
from bs4 import BeautifulSoup
import json
import subprocess
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class ToolsManager:
    """Manager untuk berbagai tools yang bisa digunakan agent"""
    
    def __init__(self):
        self.available_tools = {
            "web_search": self.web_search,
            "web_scrape": self.web_scrape,
            "file_read": self.file_read,
            "file_write": self.file_write,
            "file_search": self.file_search,
            "execute_code": self.execute_code,
            "calculate": self.calculate,
            "get_weather": self.get_weather,
            "send_request": self.send_request,
            "system_command": self.system_command,
            "list_processes": self.list_processes,
            "kill_process": self.kill_process,
            "get_system_info": self.get_system_info,
            "create_backup": self.create_backup
        }
        self.learned_tools = {}  # Tools yang dipelajari agent
    
    def web_search(self, query: str) -> str:
        """Search web menggunakan DuckDuckGo"""
        try:
            url = f"https://html.duckduckgo.com/html/?q={query}"
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            results = []
            for result in soup.find_all('div', class_='result')[:5]:
                title = result.find('a', class_='result__a')
                snippet = result.find('a', class_='result__snippet')
                if title and snippet:
                    results.append({
                        'title': title.text,
                        'snippet': snippet.text
                    })
            
            return json.dumps(results, indent=2)
        except Exception as e:
            logger.error(f"Web search error: {e}")
            return f"Error: {str(e)}"
    
    def web_scrape(self, url: str) -> str:
        """Scrape content dari URL"""
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            text = soup.get_text()
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = '\n'.join(chunk for chunk in chunks if chunk)
            
            return text[:2000]  # Limit to 2000 chars
        except Exception as e:
            logger.error(f"Web scrape error: {e}")
            return f"Error: {str(e)}"
    
    def file_read(self, filepath: str = None, path: str = None, file_path: str = None) -> str:
        """Baca file - support multiple parameter names"""
        # Support berbagai nama parameter
        file_to_read = filepath or path or file_path
        if not file_to_read:
            return "Error: No file path provided"
        
        try:
            with open(file_to_read, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            return f"Error reading file: {str(e)}"
    
    def file_write(self, filepath: str, content: str) -> str:
        """Tulis file"""
        try:
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return f"✓ File written: {filepath}"
        except Exception as e:
            return f"Error writing file: {str(e)}"
    
    def execute_code(self, code: str, language: str = "python") -> str:
        """Execute code (Python only untuk keamanan) - SANDBOXED"""
        if language.lower() != "python":
            return "Only Python code execution is supported"
        
        try:
            # Security: Check for dangerous patterns
            dangerous_patterns = [
                'import os', 'import sys', 'import subprocess', 
                '__import__', 'eval(', 'exec(', 'compile(',
                'open(', 'file(', 'input(', 'raw_input(',
                'execfile(', '__builtins__'
            ]
            
            code_lower = code.lower()
            for pattern in dangerous_patterns:
                if pattern in code_lower:
                    return f"🚫 Security: '{pattern}' is not allowed for safety"
            
            # Restricted execution dengan timeout
            import signal
            
            def timeout_handler(signum, frame):
                raise TimeoutError("Code execution timeout (5s)")
            
            # Set timeout (5 seconds)
            signal.signal(signal.SIGALRM, timeout_handler)
            signal.alarm(5)
            
            try:
                # Safe namespace - only math operations
                safe_globals = {
                    '__builtins__': {
                        'abs': abs, 'round': round, 'min': min, 'max': max,
                        'sum': sum, 'pow': pow, 'len': len, 'range': range,
                        'int': int, 'float': float, 'str': str, 'bool': bool,
                        'list': list, 'dict': dict, 'tuple': tuple, 'set': set
                    }
                }
                
                local_vars = {}
                exec(code, safe_globals, local_vars)
                
                signal.alarm(0)  # Cancel timeout
                
                # Return result or success message
                if 'result' in local_vars:
                    return str(local_vars['result'])
                else:
                    return "✓ Code executed successfully (no result variable)"
                    
            except TimeoutError as e:
                signal.alarm(0)
                return f"⏱️ Timeout: {str(e)}"
                
        except Exception as e:
            return f"❌ Execution error: {str(e)}"
    
    def calculate(self, expression: str) -> str:
        """Kalkulasi matematika - SAFE (no eval)"""
        try:
            # Use ast.literal_eval for safety instead of eval
            import ast
            import operator
            
            # Allowed operators
            operators = {
                ast.Add: operator.add,
                ast.Sub: operator.sub,
                ast.Mult: operator.mul,
                ast.Div: operator.truediv,
                ast.Pow: operator.pow,
                ast.Mod: operator.mod,
                ast.FloorDiv: operator.floordiv
            }
            
            def eval_expr(node):
                if isinstance(node, ast.Num):
                    return node.n
                elif isinstance(node, ast.BinOp):
                    return operators[type(node.op)](eval_expr(node.left), eval_expr(node.right))
                elif isinstance(node, ast.UnaryOp):
                    if isinstance(node.op, ast.USub):
                        return -eval_expr(node.operand)
                    elif isinstance(node.op, ast.UAdd):
                        return eval_expr(node.operand)
                else:
                    raise TypeError(f"Unsupported operation: {node}")
            
            # Parse and evaluate
            tree = ast.parse(expression, mode='eval')
            result = eval_expr(tree.body)
            return str(result)
            
        except Exception as e:
            return f"❌ Calculation error: {str(e)}"
    
    def get_weather(self, location: str) -> str:
        """Get weather info (simplified)"""
        try:
            # Using wttr.in API
            url = f"https://wttr.in/{location}?format=j1"
            response = requests.get(url, timeout=10)
            data = response.json()
            
            current = data['current_condition'][0]
            return f"Weather in {location}: {current['temp_C']}°C, {current['weatherDesc'][0]['value']}"
        except Exception as e:
            return f"Weather error: {str(e)}"
    
    def send_request(self, url: str, method: str = "GET", data: dict = None) -> str:
        """Send HTTP request"""
        try:
            if method.upper() == "GET":
                response = requests.get(url, timeout=10)
            elif method.upper() == "POST":
                response = requests.post(url, json=data, timeout=10)
            else:
                return "Only GET and POST methods supported"
            
            return f"Status: {response.status_code}\n{response.text[:500]}"
        except Exception as e:
            return f"Request error: {str(e)}"
    
    def execute_tool(self, tool_name: str, **kwargs) -> str:
        """Execute a tool by name"""
        if tool_name not in self.available_tools:
            return f"Tool '{tool_name}' not found. Available: {list(self.available_tools.keys())}"
        
        try:
            return self.available_tools[tool_name](**kwargs)
        except Exception as e:
            logger.error(f"Tool execution error: {e}")
            return f"Error executing {tool_name}: {str(e)}"
    
    def list_tools(self) -> list:
        """List all available tools"""
        return list(self.available_tools.keys())

    
    def system_command(self, command: str) -> str:
        """Execute system command - WITH WHITELIST"""
        try:
            # Whitelist of safe commands
            safe_commands = [
                'dir', 'ls', 'pwd', 'whoami', 'date', 'time',
                'echo', 'cat', 'head', 'tail', 'wc', 'grep',
                'find', 'which', 'where', 'hostname', 'ipconfig',
                'ifconfig', 'ping', 'tracert', 'traceroute',
                'netstat', 'tasklist', 'ps', 'top', 'df', 'du'
            ]
            
            # Extract base command
            base_cmd = command.split()[0].lower()
            
            # Check if command is in whitelist
            if base_cmd not in safe_commands:
                return f"🚫 Security: Command '{base_cmd}' not in whitelist.\n" \
                       f"Safe commands: {', '.join(safe_commands[:10])}..."
            
            # Execute with timeout
            result = subprocess.run(
                command, 
                shell=True, 
                capture_output=True, 
                text=True, 
                timeout=10  # 10 second timeout
            )
            output = result.stdout if result.stdout else result.stderr
            return output[:1000]  # Limit output
            
        except subprocess.TimeoutExpired:
            return "⏱️ Command timeout (10s limit)"
        except Exception as e:
            return f"❌ Error: {str(e)}"
    
    def list_processes(self) -> str:
        """List running processes"""
        try:
            if subprocess.sys.platform == "win32":
                result = subprocess.run("tasklist", capture_output=True, text=True)
            else:
                result = subprocess.run("ps aux", shell=True, capture_output=True, text=True)
            return result.stdout[:2000]
        except Exception as e:
            return f"Error: {str(e)}"
    
    def kill_process(self, process_name: str) -> str:
        """Kill a process by name"""
        try:
            if subprocess.sys.platform == "win32":
                subprocess.run(f"taskkill /IM {process_name} /F", shell=True)
            else:
                subprocess.run(f"pkill {process_name}", shell=True)
            return f"✓ Process {process_name} terminated"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def register_learned_tool(self, tool_name: str, code: str):
        """Register a learned tool"""
        try:
            # Create function from code
            exec_globals = {}
            exec(code, exec_globals)
            
            # Get the function
            if tool_name in exec_globals:
                self.learned_tools[tool_name] = exec_globals[tool_name]
                self.available_tools[tool_name] = exec_globals[tool_name]
                logger.info(f"✓ Learned tool '{tool_name}' registered")
                return True
        except Exception as e:
            logger.error(f"Failed to register learned tool: {e}")
            return False
    
    def list_tools(self) -> list:
        """List all available tools (built-in + learned)"""
        return list(self.available_tools.keys())

    
    def file_search(self, filename: str, directory: str = ".") -> str:
        """Search for files by name"""
        try:
            import os
            import glob
            
            # Search recursively
            pattern = f"**/{filename}"
            matches = []
            
            for root, dirs, files in os.walk(directory):
                for file in files:
                    if filename.lower() in file.lower():
                        full_path = os.path.join(root, file)
                        matches.append(full_path)
                        if len(matches) >= 20:  # Limit results
                            break
                if len(matches) >= 20:
                    break
            
            if matches:
                result = f"Found {len(matches)} file(s):\n"
                for match in matches[:10]:  # Show first 10
                    result += f"  - {match}\n"
                if len(matches) > 10:
                    result += f"  ... and {len(matches) - 10} more"
                return result
            else:
                return f"No files found matching '{filename}'"
                
        except Exception as e:
            return f"Error searching files: {str(e)}"
    
    def get_system_info(self) -> str:
        """Get system information"""
        try:
            import platform
            import psutil
            
            info = f"""System Information:
==================================
OS: {platform.system()} {platform.release()}
Architecture: {platform.machine()}
Processor: {platform.processor()}

CPU Usage: {psutil.cpu_percent()}%
Memory: {psutil.virtual_memory().percent}% used
Disk: {psutil.disk_usage('/').percent}% used

Python: {platform.python_version()}
=================================="""
            return info
        except ImportError:
            return "Install psutil: pip install psutil"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def create_backup(self, source: str, destination: str = None) -> str:
        """Create backup of file or folder"""
        try:
            import shutil
            from datetime import datetime
            
            if not destination:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                destination = f"{source}_backup_{timestamp}"
            
            if os.path.isfile(source):
                shutil.copy2(source, destination)
                return f"✓ File backed up: {destination}"
            elif os.path.isdir(source):
                shutil.copytree(source, destination)
                return f"✓ Folder backed up: {destination}"
            else:
                return f"Error: {source} not found"
                
        except Exception as e:
            return f"Error creating backup: {str(e)}"

# Qyrox V4.6 - Build c0c3da0a
