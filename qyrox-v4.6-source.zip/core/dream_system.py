"""
Dream System - Background Self-Improvement
Agent "bermimpi" untuk memperbaiki diri saat idle/tidur
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Dict
import random

logger = logging.getLogger(__name__)

class DreamSystem:
    """Agent dreaming and imagination system"""
    
    def __init__(self):
        self.dream_file = Path(__file__).parent.parent / "data" / "dreams.json"
        self.dreams = self._load_dreams()
        self.imagination_mode = False
    
    def _load_dreams(self) -> list:
        """Load saved dreams"""
        if self.dream_file.exists():
            try:
                with open(self.dream_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def _save_dreams(self):
        """Save dreams to file"""
        try:
            self.dream_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.dream_file, 'w', encoding='utf-8') as f:
                json.dump(self.dreams, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save dreams: {e}")
    
    def dream(self, context: dict) -> str:
        """
        Agent "bermimpi" - analyze past experiences and generate improvements
        Called during sleep or idle time
        """
        logger.info("💭 Agent is dreaming...")
        
        # Analyze recent activities
        activities = context.get('recent_activities', [])
        errors = context.get('recent_errors', [])
        successes = context.get('recent_successes', [])
        
        dream_content = {
            'timestamp': datetime.now().isoformat(),
            'type': 'improvement_dream',
            'insights': [],
            'improvements': [],
            'new_ideas': []
        }
        
        # Generate insights from errors
        if errors:
            dream_content['insights'].append({
                'category': 'error_analysis',
                'observation': f"Saya mengalami {len(errors)} error baru-baru ini",
                'learning': "Saya perlu lebih hati-hati dan validate input sebelum execute"
            })
            
            # Generate improvement ideas
            for error in errors[-3:]:  # Last 3 errors
                dream_content['improvements'].append({
                    'area': 'error_handling',
                    'idea': f"Tambahkan error handling untuk: {error.get('type', 'unknown')}",
                    'priority': 'high'
                })
        
        # Generate insights from successes
        if successes:
            dream_content['insights'].append({
                'category': 'success_pattern',
                'observation': f"Saya berhasil menyelesaikan {len(successes)} task",
                'learning': "Pattern yang berhasil bisa direplikasi untuk task serupa"
            })
        
        # Generate new ideas (imagination)
        new_ideas = self._imagine_improvements(context)
        dream_content['new_ideas'] = new_ideas
        
        # Save dream
        self.dreams.append(dream_content)
        self.dreams = self.dreams[-50:]  # Keep last 50 dreams
        self._save_dreams()
        
        logger.info(f"✓ Dream completed: {len(dream_content['insights'])} insights, {len(dream_content['improvements'])} improvements")
        
        return self._format_dream_report(dream_content)
    
    def _imagine_improvements(self, context: dict) -> List[Dict]:
        """Imagination mode - generate creative improvement ideas"""
        ideas = []
        
        # Random creative ideas
        creative_ideas = [
            {
                'category': 'efficiency',
                'idea': 'Batch similar requests untuk hemat API calls',
                'benefit': 'Reduce API usage by 30-50%'
            },
            {
                'category': 'proactivity',
                'idea': 'Predict user needs berdasarkan time of day',
                'benefit': 'More helpful and anticipatory'
            },
            {
                'category': 'learning',
                'idea': 'Create knowledge graph dari past interactions',
                'benefit': 'Better context understanding'
            },
            {
                'category': 'automation',
                'idea': 'Auto-detect repetitive tasks dan suggest automation',
                'benefit': 'Save user time'
            },
            {
                'category': 'security',
                'idea': 'Monitor unusual file access patterns',
                'benefit': 'Better security protection'
            }
        ]
        
        # Pick 2-3 random ideas
        selected = random.sample(creative_ideas, min(3, len(creative_ideas)))
        return selected
    
    def _format_dream_report(self, dream: dict) -> str:
        """Format dream into readable report"""
        report = "💭 DREAM REPORT\n"
        report += "=" * 50 + "\n\n"
        
        if dream['insights']:
            report += "📊 INSIGHTS:\n"
            for insight in dream['insights']:
                report += f"  • {insight['observation']}\n"
                report += f"    → {insight['learning']}\n\n"
        
        if dream['improvements']:
            report += "🔧 IMPROVEMENT IDEAS:\n"
            for imp in dream['improvements']:
                report += f"  • [{imp['priority'].upper()}] {imp['idea']}\n"
        
        if dream['new_ideas']:
            report += "\n💡 CREATIVE IDEAS:\n"
            for idea in dream['new_ideas']:
                report += f"  • {idea['idea']}\n"
                report += f"    Benefit: {idea['benefit']}\n\n"
        
        return report
    
    def imagine(self, prompt: str) -> str:
        """
        Imagination mode - creative thinking
        Generate alternative solutions and "what if" scenarios
        """
        logger.info(f"🎨 Imagination mode: {prompt}")
        
        imagination = {
            'timestamp': datetime.now().isoformat(),
            'type': 'imagination',
            'prompt': prompt,
            'scenarios': []
        }
        
        # Generate multiple scenarios
        scenarios = [
            {
                'scenario': 'Optimistic scenario',
                'description': 'Best case outcome dengan semua kondisi ideal',
                'approach': 'Aggressive execution dengan minimal validation'
            },
            {
                'scenario': 'Realistic scenario',
                'description': 'Balanced approach dengan proper error handling',
                'approach': 'Step-by-step dengan validation di setiap step'
            },
            {
                'scenario': 'Pessimistic scenario',
                'description': 'Worst case dengan banyak potential issues',
                'approach': 'Defensive programming dengan extensive error handling'
            },
            {
                'scenario': 'Creative scenario',
                'description': 'Out-of-the-box solution yang unconventional',
                'approach': 'Experimental approach dengan fallback plan'
            }
        ]
        
        imagination['scenarios'] = scenarios
        
        # Save imagination
        self.dreams.append(imagination)
        self._save_dreams()
        
        # Format output
        output = f"🎨 IMAGINATION MODE: {prompt}\n"
        output += "=" * 50 + "\n\n"
        
        for i, scenario in enumerate(scenarios, 1):
            output += f"{i}. {scenario['scenario'].upper()}\n"
            output += f"   {scenario['description']}\n"
            output += f"   Approach: {scenario['approach']}\n\n"
        
        return output
    
    def get_dream_journal(self, limit: int = 10) -> List[Dict]:
        """Get recent dreams"""
        return self.dreams[-limit:]
    
    def get_dream_insights(self) -> str:
        """Get summary of all dream insights"""
        if not self.dreams:
            return "Belum ada dreams. Agent perlu tidur dulu untuk bermimpi! 😴"
        
        total_insights = sum(len(d.get('insights', [])) for d in self.dreams)
        total_improvements = sum(len(d.get('improvements', [])) for d in self.dreams)
        total_ideas = sum(len(d.get('new_ideas', [])) for d in self.dreams)
        
        report = "📚 DREAM JOURNAL SUMMARY\n"
        report += "=" * 50 + "\n\n"
        report += f"Total dreams: {len(self.dreams)}\n"
        report += f"Total insights: {total_insights}\n"
        report += f"Total improvements: {total_improvements}\n"
        report += f"Total creative ideas: {total_ideas}\n\n"
        
        # Recent dreams
        report += "Recent dreams:\n"
        for dream in self.dreams[-5:]:
            timestamp = datetime.fromisoformat(dream['timestamp'])
            report += f"  • {timestamp.strftime('%Y-%m-%d %H:%M')} - {dream['type']}\n"
        
        return report

# Qyrox V4.6 - Build 97ad8e4c
