"""
Activity Monitor - Learn from User Habits
Monitor aktivitas user untuk belajar pola dan kebiasaan
"""
import psutil
import time
from datetime import datetime, timedelta
from pathlib import Path
import json
import logging
from collections import defaultdict
from typing import Dict, List

logger = logging.getLogger(__name__)

class ActivityMonitor:
    """Monitor user activity and learn patterns"""
    
    def __init__(self):
        self.activity_file = Path(__file__).parent.parent / "data" / "activity_log.json"
        self.patterns_file = Path(__file__).parent.parent / "data" / "user_patterns.json"
        self.activities = self._load_activities()
        self.patterns = self._load_patterns()
        self.monitoring = False
        self.last_check = datetime.now()
    
    def _load_activities(self) -> list:
        """Load activity log"""
        if self.activity_file.exists():
            try:
                with open(self.activity_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def _save_activities(self):
        """Save activity log"""
        try:
            self.activity_file.parent.mkdir(parents=True, exist_ok=True)
            # Keep only last 1000 activities
            with open(self.activity_file, 'w', encoding='utf-8') as f:
                json.dump(self.activities[-1000:], f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save activities: {e}")
    
    def _load_patterns(self) -> dict:
        """Load learned patterns"""
        if self.patterns_file.exists():
            try:
                with open(self.patterns_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {
            'app_usage': {},
            'time_patterns': {},
            'frequent_tasks': [],
            'predictions': []
        }
    
    def _save_patterns(self):
        """Save learned patterns"""
        try:
            self.patterns_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.patterns_file, 'w', encoding='utf-8') as f:
                json.dump(self.patterns, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save patterns: {e}")
    
    def record_activity(self, activity_type: str, details: dict):
        """Record user activity"""
        activity = {
            'timestamp': datetime.now().isoformat(),
            'type': activity_type,
            'details': details
        }
        self.activities.append(activity)
        self._save_activities()
        
        # Update patterns
        self._update_patterns(activity)
    
    def _update_patterns(self, activity: dict):
        """Update learned patterns based on activity"""
        activity_type = activity['type']
        timestamp = datetime.fromisoformat(activity['timestamp'])
        hour = timestamp.hour
        
        # Track time patterns
        if hour not in self.patterns['time_patterns']:
            self.patterns['time_patterns'][str(hour)] = []
        
        self.patterns['time_patterns'][str(hour)].append(activity_type)
        
        # Track frequent tasks
        task_key = f"{activity_type}:{activity.get('details', {}).get('task', 'unknown')}"
        found = False
        for task in self.patterns['frequent_tasks']:
            if task['key'] == task_key:
                task['count'] += 1
                task['last_seen'] = timestamp.isoformat()
                found = True
                break
        
        if not found:
            self.patterns['frequent_tasks'].append({
                'key': task_key,
                'type': activity_type,
                'count': 1,
                'first_seen': timestamp.isoformat(),
                'last_seen': timestamp.isoformat()
            })
        
        # Sort by count
        self.patterns['frequent_tasks'].sort(key=lambda x: x['count'], reverse=True)
        self.patterns['frequent_tasks'] = self.patterns['frequent_tasks'][:50]  # Keep top 50
        
        self._save_patterns()
    
    def get_active_apps(self) -> List[str]:
        """Get currently running applications"""
        apps = []
        try:
            for proc in psutil.process_iter(['name']):
                try:
                    apps.append(proc.info['name'])
                except:
                    pass
        except Exception as e:
            logger.error(f"Failed to get active apps: {e}")
        return list(set(apps))[:20]  # Top 20 unique apps
    
    def monitor_apps(self):
        """Monitor app usage"""
        apps = self.get_active_apps()
        
        for app in apps:
            if app not in self.patterns['app_usage']:
                self.patterns['app_usage'][app] = {
                    'count': 0,
                    'first_seen': datetime.now().isoformat(),
                    'last_seen': datetime.now().isoformat()
                }
            
            self.patterns['app_usage'][app]['count'] += 1
            self.patterns['app_usage'][app]['last_seen'] = datetime.now().isoformat()
        
        self._save_patterns()
    
    def predict_next_action(self) -> str:
        """Predict what user might do next based on patterns"""
        current_hour = datetime.now().hour
        
        # Get common activities at this hour
        hour_activities = self.patterns['time_patterns'].get(str(current_hour), [])
        
        if not hour_activities:
            return "Tidak ada prediksi (belum cukup data)"
        
        # Count frequency
        freq = defaultdict(int)
        for activity in hour_activities:
            freq[activity] += 1
        
        # Get most common
        if freq:
            most_common = max(freq.items(), key=lambda x: x[1])
            return f"Prediksi: User biasanya melakukan '{most_common[0]}' pada jam ini ({most_common[1]}x)"
        
        return "Tidak ada prediksi"
    
    def get_insights(self) -> str:
        """Get insights from learned patterns"""
        insights = "📊 USER ACTIVITY INSIGHTS\n"
        insights += "=" * 50 + "\n\n"
        
        # Total activities
        insights += f"Total activities tracked: {len(self.activities)}\n\n"
        
        # Most used apps
        if self.patterns['app_usage']:
            top_apps = sorted(
                self.patterns['app_usage'].items(),
                key=lambda x: x[1]['count'],
                reverse=True
            )[:5]
            
            insights += "🔥 Most Used Apps:\n"
            for app, data in top_apps:
                insights += f"  • {app}: {data['count']} times\n"
            insights += "\n"
        
        # Frequent tasks
        if self.patterns['frequent_tasks']:
            insights += "📋 Frequent Tasks:\n"
            for task in self.patterns['frequent_tasks'][:5]:
                insights += f"  • {task['type']}: {task['count']}x\n"
            insights += "\n"
        
        # Time patterns
        if self.patterns['time_patterns']:
            insights += "⏰ Activity by Hour:\n"
            for hour in sorted(self.patterns['time_patterns'].keys(), key=int):
                count = len(self.patterns['time_patterns'][hour])
                insights += f"  • {hour}:00 - {count} activities\n"
            insights += "\n"
        
        # Prediction
        prediction = self.predict_next_action()
        insights += f"🔮 {prediction}\n"
        
        return insights
    
    def get_proactive_suggestions(self) -> List[str]:
        """Generate proactive suggestions based on patterns"""
        suggestions = []
        current_hour = datetime.now().hour
        
        # Based on time patterns
        hour_activities = self.patterns['time_patterns'].get(str(current_hour), [])
        if hour_activities:
            most_common = max(set(hour_activities), key=hour_activities.count)
            suggestions.append(f"Biasanya jam segini Anda {most_common}. Perlu bantuan?")
        
        # Based on frequent tasks
        if self.patterns['frequent_tasks']:
            top_task = self.patterns['frequent_tasks'][0]
            suggestions.append(f"Anda sering melakukan '{top_task['type']}'. Mau saya automate?")
        
        return suggestions
    
    def start_monitoring(self):
        """Start background monitoring"""
        self.monitoring = True
        logger.info("✓ Activity monitoring started")
    
    def stop_monitoring(self):
        """Stop monitoring"""
        self.monitoring = False
        logger.info("✓ Activity monitoring stopped")
    
    def get_recent_activities(self, limit: int = 10) -> List[Dict]:
        """Get recent activities"""
        return self.activities[-limit:]

# Qyrox V4.6 - Build a3703369
