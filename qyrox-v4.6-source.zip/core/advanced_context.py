import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
import hashlib

@dataclass
class ContextChunk:
    """A chunk of context with metadata"""
    chunk_id: str
    content: str
    relevance_score: float  # 0.0 - 1.0
    importance: str  # critical, high, medium, low
    category: str  # conversation, system, memory, knowledge
    timestamp: str
    token_count: int
    access_count: int = 0
    last_accessed: Optional[str] = None
    
    def __post_init__(self):
        if not self.chunk_id:
            self.chunk_id = hashlib.md5(self.content.encode()).hexdigest()[:16]

class AdvancedContextManager:
    """Intelligent context management with compression and retrieval"""
    
    def __init__(self, data_dir: Path, max_tokens: int = 4000):
        self.data_dir = data_dir
        self.max_tokens = max_tokens
        self.context_file = data_dir / "advanced_context.json"
        
        # Context storage
        self.chunks: List[ContextChunk] = []
        self.summaries: Dict[str, str] = {}  # Compressed summaries
        
        # Configuration
        self.compression_ratio = 0.3  # Target 70% reduction
        self.relevance_threshold = 0.5
        
        self._load_context()
    
    def _load_context(self):
        """Load context from disk"""
        if self.context_file.exists():
            try:
                with open(self.context_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.chunks = [
                        ContextChunk(**chunk) for chunk in data.get('chunks', [])
                    ]
                    self.summaries = data.get('summaries', {})
            except:
                pass
    
    def _save_context(self):
        """Save context to disk"""
        try:
            data = {
                'chunks': [vars(chunk) for chunk in self.chunks],
                'summaries': self.summaries,
                'last_updated': datetime.now().isoformat()
            }
            with open(self.context_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        except:
            pass
    
    def add_context(self, content: str, importance: str = "medium",
                   category: str = "conversation") -> ContextChunk:
        """Add new context"""
        chunk = ContextChunk(
            chunk_id="",
            content=content,
            relevance_score=1.0,  # New content is always relevant
            importance=importance,
            category=category,
            timestamp=datetime.now().isoformat(),
            token_count=len(content.split())  # Rough estimate
        )
        
        self.chunks.append(chunk)
        self._save_context()
        
        # Trigger compression if needed
        if self._get_total_tokens() > self.max_tokens:
            self._compress_context()
        
        return chunk
    
    def _get_total_tokens(self) -> int:
        """Get total token count"""
        return sum(chunk.token_count for chunk in self.chunks)
    
    def _compress_context(self):
        """Compress context to reduce token usage"""
        # Step 1: Remove low-relevance chunks
        self.chunks = [
            chunk for chunk in self.chunks
            if chunk.relevance_score >= self.relevance_threshold or
            chunk.importance == "critical"
        ]
        
        # Step 2: Summarize old conversations
        old_chunks = [
            chunk for chunk in self.chunks
            if self._is_old(chunk) and chunk.category == "conversation"
        ]
        
        if old_chunks:
            summary = self._create_summary(old_chunks)
            self.summaries[f"summary_{datetime.now().timestamp()}"] = summary
            
            # Remove summarized chunks
            summarized_ids = {chunk.chunk_id for chunk in old_chunks}
            self.chunks = [
                chunk for chunk in self.chunks
                if chunk.chunk_id not in summarized_ids
            ]
        
        # Step 3: Decay relevance scores over time
        self._decay_relevance()
        
        self._save_context()
    
    def _is_old(self, chunk: ContextChunk, hours: int = 24) -> bool:
        """Check if chunk is old"""
        try:
            chunk_time = datetime.fromisoformat(chunk.timestamp)
            return datetime.now() - chunk_time > timedelta(hours=hours)
        except:
            return False
    
    def _create_summary(self, chunks: List[ContextChunk]) -> str:
        """Create summary of multiple chunks"""
        # Simple concatenation for now
        # In production, use LLM to create intelligent summary
        contents = [chunk.content for chunk in chunks]
        return f"Summary of {len(chunks)} interactions: " + " | ".join(contents[:3])
    
    def _decay_relevance(self):
        """Decay relevance scores over time"""
        for chunk in self.chunks:
            if self._is_old(chunk, hours=12):
                chunk.relevance_score *= 0.9  # 10% decay
    
    def get_relevant_context(self, query: str, max_tokens: int = None) -> str:
        """Get most relevant context for a query"""
        if max_tokens is None:
            max_tokens = self.max_tokens
        
        # Score chunks by relevance to query
        scored_chunks = []
        for chunk in self.chunks:
            score = self._calculate_relevance(query, chunk)
            scored_chunks.append((score, chunk))
        
        # Sort by score (descending)
        scored_chunks.sort(reverse=True, key=lambda x: x[0])
        
        # Build context within token limit
        context_parts = []
        current_tokens = 0
        
        # Always include summaries first (compressed knowledge)
        for summary in self.summaries.values():
            summary_tokens = len(summary.split())
            if current_tokens + summary_tokens <= max_tokens:
                context_parts.append(summary)
                current_tokens += summary_tokens
        
        # Add relevant chunks
        for score, chunk in scored_chunks:
            if current_tokens + chunk.token_count <= max_tokens:
                context_parts.append(chunk.content)
                current_tokens += chunk.token_count
                
                # Update access stats
                chunk.access_count += 1
                chunk.last_accessed = datetime.now().isoformat()
            else:
                break
        
        self._save_context()
        return "\n\n".join(context_parts)
    
    def _calculate_relevance(self, query: str, chunk: ContextChunk) -> float:
        """Calculate relevance score between query and chunk"""
        # Simple keyword matching for now
        # In production, use embeddings for semantic similarity
        
        query_words = set(query.lower().split())
        chunk_words = set(chunk.content.lower().split())
        
        # Jaccard similarity
        intersection = query_words & chunk_words
        union = query_words | chunk_words
        
        similarity = len(intersection) / len(union) if union else 0
        
        # Boost by importance
        importance_boost = {
            "critical": 1.5,
            "high": 1.2,
            "medium": 1.0,
            "low": 0.8
        }
        
        # Boost by recency
        recency_boost = 1.0
        if not self._is_old(chunk, hours=1):
            recency_boost = 1.3
        elif not self._is_old(chunk, hours=6):
            recency_boost = 1.1
        
        # Boost by access frequency
        frequency_boost = min(1.0 + (chunk.access_count * 0.1), 1.5)
        
        final_score = (
            similarity * 
            importance_boost.get(chunk.importance, 1.0) *
            recency_boost *
            frequency_boost *
            chunk.relevance_score
        )
        
        return final_score
    
    def get_context_stats(self) -> Dict:
        """Get context statistics"""
        total_tokens = self._get_total_tokens()
        
        by_category = {}
        by_importance = {}
        
        for chunk in self.chunks:
            by_category[chunk.category] = by_category.get(chunk.category, 0) + 1
            by_importance[chunk.importance] = by_importance.get(chunk.importance, 0) + 1
        
        return {
            "total_chunks": len(self.chunks),
            "total_summaries": len(self.summaries),
            "total_tokens": total_tokens,
            "max_tokens": self.max_tokens,
            "usage_percentage": (total_tokens / self.max_tokens) * 100,
            "by_category": by_category,
            "by_importance": by_importance,
            "compression_ratio": self.compression_ratio,
            "avg_relevance": sum(c.relevance_score for c in self.chunks) / len(self.chunks) if self.chunks else 0
        }
    
    def prune_context(self, keep_critical: bool = True):
        """Manually prune context"""
        if keep_critical:
            self.chunks = [
                chunk for chunk in self.chunks
                if chunk.importance == "critical"
            ]
        else:
            self.chunks = []
        
        self.summaries = {}
        self._save_context()
    
    def search_context(self, query: str, limit: int = 10) -> List[ContextChunk]:
        """Search context by query"""
        scored_chunks = [
            (self._calculate_relevance(query, chunk), chunk)
            for chunk in self.chunks
        ]
        
        scored_chunks.sort(reverse=True, key=lambda x: x[0])
        return [chunk for score, chunk in scored_chunks[:limit]]
    
    def get_context_summary(self) -> str:
        """Get overall context summary"""
        stats = self.get_context_stats()
        
        return f"""
📊 Advanced Context Status:
- Total Chunks: {stats['total_chunks']}
- Total Summaries: {stats['total_summaries']}
- Token Usage: {stats['total_tokens']}/{stats['max_tokens']} ({stats['usage_percentage']:.1f}%)
- Avg Relevance: {stats['avg_relevance']:.2f}
- Compression: {self.compression_ratio*100:.0f}% target reduction

By Category: {stats['by_category']}
By Importance: {stats['by_importance']}
"""

# Qyrox V4.6 - Build 88ceae4b
