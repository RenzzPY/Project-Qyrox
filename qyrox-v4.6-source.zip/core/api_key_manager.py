"""
API Key Manager - Secure storage and retrieval of API keys
"""
import os
import json
from pathlib import Path
from typing import Dict, Optional
from cryptography.fernet import Fernet
import logging

logger = logging.getLogger(__name__)

class APIKeyManager:
    """Manage API keys securely with encryption"""
    
    def __init__(self, key_file: Path = None, encryption_key_file: Path = None):
        """
        Initialize API Key Manager
        
        Args:
            key_file: Path to encrypted keys file (default: data/api_keys.enc)
            encryption_key_file: Path to encryption key (default: .key - should be in .gitignore)
        """
        self.key_file = key_file or Path("data/api_keys.enc")
        self.encryption_key_file = encryption_key_file or Path(".key")
        self.cipher = None
        self._init_encryption()
    
    def _init_encryption(self):
        """Initialize encryption cipher"""
        try:
            # Try to load existing key
            if self.encryption_key_file.exists():
                with open(self.encryption_key_file, 'rb') as f:
                    key = f.read()
            else:
                # Generate new key
                key = Fernet.generate_key()
                self.encryption_key_file.parent.mkdir(parents=True, exist_ok=True)
                with open(self.encryption_key_file, 'wb') as f:
                    f.write(key)
                logger.info(f"Generated new encryption key at {self.encryption_key_file}")
            
            self.cipher = Fernet(key)
        except Exception as e:
            logger.error(f"Failed to initialize encryption: {e}")
            raise
    
    def save_keys(self, keys: Dict[str, str]):
        """
        Save API keys encrypted
        
        Args:
            keys: Dictionary of API keys {provider: key}
        """
        try:
            # Convert to JSON
            json_data = json.dumps(keys)
            
            # Encrypt
            encrypted_data = self.cipher.encrypt(json_data.encode())
            
            # Save
            self.key_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.key_file, 'wb') as f:
                f.write(encrypted_data)
            
            logger.info(f"Saved {len(keys)} API keys securely")
        except Exception as e:
            logger.error(f"Failed to save keys: {e}")
            raise
    
    def load_keys(self) -> Dict[str, str]:
        """
        Load and decrypt API keys
        
        Returns:
            Dictionary of API keys {provider: key}
        """
        try:
            if not self.key_file.exists():
                logger.warning(f"Key file not found: {self.key_file}")
                return {}
            
            # Read encrypted data
            with open(self.key_file, 'rb') as f:
                encrypted_data = f.read()
            
            # Decrypt
            decrypted_data = self.cipher.decrypt(encrypted_data)
            
            # Parse JSON
            keys = json.loads(decrypted_data.decode())
            
            logger.info(f"Loaded {len(keys)} API keys")
            return keys
        except Exception as e:
            logger.error(f"Failed to load keys: {e}")
            return {}
    
    def get_key(self, provider: str) -> Optional[str]:
        """
        Get API key for specific provider
        
        Args:
            provider: Provider name (e.g., 'groq', 'google', 'openrouter')
        
        Returns:
            API key or None if not found
        """
        keys = self.load_keys()
        return keys.get(provider)
    
    def set_key(self, provider: str, key: str):
        """
        Set API key for specific provider
        
        Args:
            provider: Provider name
            key: API key
        """
        keys = self.load_keys()
        keys[provider] = key
        self.save_keys(keys)
    
    def migrate_from_plaintext(self, plaintext_file: Path):
        """
        Migrate from old plaintext api_key.txt format
        
        Args:
            plaintext_file: Path to old api_key.txt
        """
        try:
            if not plaintext_file.exists():
                logger.warning(f"Plaintext file not found: {plaintext_file}")
                return
            
            keys = {}
            with open(plaintext_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    if '=' in line:
                        provider, key = line.split('=', 1)
                        keys[provider.strip().lower()] = key.strip()
            
            if keys:
                self.save_keys(keys)
                logger.info(f"Migrated {len(keys)} keys from plaintext")
                
                # Backup old file
                backup_file = plaintext_file.with_suffix('.txt.bak')
                plaintext_file.rename(backup_file)
                logger.info(f"Backed up old file to {backup_file}")
            
        except Exception as e:
            logger.error(f"Failed to migrate keys: {e}")
            raise
    
    @staticmethod
    def from_env() -> Dict[str, str]:
        """
        Load API keys from environment variables
        
        Returns:
            Dictionary of API keys found in environment
        """
        keys = {}
        env_vars = {
            'GROQ_API_KEY': 'groq',
            'GOOGLE_API_KEY': 'google',
            'OPENROUTER_API_KEY': 'openrouter',
            'ANTHROPIC_API_KEY': 'anthropic',
        }
        
        for env_var, provider in env_vars.items():
            value = os.getenv(env_var)
            if value:
                keys[provider] = value
        
        return keys


# Convenience function for backward compatibility
def load_api_keys() -> Dict[str, str]:
    """
    Load API keys with fallback priority:
    1. Environment variables
    2. Encrypted file
    3. Plaintext file (legacy)
    
    Returns:
        Dictionary of API keys
    """
    # Try environment variables first
    keys = APIKeyManager.from_env()
    if keys:
        logger.info(f"Loaded {len(keys)} keys from environment")
        return keys
    
    # Try encrypted file
    manager = APIKeyManager()
    keys = manager.load_keys()
    if keys:
        return keys
    
    # Try plaintext file (legacy)
    plaintext_file = Path("api_key.txt")
    if plaintext_file.exists():
        logger.warning("Using legacy plaintext API keys. Consider migrating to encrypted storage.")
        try:
            with open(plaintext_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    if '=' in line:
                        provider, key = line.split('=', 1)
                        keys[provider.strip().lower()] = key.strip()
        except Exception as e:
            logger.error(f"Failed to load plaintext keys: {e}")
    
    return keys

# Qyrox V4.6 - Build 48a19bb4
