"""
Semantic Cache - Hemat API dengan caching berbasis makna
"""
import json
import hashlib
from pathlib import Path
from typing import Optional, Dict
import sys
sys.path.append(str(Path(__file__).parent.parent))
from config import Config
import logging

logger = logging.getLogger(__name__)

class SemanticCache:
    def __init__(self):
        self.cache_dir = Path(Config.CACHE_DIR)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.cache_file = self.cache_dir / "semantic_cache.json"
        self.cache_data = self._load_cache()
    
    def _load_cache(self) -> Dict:
        """Load cache dari file"""
        if self.cache_file.exists():
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_cache(self):
        """Simpan cache ke file"""
        with open(self.cache_file, 'w', encoding='utf-8') as f:
            json.dump(self.cache_data, f, ensure_ascii=False, indent=2)
    
    def _get_hash(self, text: str) -> str:
        """Generate hash dari text"""
        return hashlib.md5(text.encode()).hexdigest()
    
    def get(self, query: str) -> Optional[str]:
        """Cari di cache berdasarkan similarity"""
        query_hash = self._get_hash(query)
        
        # Exact match
        if query_hash in self.cache_data:
            logger.info("✓ Cache hit (exact)")
            return self.cache_data[query_hash]["response"]
        
        # Semantic similarity (simplified)
        for cached_hash, cached_item in self.cache_data.items():
            if self._is_similar(query, cached_item["query"]):
                logger.info("✓ Cache hit (semantic)")
                return cached_item["response"]
        
        return None
    
    def set(self, query: str, response: str):
        """Simpan ke cache"""
        query_hash = self._get_hash(query)
        self.cache_data[query_hash] = {
            "query": query,
            "response": response
        }
        self._save_cache()
        logger.info("✓ Cached new response")
    
    def _is_similar(self, text1: str, text2: str) -> bool:
        """Check similarity (simplified - word overlap)"""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return False
        
        overlap = len(words1.intersection(words2))
        similarity = overlap / max(len(words1), len(words2))
        
        return similarity >= Config.SEMANTIC_CACHE_THRESHOLD

# Qyrox V4.6 - Build ceb2ce31
