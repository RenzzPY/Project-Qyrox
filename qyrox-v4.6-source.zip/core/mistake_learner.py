"""
Mistake Learner - Learn from Errors
Track errors dan never repeat same mistake
"""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import hashlib

logger = logging.getLogger(__name__)

class MistakeLearner:
    """Learn from mistakes and never repeat them"""
    
    def __init__(self):
        self.mistakes_file = Path(__file__).parent.parent / "data" / "mistakes.json"
        self.solutions_file = Path(__file__).parent.parent / "data" / "solutions.json"
        self.mistakes = self._load_mistakes()
        self.solutions = self._load_solutions()
    
    def _load_mistakes(self) -> list:
        """Load mistake history"""
        if self.mistakes_file.exists():
            try:
                with open(self.mistakes_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def _save_mistakes(self):
        """Save mistakes"""
        try:
            self.mistakes_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.mistakes_file, 'w', encoding='utf-8') as f:
                json.dump(self.mistakes, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save mistakes: {e}")
    
    def _load_solutions(self) -> dict:
        """Load known solutions"""
        if self.solutions_file.exists():
            try:
                with open(self.solutions_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def _save_solutions(self):
        """Save solutions"""
        try:
            self.solutions_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.solutions_file, 'w', encoding='utf-8') as f:
                json.dump(self.solutions, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save solutions: {e}")
    
    def _get_error_signature(self, error: str, context: dict) -> str:
        """Generate unique signature for error"""
        # Combine error message and context
        signature_str = f"{error}:{json.dumps(context, sort_keys=True)}"
        return hashlib.md5(signature_str.encode()).hexdigest()
    
    def record_mistake(self, error: str, context: dict, severity: str = "medium"):
        """Record a mistake"""
        signature = self._get_error_signature(error, context)
        
        # Check if already recorded
        for mistake in self.mistakes:
            if mistake['signature'] == signature:
                mistake['count'] += 1
                mistake['last_occurrence'] = datetime.now().isoformat()
                self._save_mistakes()
                logger.warning(f"⚠️ Repeated mistake: {error} (count: {mistake['count']})")
                return mistake
        
        # New mistake
        mistake = {
            'signature': signature,
            'error': error,
            'context': context,
            'severity': severity,
            'count': 1,
            'first_occurrence': datetime.now().isoformat(),
            'last_occurrence': datetime.now().isoformat(),
            'solved': False,
            'solution': None
        }
        
        self.mistakes.append(mistake)
        self._save_mistakes()
        logger.info(f"📝 New mistake recorded: {error}")
        
        return mistake
    
    def add_solution(self, error_signature: str, solution: str, verified: bool = False):
        """Add solution for an error"""
        # Update mistake
        for mistake in self.mistakes:
            if mistake['signature'] == error_signature:
                mistake['solved'] = True
                mistake['solution'] = solution
                mistake['solution_verified'] = verified
                mistake['solution_added'] = datetime.now().isoformat()
                break
        
        # Add to solutions database
        self.solutions[error_signature] = {
            'solution': solution,
            'verified': verified,
            'added': datetime.now().isoformat(),
            'used_count': 0
        }
        
        self._save_mistakes()
        self._save_solutions()
        logger.info(f"✓ Solution added for error: {error_signature[:8]}...")
    
    def get_solution(self, error: str, context: dict) -> Optional[Dict]:
        """Get solution for an error"""
        signature = self._get_error_signature(error, context)
        
        if signature in self.solutions:
            solution = self.solutions[signature]
            solution['used_count'] += 1
            self._save_solutions()
            logger.info(f"💡 Found solution for error: {error}")
            return solution
        
        return None
    
    def has_seen_before(self, error: str, context: dict) -> bool:
        """Check if error has been seen before"""
        signature = self._get_error_signature(error, context)
        return any(m['signature'] == signature for m in self.mistakes)
    
    def get_mistake_stats(self) -> str:
        """Get mistake statistics"""
        stats = "📊 MISTAKE LEARNING STATS\n"
        stats += "=" * 50 + "\n\n"
        
        total_mistakes = len(self.mistakes)
        total_occurrences = sum(m['count'] for m in self.mistakes)
        solved_mistakes = sum(1 for m in self.mistakes if m['solved'])
        
        stats += f"Total unique mistakes: {total_mistakes}\n"
        stats += f"Total occurrences: {total_occurrences}\n"
        stats += f"Solved mistakes: {solved_mistakes}\n"
        stats += f"Unsolved mistakes: {total_mistakes - solved_mistakes}\n\n"
        
        # Most common mistakes
        if self.mistakes:
            sorted_mistakes = sorted(self.mistakes, key=lambda x: x['count'], reverse=True)
            stats += "🔥 Most Common Mistakes:\n"
            for mistake in sorted_mistakes[:5]:
                status = "✅ SOLVED" if mistake['solved'] else "❌ UNSOLVED"
                stats += f"  • {mistake['error'][:50]}... ({mistake['count']}x) [{status}]\n"
            stats += "\n"
        
        # Recent mistakes
        if self.mistakes:
            recent = sorted(self.mistakes, key=lambda x: x['last_occurrence'], reverse=True)[:5]
            stats += "⏰ Recent Mistakes:\n"
            for mistake in recent:
                timestamp = datetime.fromisoformat(mistake['last_occurrence'])
                stats += f"  • {mistake['error'][:50]}...\n"
                stats += f"    {timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"
        
        return stats
    
    def get_learning_insights(self) -> List[str]:
        """Get insights from mistakes"""
        insights = []
        
        # Repeated mistakes
        repeated = [m for m in self.mistakes if m['count'] > 3 and not m['solved']]
        if repeated:
            insights.append(f"⚠️ {len(repeated)} mistakes repeated >3 times without solution")
        
        # Unsolved critical mistakes
        critical_unsolved = [m for m in self.mistakes if m['severity'] == 'critical' and not m['solved']]
        if critical_unsolved:
            insights.append(f"🚨 {len(critical_unsolved)} critical mistakes still unsolved")
        
        # Success rate
        if self.mistakes:
            solve_rate = (sum(1 for m in self.mistakes if m['solved']) / len(self.mistakes)) * 100
            insights.append(f"✅ Solution rate: {solve_rate:.1f}%")
        
        return insights
    
    def suggest_improvements(self) -> List[str]:
        """Suggest improvements based on mistakes"""
        suggestions = []
        
        # Analyze patterns
        error_types = {}
        for mistake in self.mistakes:
            error_type = mistake['error'].split(':')[0] if ':' in mistake['error'] else 'Unknown'
            error_types[error_type] = error_types.get(error_type, 0) + 1
        
        # Suggest based on most common error types
        if error_types:
            most_common = max(error_types.items(), key=lambda x: x[1])
            suggestions.append(f"Focus on preventing '{most_common[0]}' errors ({most_common[1]} occurrences)")
        
        # Suggest for unsolved mistakes
        unsolved = [m for m in self.mistakes if not m['solved']]
        if unsolved:
            suggestions.append(f"Research solutions for {len(unsolved)} unsolved mistakes")
        
        return suggestions
    
    def export_knowledge_base(self) -> Dict:
        """Export mistake knowledge base"""
        return {
            'mistakes': self.mistakes,
            'solutions': self.solutions,
            'stats': {
                'total_mistakes': len(self.mistakes),
                'total_solutions': len(self.solutions),
                'solve_rate': (len(self.solutions) / len(self.mistakes) * 100) if self.mistakes else 0
            },
            'exported_at': datetime.now().isoformat()
        }

# Qyrox V4.6 - Build fea3538d
