"""
Sleep/Rest System - Smart API Limit Management
Agent bisa "tidur" untuk menunggu API limit reset
"""
import time
from datetime import datetime, timedelta
import logging
import json
from pathlib import Path

logger = logging.getLogger(__name__)

class SleepSystem:
    """Manage agent sleep/rest for API limit management"""
    
    def __init__(self):
        self.sleep_file = Path(__file__).parent.parent / "data" / "sleep_state.json"
        self.is_sleeping = False
        self.wake_up_time = None
        self.sleep_reason = None
        
        # API limits (per provider)
        self.api_limits = {
            'groq': {
                'rpm': 30,      # requests per minute
                'rph': 14400,   # requests per hour
                'rpd': 14400    # requests per day
            },
            'google': {
                'rpm': 15,
                'rph': 1500,
                'rpd': 1500
            },
            'openrouter': {
                'rpm': 20,
                'rph': 200,
                'rpd': 200
            }
        }
        
        self._load_sleep_state()
    
    def _load_sleep_state(self):
        """Load sleep state from file"""
        if self.sleep_file.exists():
            try:
                with open(self.sleep_file, 'r') as f:
                    state = json.load(f)
                    self.is_sleeping = state.get('is_sleeping', False)
                    wake_time = state.get('wake_up_time')
                    if wake_time:
                        self.wake_up_time = datetime.fromisoformat(wake_time)
                    self.sleep_reason = state.get('sleep_reason')
                    
                    # Check if should wake up
                    if self.is_sleeping and self.wake_up_time:
                        if datetime.now() >= self.wake_up_time:
                            self.wake_up()
            except Exception as e:
                logger.error(f"Failed to load sleep state: {e}")
    
    def _save_sleep_state(self):
        """Save sleep state to file"""
        try:
            self.sleep_file.parent.mkdir(parents=True, exist_ok=True)
            state = {
                'is_sleeping': self.is_sleeping,
                'wake_up_time': self.wake_up_time.isoformat() if self.wake_up_time else None,
                'sleep_reason': self.sleep_reason,
                'last_updated': datetime.now().isoformat()
            }
            with open(self.sleep_file, 'w') as f:
                json.dump(state, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save sleep state: {e}")
    
    def should_sleep(self, api_usage: dict) -> tuple[bool, str, int]:
        """
        Check if agent should sleep based on API usage
        Returns: (should_sleep, reason, sleep_duration_seconds)
        """
        for provider, usage in api_usage.items():
            if provider not in self.api_limits:
                continue
            
            limits = self.api_limits[provider]
            
            # Check RPM (requests per minute)
            if usage.get('requests_last_minute', 0) >= limits['rpm'] * 0.9:  # 90% threshold
                sleep_time = 60  # Sleep 1 minute
                reason = f"API {provider} mendekati limit RPM ({usage['requests_last_minute']}/{limits['rpm']})"
                return True, reason, sleep_time
            
            # Check RPH (requests per hour)
            if usage.get('requests_last_hour', 0) >= limits['rph'] * 0.9:
                sleep_time = 3600  # Sleep 1 hour
                reason = f"API {provider} mendekati limit RPH ({usage['requests_last_hour']}/{limits['rph']})"
                return True, reason, sleep_time
            
            # Check RPD (requests per day)
            if usage.get('requests_today', 0) >= limits['rpd'] * 0.9:
                # Calculate time until midnight
                now = datetime.now()
                midnight = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                sleep_time = int((midnight - now).total_seconds())
                reason = f"API {provider} mendekati limit RPD ({usage['requests_today']}/{limits['rpd']})"
                return True, reason, sleep_time
        
        return False, "", 0
    
    def go_to_sleep(self, duration_seconds: int, reason: str):
        """Put agent to sleep"""
        self.is_sleeping = True
        self.wake_up_time = datetime.now() + timedelta(seconds=duration_seconds)
        self.sleep_reason = reason
        self._save_sleep_state()
        
        hours = duration_seconds // 3600
        minutes = (duration_seconds % 3600) // 60
        seconds = duration_seconds % 60
        
        time_str = ""
        if hours > 0:
            time_str += f"{hours} jam "
        if minutes > 0:
            time_str += f"{minutes} menit "
        if seconds > 0 or not time_str:
            time_str += f"{seconds} detik"
        
        logger.info(f"😴 Agent going to sleep for {time_str}")
        logger.info(f"💤 Reason: {reason}")
        logger.info(f"⏰ Will wake up at: {self.wake_up_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        return f"""😴 AGENT TIDUR / ISTIRAHAT

Alasan: {reason}
Durasi: {time_str}
Bangun jam: {self.wake_up_time.strftime('%H:%M:%S')}

Saya akan tidur dulu untuk menunggu API limit reset.
Saat bangun nanti, saya akan fresh dan siap bekerja lagi! 💪

Anda bisa:
- Tunggu saya bangun otomatis
- Atau ketik /wake untuk bangunkan saya paksa (emergency)
"""
    
    def wake_up(self, forced: bool = False):
        """Wake up agent"""
        if not self.is_sleeping:
            return "Agent sudah bangun!"
        
        self.is_sleeping = False
        reason = "dipaksa bangun" if forced else "waktu tidur selesai"
        
        logger.info(f"☀️ Agent waking up ({reason})")
        
        self.wake_up_time = None
        self.sleep_reason = None
        self._save_sleep_state()
        
        return f"""☀️ AGENT BANGUN!

Saya sudah bangun dan siap bekerja lagi! 💪
API limits sudah reset, saya bisa bekerja optimal sekarang.

Status: ACTIVE ✅
"""
    
    def get_sleep_status(self) -> str:
        """Get current sleep status"""
        if not self.is_sleeping:
            return "Status: ACTIVE ✅ (Agent sedang bangun dan siap bekerja)"
        
        if self.wake_up_time:
            remaining = self.wake_up_time - datetime.now()
            if remaining.total_seconds() <= 0:
                self.wake_up()
                return self.get_sleep_status()
            
            hours = int(remaining.total_seconds() // 3600)
            minutes = int((remaining.total_seconds() % 3600) // 60)
            seconds = int(remaining.total_seconds() % 60)
            
            time_str = ""
            if hours > 0:
                time_str += f"{hours} jam "
            if minutes > 0:
                time_str += f"{minutes} menit "
            if seconds > 0 or not time_str:
                time_str += f"{seconds} detik"
            
            return f"""😴 AGENT SEDANG TIDUR

Alasan: {self.sleep_reason}
Sisa waktu: {time_str}
Bangun jam: {self.wake_up_time.strftime('%H:%M:%S')}

Ketik /wake untuk bangunkan paksa (emergency only!)
"""
        
        return "Status: SLEEPING 😴"
    
    def check_and_sleep_if_needed(self, api_usage: dict) -> str:
        """Check API usage and sleep if needed"""
        should_sleep, reason, duration = self.should_sleep(api_usage)
        
        if should_sleep:
            return self.go_to_sleep(duration, reason)
        
        return ""
    
    def get_time_until_wake(self) -> int:
        """Get seconds until wake up (0 if not sleeping)"""
        if not self.is_sleeping or not self.wake_up_time:
            return 0
        
        remaining = self.wake_up_time - datetime.now()
        return max(0, int(remaining.total_seconds()))

# Qyrox V4.6 - Build db553068
