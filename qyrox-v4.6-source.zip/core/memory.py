"""
Memory System - Long-term & Short-term memory untuk super agent
"""
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict
import sys
sys.path.append(str(Path(__file__).parent.parent))
from config import Config
import logging

logger = logging.getLogger(__name__)

class Memory:
    def __init__(self):
        self.memory_dir = Path(Config.MEMORY_DIR)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        
        self.short_term_file = self.memory_dir / "short_term.json"
        self.long_term_file = self.memory_dir / "long_term.json"
        self.goals_file = self.memory_dir / "goals.json"
        
        self.short_term = self._load_memory(self.short_term_file)
        self.long_term = self._load_memory(self.long_term_file)
        self.goals = self._load_memory(self.goals_file)
    
    def _load_memory(self, file_path: Path) -> List[Dict]:
        """Load memory dari file"""
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def _save_memory(self, data: List[Dict], file_path: Path):
        """Simpan memory ke file"""
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def add_short_term(self, content: str, metadata: Dict = None):
        """Tambah ke short-term memory"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "content": content,
            "metadata": metadata or {}
        }
        self.short_term.append(entry)
        
        # Keep only last 50 entries
        if len(self.short_term) > 50:
            self.short_term = self.short_term[-50:]
        
        self._save_memory(self.short_term, self.short_term_file)
        logger.info("✓ Added to short-term memory")
    
    def add_long_term(self, content: str, category: str = "general"):
        """Tambah ke long-term memory"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "content": content,
            "category": category
        }
        self.long_term.append(entry)
        self._save_memory(self.long_term, self.long_term_file)
        logger.info(f"✓ Added to long-term memory ({category})")
    
    def add_goal(self, goal: str, priority: str = "medium"):
        """Tambah goal baru"""
        entry = {
            "id": len(self.goals) + 1,
            "goal": goal,
            "priority": priority,
            "status": "active",
            "created_at": datetime.now().isoformat()
        }
        self.goals.append(entry)
        self._save_memory(self.goals, self.goals_file)
        logger.info(f"✓ New goal added: {goal}")
    
    def get_active_goals(self) -> List[Dict]:
        """Dapatkan semua goal yang aktif"""
        return [g for g in self.goals if g.get("status") == "active"]
    
    def get_context(self, limit: int = 10) -> str:
        """Dapatkan context dari memory untuk prompt"""
        recent = self.short_term[-limit:] if self.short_term else []
        active_goals = self.get_active_goals()
        
        context = "=== CONTEXT ===\n"
        
        if active_goals:
            context += "\nActive Goals:\n"
            for goal in active_goals[:3]:
                context += f"- [{goal['priority']}] {goal['goal']}\n"
        
        if recent:
            context += "\nRecent Interactions:\n"
            for entry in recent:
                context += f"- {entry['content'][:100]}...\n"
        
        return context

# Qyrox V4.6 - Build 17716745
