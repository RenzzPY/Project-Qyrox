import time
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from pathlib import Path
import sys

# Add parent directory to path for config import
sys.path.append(str(Path(__file__).parent.parent))
from config import Config

class IntelligentLimiter:
    """Smart API rate limiter with predictive throttling"""
    
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.stats_file = data_dir / "api_stats.json"
        
        # Load rate limits from config
        self.limits = Config.RATE_LIMITS
        
        # Request tracking
        self.requests: List[Dict] = []
        self.tokens_used: List[Dict] = []
        
        # Adaptive settings
        self.adaptive_delay = 1.0  # seconds
        self.burst_mode = False
        self.throttle_level = 0  # 0-5
        
        # Auto-sleep settings
        self.auto_sleep_enabled = Config.AUTO_SLEEP_ON_LIMIT
        self.auto_sleep_threshold = Config.AUTO_SLEEP_THRESHOLD
        
        self._load_stats()
    
    def _load_stats(self):
        """Load API usage statistics"""
        if self.stats_file.exists():
            try:
                with open(self.stats_file, 'r') as f:
                    data = json.load(f)
                    self.requests = data.get('requests', [])
                    self.tokens_used = data.get('tokens', [])
                    self.adaptive_delay = data.get('adaptive_delay', 1.0)
            except:
                pass
    
    def _save_stats(self):
        """Save API usage statistics"""
        try:
            with open(self.stats_file, 'w') as f:
                json.dump({
                    'requests': self.requests[-1000:],  # Keep last 1000
                    'tokens': self.tokens_used[-1000:],
                    'adaptive_delay': self.adaptive_delay,
                    'last_updated': datetime.now().isoformat()
                }, f, indent=2)
        except:
            pass
    
    def _clean_old_records(self):
        """Remove records older than 24 hours"""
        cutoff = datetime.now() - timedelta(hours=24)
        cutoff_str = cutoff.isoformat()
        
        self.requests = [r for r in self.requests if r['timestamp'] > cutoff_str]
        self.tokens_used = [t for t in self.tokens_used if t['timestamp'] > cutoff_str]
    
    def _get_usage(self, timeframe: str) -> Dict:
        """Get usage statistics for timeframe"""
        now = datetime.now()
        
        if timeframe == "minute":
            cutoff = now - timedelta(minutes=1)
        elif timeframe == "hour":
            cutoff = now - timedelta(hours=1)
        else:  # day
            cutoff = now - timedelta(days=1)
        
        cutoff_str = cutoff.isoformat()
        
        recent_requests = [r for r in self.requests if r['timestamp'] > cutoff_str]
        recent_tokens = [t for t in self.tokens_used if t['timestamp'] > cutoff_str]
        
        return {
            'requests': len(recent_requests),
            'tokens': sum(t['count'] for t in recent_tokens),
            'percentage': 0
        }


    
    def check_limit(self, estimated_tokens: int = 1000) -> Dict:
        """Check if request can be made without hitting limits"""
        self._clean_old_records()
        
        # Get current usage
        minute_usage = self._get_usage("minute")
        hour_usage = self._get_usage("hour")
        day_usage = self._get_usage("day")
        
        # Calculate percentages
        minute_usage['percentage'] = (minute_usage['requests'] / self.limits['requests_per_minute']) * 100
        hour_usage['percentage'] = (hour_usage['requests'] / self.limits['requests_per_hour']) * 100
        day_usage['percentage'] = (day_usage['requests'] / self.limits['requests_per_day']) * 100
        
        # Check token limits
        token_minute_pct = (minute_usage['tokens'] / self.limits['tokens_per_minute']) * 100
        token_day_pct = (day_usage['tokens'] / self.limits['tokens_per_day']) * 100
        
        # Determine if we should throttle
        max_percentage = max(
            minute_usage['percentage'],
            hour_usage['percentage'],
            day_usage['percentage'],
            token_minute_pct,
            token_day_pct
        )
        
        # Adaptive throttling
        if max_percentage > 90:
            self.throttle_level = 5
            recommended_delay = 60
            can_proceed = False
        elif max_percentage > 80:
            self.throttle_level = 4
            recommended_delay = 30
            can_proceed = True
        elif max_percentage > 70:
            self.throttle_level = 3
            recommended_delay = 15
            can_proceed = True
        elif max_percentage > 60:
            self.throttle_level = 2
            recommended_delay = 5
            can_proceed = True
        elif max_percentage > 50:
            self.throttle_level = 1
            recommended_delay = 2
            can_proceed = True
        else:
            self.throttle_level = 0
            recommended_delay = self.adaptive_delay
            can_proceed = True
        
        return {
            'can_proceed': can_proceed,
            'recommended_delay': recommended_delay,
            'throttle_level': self.throttle_level,
            'usage': {
                'minute': minute_usage,
                'hour': hour_usage,
                'day': day_usage,
                'token_minute_pct': token_minute_pct,
                'token_day_pct': token_day_pct
            },
            'max_percentage': max_percentage
        }
    
    def record_request(self, tokens_used: int = 0):
        """Record a completed request"""
        now = datetime.now().isoformat()
        
        self.requests.append({
            'timestamp': now,
            'tokens': tokens_used
        })
        
        if tokens_used > 0:
            self.tokens_used.append({
                'timestamp': now,
                'count': tokens_used
            })
        
        # Adjust adaptive delay based on success
        if self.throttle_level > 2:
            self.adaptive_delay = min(self.adaptive_delay * 1.1, 5.0)
        else:
            self.adaptive_delay = max(self.adaptive_delay * 0.95, 0.5)
        
        self._save_stats()
    
    def wait_if_needed(self, estimated_tokens: int = 1000) -> bool:
        """Wait if necessary to avoid hitting limits"""
        check = self.check_limit(estimated_tokens)
        
        if not check['can_proceed']:
            print(f"⏸️  Rate limit approaching ({check['max_percentage']:.1f}%)")
            print(f"   Waiting {check['recommended_delay']}s...")
            time.sleep(check['recommended_delay'])
            return True
        elif check['throttle_level'] > 0:
            time.sleep(check['recommended_delay'])
            return True
        
        return False
    
    def get_stats(self) -> Dict:
        """Get current usage statistics"""
        self._clean_old_records()
        
        minute = self._get_usage("minute")
        hour = self._get_usage("hour")
        day = self._get_usage("day")
        
        return {
            'minute': {
                'requests': minute['requests'],
                'limit': self.limits['requests_per_minute'],
                'percentage': (minute['requests'] / self.limits['requests_per_minute']) * 100,
                'tokens': minute['tokens']
            },
            'hour': {
                'requests': hour['requests'],
                'limit': self.limits['requests_per_hour'],
                'percentage': (hour['requests'] / self.limits['requests_per_hour']) * 100
            },
            'day': {
                'requests': day['requests'],
                'limit': self.limits['requests_per_day'],
                'percentage': (day['requests'] / self.limits['requests_per_day']) * 100,
                'tokens': day['tokens'],
                'token_limit': self.limits['tokens_per_day'],
                'token_percentage': (day['tokens'] / self.limits['tokens_per_day']) * 100
            },
            'adaptive_delay': self.adaptive_delay,
            'throttle_level': self.throttle_level
        }
    
    def reset_stats(self):
        """Reset all statistics"""
        self.requests = []
        self.tokens_used = []
        self.adaptive_delay = 1.0
        self.throttle_level = 0
        self._save_stats()

    
    def should_auto_sleep(self) -> bool:
        """Check if should trigger auto-sleep based on usage"""
        if not self.auto_sleep_enabled:
            return False
        
        check = self.check_limit()
        return check['max_percentage'] >= self.auto_sleep_threshold
    
    def get_sleep_duration(self) -> int:
        """Calculate recommended sleep duration in seconds"""
        stats = self.get_stats()
        
        # If minute limit is high, sleep until next minute
        if stats['minute']['percentage'] > 80:
            return 60
        
        # If hour limit is high, sleep 5 minutes
        if stats['hour']['percentage'] > 80:
            return 300
        
        # If day limit is high, sleep 1 hour
        if stats['day']['percentage'] > 80:
            return 3600
        
        return 300  # Default 5 minutes

# Qyrox V4.6 - Build d1748377
