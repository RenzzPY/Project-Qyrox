"""
Command Handler - Separate command logic from main.py
"""
import sys
import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .agent import ProactiveSuperAgent

class CommandHandler:
    """Handle all slash commands"""
    
    def __init__(self, agent: 'ProactiveSuperAgent'):
        self.agent = agent
    
    def handle(self, command: str) -> bool:
        """
        Handle a command
        Returns True if should exit, False otherwise
        """
        parts = command.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        
        # Map commands to handlers
        handlers = {
            '/goal': self._handle_goal,
            '/goals': self._handle_goals,
            '/proactive': self._handle_proactive,
            '/autonomous': self._handle_autonomous,
            '/stats': self._handle_stats,
            '/learned': self._handle_learned,
            '/tool': self._handle_tool,
            '/monitor': self._handle_monitor,
            '/context': self._handle_context,
            '/sleep': self._handle_sleep,
            '/wake': self._handle_wake,
            '/dream': self._handle_dream,
            '/imagine': self._handle_imagine,
            '/dreams': self._handle_dreams,
            '/security': self._handle_security,
            '/mistakes': self._handle_mistakes,
            '/limiter': self._handle_limiter,
            '/help': self._handle_help,
            '/exit': self._handle_exit,
        }
        
        handler = handlers.get(cmd)
        if handler:
            return handler(arg)
        else:
            print(f"Unknown command: {cmd}. Type /help for available commands.")
            return False
    
    def _handle_goal(self, arg: str) -> bool:
        if arg:
            self.agent.memory.add_goal(arg)
            print(f"✓ Goal added: {arg}")
        else:
            print("Usage: /goal <goal text>")
        return False
    
    def _handle_goals(self, arg: str) -> bool:
        goals = self.agent.memory.get_active_goals()
        if goals:
            print("\n📋 Active Goals:")
            for g in goals:
                print(f"  [{g['priority']}] {g['goal']}")
        else:
            print("No active goals yet. Use /goal to add one.")
        return False
    
    def _handle_proactive(self, arg: str) -> bool:
        print("\n💡 Running proactive check...")
        suggestion = self.agent.proactive_check()
        if suggestion:
            print(f"\n🤖 Suggestion:\n{suggestion}")
        else:
            print("No suggestions at the moment.")
        return False
    
    def _handle_autonomous(self, arg: str) -> bool:
        parts = arg.lower().split()
        
        if not parts:
            # Show status
            status = self.agent.autonomous_engine.get_status()
            print(f"\n🤖 Autonomous Engine Status:")
            print(f"   Enabled: {status['enabled']}")
            print(f"   Safety Mode: {status['safety_mode']}")
            print(f"   Require Approval: {status['require_approval']}")
            print(f"   Max Actions/Hour: {status['max_actions_per_hour']}")
            print(f"   Total Actions: {status['total_actions']}")
            if status['last_action']:
                print(f"   Last Action: {status['last_action']['action']} at {status['last_action']['timestamp']}")
            return False
        
        cmd = parts[0]
        
        if cmd == 'on':
            # Enable with safety mode
            safety_mode = parts[1] if len(parts) > 1 else 'safe'
            if safety_mode not in ['safe', 'moderate', 'aggressive']:
                print("❌ Invalid safety mode. Use: safe, moderate, or aggressive")
                return False
            
            result = self.agent.autonomous_engine.enable(safety_mode)
            print(f"\n{result}")
            print("\n⚠️  V4.2 TRUE AUTONOMOUS MODE:")
            print(f"    Safety: {safety_mode.upper()}")
            print("    - Agent akan bertindak sendiri berdasarkan context")
            print("    - Monitoring system health, backup, optimization")
            print("    - Safety guardrails aktif")
            if safety_mode == 'safe':
                print("    - Require approval untuk semua action")
            elif safety_mode == 'moderate':
                print("    - Require approval untuk action penting")
            else:
                print("    - Auto-execute (aggressive mode)")
        
        elif cmd == 'off':
            result = self.agent.autonomous_engine.disable()
            print(f"\n{result}")
        
        elif cmd == 'trigger':
            # Manual trigger action
            if len(parts) < 2:
                print("Usage: /autonomous trigger <action_type>")
                print("Available actions: optimize_memory, clean_temp_files, backup_important_files, update_context, check_system_health")
                return False
            
            action_type = parts[1]
            result = self.agent.autonomous_engine.manual_trigger(action_type)
            print(f"\n{result}")
        
        elif cmd == 'history':
            # Show action history
            status = self.agent.autonomous_engine.get_status()
            print(f"\n📜 Recent Autonomous Actions:")
            for action in status['recent_actions'][-10:]:
                print(f"   [{action['timestamp']}] {action['action']}")
                print(f"      Reason: {action['reason']}")
                print(f"      Result: {action['result']}")
        
        else:
            print("Usage: /autonomous [on|off|trigger|history]")
            print("  /autonomous              - Show status")
            print("  /autonomous on [mode]    - Enable (safe/moderate/aggressive)")
            print("  /autonomous off          - Disable")
            print("  /autonomous trigger <action> - Manual trigger")
            print("  /autonomous history      - Show action history")
        
        return False
    
    def _handle_stats(self, arg: str) -> bool:
        stats = self.agent.get_api_stats()
        print(stats)
        return False
    
    def _handle_learned(self, arg: str) -> bool:
        learned = self.agent.get_learned_tools()
        if learned:
            print("\n🧠 Learned Tools:")
            for tool in learned:
                print(f"  - {tool}")
        else:
            print("Belum ada tools yang dipelajari.")
            print("Coba minta agent untuk sesuatu yang belum ada toolnya!")
        return False
    
    def _handle_tool(self, arg: str) -> bool:
        if arg:
            tool_parts = arg.split(maxsplit=1)
            tool_name = tool_parts[0]
            print(f"\n🔧 Available tools: {', '.join(self.agent.tools.list_tools())}")
            print(f"Use in chat: 'gunakan tool {tool_name} untuk...'")
        else:
            print(f"\nAvailable tools: {', '.join(self.agent.tools.list_tools())}")
        return False
    
    def _handle_monitor(self, arg: str) -> bool:
        if arg == 'start':
            print("\n" + self.agent.start_activity_monitoring())
            print("💡 Activity monitoring akan track aktivitas Anda")
        elif arg == 'stop':
            print("\n" + self.agent.stop_activity_monitoring())
        elif arg == 'insights':
            print("\n" + self.agent.get_activity_insights())
        elif arg == 'predict':
            print("\n🔮 " + self.agent.predict_user_action())
        elif arg == 'suggest':
            suggestions = self.agent.get_proactive_suggestions()
            if suggestions:
                print("\n💡 Proactive Suggestions:")
                for s in suggestions:
                    print(f"  • {s}")
            else:
                print("\nBelum ada suggestions (perlu lebih banyak data)")
        elif arg == 'signal':
            print("\n🔍 Starting signal monitoring...")
            self._start_signal_monitoring()
        else:
            print("\nUsage:")
            print("  /monitor start    - Start activity monitoring")
            print("  /monitor stop     - Stop activity monitoring")
            print("  /monitor insights - View activity insights")
            print("  /monitor predict  - Predict next action")
            print("  /monitor suggest  - Get proactive suggestions")
            print("  /monitor signal   - Start signal monitoring (morning/evening)")
        return False
    
    def _handle_context(self, arg: str) -> bool:
        print("\n" + self.agent.get_context_info())
        return False
    
    def _handle_sleep(self, arg: str) -> bool:
        print("\n" + self.agent.get_sleep_status())
        return False
    
    def _handle_wake(self, arg: str) -> bool:
        print("\n" + self.agent.wake_up_agent())
        return False
    
    def _handle_dream(self, arg: str) -> bool:
        print("\n💭 Agent is dreaming...")
        report = self.agent.do_dream()
        print(report)
        return False
    
    def _handle_imagine(self, arg: str) -> bool:
        if arg:
            print("\n🎨 Imagination mode activated...")
            result = self.agent.imagine(arg)
            print(result)
        else:
            print("Usage: /imagine <prompt>")
            print("Example: /imagine Bagaimana cara optimize API usage?")
        return False
    
    def _handle_dreams(self, arg: str) -> bool:
        print("\n" + self.agent.get_dreams())
        return False
    
    def _handle_security(self, arg: str) -> bool:
        if arg == 'status':
            print("\n" + self.agent.get_security_status())
        elif arg == 'scan':
            print("\n🔍 Scanning for threats...")
            threats = self.agent.scan_security_threats()
            if threats:
                print(f"⚠️ Found {len(threats)} suspicious processes:")
                for t in threats[:5]:
                    print(f"  • {t['name']}: {t['reason']}")
            else:
                print("✅ No threats detected")
        elif arg == 'backup':
            print("\n💾 Creating backup...")
            backed_up = self.agent.backup_important_files()
            print(f"✓ Backed up {len(backed_up)} files")
        elif arg == 'alerts':
            alerts = self.agent.get_security_alerts()
            if alerts:
                print(f"\n⚠️ Recent Alerts ({len(alerts)}):")
                for alert in alerts[-5:]:
                    print(f"  • [{alert['severity'].upper()}] {alert['message']}")
            else:
                print("\n✅ No alerts")
        else:
            print("\nUsage:")
            print("  /security status  - Security status")
            print("  /security scan    - Scan threats")
            print("  /security backup  - Backup files")
            print("  /security alerts  - View alerts")
        return False
    
    def _handle_mistakes(self, arg: str) -> bool:
        if arg == 'stats':
            print("\n" + self.agent.get_mistake_stats())
        elif arg == 'insights':
            insights = self.agent.get_learning_insights()
            if insights:
                print("\n📚 Learning Insights:")
                for insight in insights:
                    print(f"  • {insight}")
            else:
                print("\nBelum ada insights (belum ada mistakes)")
        else:
            print("\nUsage:")
            print("  /mistakes stats    - View statistics")
            print("  /mistakes insights - Learning insights")
        return False
    
    def _handle_limiter(self, arg: str) -> bool:
        """Handle intelligent limiter commands (V4.3)"""
        if arg == 'stats':
            stats = self.agent.limiter.get_stats()
            print(f"""
🛡️ Intelligent Rate Limiter Status (V4.3):
============================================

📊 Current Usage:
  Minute: {stats['minute']['requests']}/{stats['minute']['limit']} ({stats['minute']['percentage']:.1f}%)
  Hour:   {stats['hour']['requests']}/{stats['hour']['limit']} ({stats['hour']['percentage']:.1f}%)
  Day:    {stats['day']['requests']}/{stats['day']['limit']} ({stats['day']['percentage']:.1f}%)

🔢 Token Usage:
  Today: {stats['day']['tokens']:,}/{stats['day']['token_limit']:,} ({stats['day']['token_percentage']:.1f}%)

⚙️ Adaptive Settings:
  Throttle Level: {stats['throttle_level']}/5
  Adaptive Delay: {stats['adaptive_delay']:.2f}s
  
💡 Status: {"🟢 Normal" if stats['throttle_level'] == 0 else "🟡 Throttling" if stats['throttle_level'] < 3 else "🔴 High Usage"}
""")
        elif arg == 'reset':
            self.agent.limiter.reset_stats()
            print("✓ Limiter statistics reset")
        elif arg == 'check':
            check = self.agent.limiter.check_limit()
            print(f"""
🔍 Rate Limit Check:
  Can Proceed: {"✓ Yes" if check['can_proceed'] else "✗ No"}
  Recommended Delay: {check['recommended_delay']}s
  Throttle Level: {check['throttle_level']}/5
  Max Usage: {check['max_percentage']:.1f}%
""")
        else:
            print("\nUsage:")
            print("  /limiter stats - View limiter statistics")
            print("  /limiter check - Check current rate limit status")
            print("  /limiter reset - Reset statistics")
        return False
    
    def _handle_help(self, arg: str) -> bool:
        print("""
Commands:
  /goal <text>     - Tambah goal baru untuk tracking
  /goals           - Lihat semua active goals
  /proactive       - Trigger manual proactive check
  /autonomous [cmd]- Autonomous engine control (V4.2)
  /learned         - Lihat tools yang sudah dipelajari
  /tool [name]     - List atau info tentang tools
  /stats           - Lihat API usage statistics
  /limiter [cmd]   - Intelligent rate limiter (V4.3)
  /help            - Show this help
  /exit            - Exit program

V4.0 Phase 1 Features:
  /context         - Show agent self-awareness
  /sleep           - Check sleep status
  /wake            - Force wake up (emergency)
  /dream           - Trigger manual dream
  /imagine <text>  - Imagination mode
  /dreams          - View dream journal

V4.0 Phase 2 Features:
  /monitor start   - Start activity monitoring
  /monitor insights- View activity insights
  /monitor predict - Predict next action
  /security status - Security status
  /security scan   - Scan for threats
  /security backup - Backup important files
  /mistakes stats  - View mistake statistics
  /mistakes insights- Learning insights

V4.2 True Autonomous Mode:
  /autonomous              - Show status
  /autonomous on [mode]    - Enable (safe/moderate/aggressive)
  /autonomous off          - Disable
  /autonomous trigger <act>- Manual trigger action
  /autonomous history      - Show action history
  
  Features:
  - Agent bertindak sendiri berdasarkan context
  - Monitoring system health otomatis
  - Auto backup, optimization, cleaning
  - Safety guardrails & approval system
  - Action history & learning

V4.3 Intelligent Rate Limiter:
  /limiter stats   - View rate limit statistics
  /limiter check   - Check current limit status
  /limiter reset   - Reset statistics
  
  Features:
  - Adaptive throttling (5 levels)
  - Predictive rate limiting
  - Token usage tracking
  - Auto-delay when approaching limits
  - Prevents API/RPM/RPD limit hits
        """)
        return False
    
    def _handle_exit(self, arg: str) -> bool:
        print("\n👋 Sampai jumpa!")
        return True
    
    def _start_signal_monitoring(self):
        """Start background signal monitoring"""
        from .signal_monitor import SignalMonitor, SignalCheckers
        
        monitor = SignalMonitor()
        
        # Register time-based signals
        monitor.register_signal(
            "time_based",
            SignalCheckers.check_time_based,
            interval_minutes=1
        )
        
        # Register handler
        def handle_time_signal(data):
            result = self.agent.handle_signal(data)
            print(f"\n\n🔔 {data['message']}")
            print(f"🤖 {self.agent.name}:\n{result}\n")
            print("👤 You: ", end="", flush=True)
        
        monitor.register_handler("time_based", handle_time_signal)
        
        print("✓ Monitoring started (running in background)")
        print("  - Morning briefing: 08:00")
        print("  - Evening summary: 18:00")
        print("\nNote: Monitoring berjalan di background. Lanjutkan chat seperti biasa.")
        
        # Start in separate thread
        thread = threading.Thread(target=monitor.start, daemon=True)
        thread.start()

# Qyrox V4.6 - Build 95c392f1
