"""
Multi-AI Discussion System
Groq, Google, OpenAI, OpenRouter diskusi untuk best answer
"""
import logging
from typing import List, Dict, Optional
import asyncio

logger = logging.getLogger(__name__)

class MultiAIDiscussion:
    """Multiple AI models discuss to reach consensus"""
    
    def __init__(self, llm_manager):
        self.llm_manager = llm_manager
        self.discussion_history = []
    
    async def discuss(self, question: str, participants: List[str] = None) -> Dict:
        """
        Multiple AI models discuss a question
        participants: ['groq', 'google', 'openrouter', 'openai']
        """
        if participants is None:
            participants = ['groq', 'google']  # Default
        
        logger.info(f"🤝 Starting multi-AI discussion with: {', '.join(participants)}")
        
        # Get responses from all participants
        responses = {}
        for participant in participants:
            try:
                response = await self._get_response(participant, question)
                responses[participant] = response
                logger.info(f"✓ {participant} responded")
            except Exception as e:
                logger.error(f"✗ {participant} failed: {e}")
                responses[participant] = f"[ERROR: {str(e)}]"
        
        # Analyze and vote
        consensus = self._reach_consensus(question, responses)
        
        # Save discussion
        self.discussion_history.append({
            'question': question,
            'responses': responses,
            'consensus': consensus
        })
        
        return consensus
    
    async def _get_response(self, model: str, question: str) -> str:
        """Get response from specific model"""
        # Use appropriate model
        if model == 'groq':
            return self.llm_manager.invoke_groq(question)
        elif model == 'google':
            return self.llm_manager.invoke_google(question)
        elif model == 'openrouter':
            return self.llm_manager.invoke_openrouter(question)
        elif model == 'openai':
            return self.llm_manager.invoke_openai(question)
        else:
            raise ValueError(f"Unknown model: {model}")
    
    def _reach_consensus(self, question: str, responses: Dict[str, str]) -> Dict:
        """Analyze responses and reach consensus"""
        # Simple voting: pick most common answer or longest response
        valid_responses = {k: v for k, v in responses.items() if not v.startswith('[ERROR')}
        
        if not valid_responses:
            return {
                'consensus': 'No valid responses',
                'confidence': 0,
                'best_response': None,
                'all_responses': responses
            }
        
        # For now, use longest response as best (more detailed)
        best_model = max(valid_responses, key=lambda k: len(valid_responses[k]))
        best_response = valid_responses[best_model]
        
        # Calculate confidence based on agreement
        confidence = len(valid_responses) / len(responses)
        
        return {
            'consensus': best_response,
            'confidence': confidence,
            'best_model': best_model,
            'all_responses': responses,
            'summary': self._create_summary(responses)
        }
    
    def _create_summary(self, responses: Dict[str, str]) -> str:
        """Create summary of all responses"""
        summary = "📊 MULTI-AI DISCUSSION SUMMARY\n"
        summary += "=" * 50 + "\n\n"
        
        for model, response in responses.items():
            summary += f"🤖 {model.upper()}:\n"
            if response.startswith('[ERROR'):
                summary += f"   {response}\n\n"
            else:
                # Show first 200 chars
                preview = response[:200] + "..." if len(response) > 200 else response
                summary += f"   {preview}\n\n"
        
        return summary
    
    def get_discussion_history(self, limit: int = 5) -> List[Dict]:
        """Get recent discussions"""
        return self.discussion_history[-limit:]

# Qyrox V4.6 - Build 1043d108
