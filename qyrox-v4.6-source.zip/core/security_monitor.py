"""
Security Monitor - Laptop Protection System
Monitor keamanan dan deteksi ancaman
"""
import os
import hashlib
import psutil
from datetime import datetime
from pathlib import Path
import json
import logging
from typing import List, Dict
import shutil

logger = logging.getLogger(__name__)

class SecurityMonitor:
    """Monitor security and detect threats"""
    
    def __init__(self):
        self.security_file = Path(__file__).parent.parent / "data" / "security_log.json"
        self.whitelist_file = Path(__file__).parent.parent / "data" / "whitelist.json"
        self.alerts = self._load_alerts()
        self.whitelist = self._load_whitelist()
        self.monitoring = False
        self.watched_folders = []
        self.file_hashes = {}
    
    def _load_alerts(self) -> list:
        """Load security alerts"""
        if self.security_file.exists():
            try:
                with open(self.security_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def _save_alerts(self):
        """Save security alerts"""
        try:
            self.security_file.parent.mkdir(parents=True, exist_ok=True)
            # Keep only last 500 alerts
            with open(self.security_file, 'w', encoding='utf-8') as f:
                json.dump(self.alerts[-500:], f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save alerts: {e}")
    
    def _load_whitelist(self) -> dict:
        """Load whitelist"""
        if self.whitelist_file.exists():
            try:
                with open(self.whitelist_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {
            'processes': [],
            'folders': [],
            'extensions': ['.txt', '.md', '.py', '.json']
        }
    
    def _save_whitelist(self):
        """Save whitelist"""
        try:
            self.whitelist_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.whitelist_file, 'w', encoding='utf-8') as f:
                json.dump(self.whitelist, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save whitelist: {e}")
    
    def add_alert(self, alert_type: str, severity: str, message: str, details: dict = None):
        """Add security alert"""
        alert = {
            'timestamp': datetime.now().isoformat(),
            'type': alert_type,
            'severity': severity,  # low, medium, high, critical
            'message': message,
            'details': details or {}
        }
        self.alerts.append(alert)
        self._save_alerts()
        
        # Log based on severity
        if severity == 'critical':
            logger.critical(f"🚨 SECURITY ALERT: {message}")
        elif severity == 'high':
            logger.error(f"⚠️ Security Alert: {message}")
        else:
            logger.warning(f"⚡ Security Notice: {message}")
    
    def scan_suspicious_processes(self) -> List[Dict]:
        """Scan for suspicious processes"""
        suspicious = []
        
        try:
            for proc in psutil.process_iter(['name', 'cpu_percent', 'memory_percent']):
                try:
                    info = proc.info
                    
                    # Check if process is suspicious
                    # High CPU usage
                    if info['cpu_percent'] > 80:
                        suspicious.append({
                            'name': info['name'],
                            'reason': 'High CPU usage',
                            'cpu': info['cpu_percent'],
                            'severity': 'medium'
                        })
                    
                    # High memory usage
                    if info['memory_percent'] > 50:
                        suspicious.append({
                            'name': info['name'],
                            'reason': 'High memory usage',
                            'memory': info['memory_percent'],
                            'severity': 'medium'
                        })
                    
                    # Suspicious names (basic check)
                    suspicious_keywords = ['hack', 'crack', 'keylog', 'trojan', 'virus']
                    name_lower = info['name'].lower()
                    for keyword in suspicious_keywords:
                        if keyword in name_lower:
                            suspicious.append({
                                'name': info['name'],
                                'reason': f'Suspicious name contains "{keyword}"',
                                'severity': 'high'
                            })
                            break
                
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        
        except Exception as e:
            logger.error(f"Failed to scan processes: {e}")
        
        return suspicious
    
    def monitor_file_changes(self, folder: str) -> List[Dict]:
        """Monitor file changes in folder"""
        changes = []
        folder_path = Path(folder)
        
        if not folder_path.exists():
            return changes
        
        try:
            for file_path in folder_path.rglob('*'):
                if file_path.is_file():
                    # Calculate file hash
                    try:
                        with open(file_path, 'rb') as f:
                            file_hash = hashlib.md5(f.read()).hexdigest()
                        
                        file_key = str(file_path)
                        
                        # Check if file is new or modified
                        if file_key not in self.file_hashes:
                            changes.append({
                                'file': file_key,
                                'type': 'new',
                                'timestamp': datetime.now().isoformat()
                            })
                        elif self.file_hashes[file_key] != file_hash:
                            changes.append({
                                'file': file_key,
                                'type': 'modified',
                                'timestamp': datetime.now().isoformat()
                            })
                        
                        # Update hash
                        self.file_hashes[file_key] = file_hash
                    
                    except Exception as e:
                        pass
        
        except Exception as e:
            logger.error(f"Failed to monitor files: {e}")
        
        return changes
    
    def auto_backup_important_files(self, source_folder: str, backup_folder: str = None):
        """Auto backup important files"""
        if backup_folder is None:
            backup_folder = str(Path(__file__).parent.parent / "data" / "backups")
        
        backup_path = Path(backup_folder)
        backup_path.mkdir(parents=True, exist_ok=True)
        
        source_path = Path(source_folder)
        backed_up = []
        
        try:
            # Backup important file types
            important_extensions = ['.py', '.json', '.md', '.txt', '.config']
            
            for file_path in source_path.rglob('*'):
                if file_path.is_file() and file_path.suffix in important_extensions:
                    try:
                        # Create backup with timestamp
                        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                        backup_name = f"{file_path.stem}_{timestamp}{file_path.suffix}"
                        backup_file = backup_path / backup_name
                        
                        shutil.copy2(file_path, backup_file)
                        backed_up.append(str(file_path))
                    
                    except Exception as e:
                        logger.error(f"Failed to backup {file_path}: {e}")
        
        except Exception as e:
            logger.error(f"Failed to auto backup: {e}")
        
        return backed_up
    
    def get_security_status(self) -> str:
        """Get security status report"""
        status = "🔒 SECURITY STATUS\n"
        status += "=" * 50 + "\n\n"
        
        # Recent alerts
        recent_alerts = self.alerts[-10:]
        if recent_alerts:
            status += "⚠️ Recent Alerts:\n"
            for alert in recent_alerts:
                timestamp = datetime.fromisoformat(alert['timestamp'])
                status += f"  • [{alert['severity'].upper()}] {alert['message']}\n"
                status += f"    {timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"
            status += "\n"
        else:
            status += "✅ No recent alerts\n\n"
        
        # Scan suspicious processes
        suspicious = self.scan_suspicious_processes()
        if suspicious:
            status += "🚨 Suspicious Processes:\n"
            for proc in suspicious[:5]:
                status += f"  • {proc['name']}: {proc['reason']}\n"
            status += "\n"
        else:
            status += "✅ No suspicious processes detected\n\n"
        
        # Monitoring status
        status += f"Monitoring: {'ACTIVE ✅' if self.monitoring else 'INACTIVE ⏸️'}\n"
        status += f"Watched folders: {len(self.watched_folders)}\n"
        
        return status
    
    def start_monitoring(self, folders: List[str] = None):
        """Start security monitoring"""
        self.monitoring = True
        if folders:
            self.watched_folders = folders
        logger.info("✓ Security monitoring started")
    
    def stop_monitoring(self):
        """Stop monitoring"""
        self.monitoring = False
        logger.info("✓ Security monitoring stopped")
    
    def get_alerts(self, severity: str = None, limit: int = 20) -> List[Dict]:
        """Get security alerts"""
        alerts = self.alerts[-limit:]
        if severity:
            alerts = [a for a in alerts if a['severity'] == severity]
        return alerts

# Qyrox V4.6 - Build 05f3c29d
