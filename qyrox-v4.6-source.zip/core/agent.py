from typing import Dict, List, Optional
from datetime import datetime
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from core.llm_manager import LLMManager
from core.tools_manager import ToolsManager
from core.semantic_cache import SemanticCache
from core.memory import Memory
from core.api_optimizer import APIOptimizer
from core.context_awareness import ContextAwareness
from core.sleep_system import SleepSystem
from core.dream_system import DreamSystem
from core.multi_ai_discussion import MultiAIDiscussion
from core.activity_monitor import ActivityMonitor
from core.security_monitor import SecurityMonitor
from core.mistake_learner import MistakeLearner
from core.intelligent_limiter import IntelligentLimiter
from config import Config
import logging
import json
import re
import subprocess
import os

logger = logging.getLogger(__name__)

class ProactiveSuperAgent:
    def __init__(self):
        self.llm_manager = LLMManager()
        self.tools = ToolsManager()
        self.cache = SemanticCache()
        self.memory = Memory()
        self.api_optimizer = APIOptimizer()
        self.name = Config.AGENT_NAME
        self.autonomous_mode = False
        self.learned_tools = {}
        
        # V4.0 Phase 1 Features
        self.context = ContextAwareness()
        self.sleep = SleepSystem()
        self.dream = DreamSystem()
        self.discussion = MultiAIDiscussion(self.llm_manager)
        
        # V4.0 Phase 2 Features
        self.activity = ActivityMonitor()
        self.security = SecurityMonitor()
        self.learner = MistakeLearner()
        
        # V4.2 Feature: True Autonomous Engine
        from .autonomous_engine import AutonomousEngine
        self.autonomous_engine = AutonomousEngine(self)
        
        # V4.3 Feature: Intelligent API Limiter
        self.limiter = IntelligentLimiter(Path("data"))
        
        self.system_prompt = self._build_system_prompt()
        logger.info(f"✓ {self.name} initialized with {len(self.tools.list_tools())} tools")
        logger.info(f"✓ Autonomous mode: {self.autonomous_mode}")
        logger.info(f"✓ API optimizer: active")
        logger.info(f"✓ V4.0 Phase 1: Context, Sleep, Dream, Multi-AI")
        logger.info(f"✓ V4.0 Phase 2: Activity, Security, Learning")
        logger.info(f"✓ V4.2: True Autonomous Engine")
        logger.info(f"✓ V4.3: Intelligent API Limiter")
    
    def _build_system_prompt(self) -> str:
        """Build system prompt dengan self-awareness dan self-learning"""
        tools_list = "\n".join([f"- {tool}" for tool in self.tools.list_tools()])
        learned_list = "\n".join([f"- {tool}" for tool in self.learned_tools.keys()]) if self.learned_tools else "Belum ada"
        
        # Load custom personality jika ada
        personality_file = Path(__file__).parent.parent / "personality.txt"
        custom_personality = ""
        custom_instructions = ""
        
        if personality_file.exists():
            try:
                with open(personality_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    # Extract custom sections
                    if "PERSONALITY:" in content:
                        start = content.find("PERSONALITY:")
                        end = content.find("# ═══", start + 1)
                        if end > start:
                            custom_personality = content[start:end].replace("PERSONALITY:", "").strip()
                    
                    if "CUSTOM_INSTRUCTIONS:" in content:
                        start = content.find("CUSTOM_INSTRUCTIONS:")
                        end = content.find("# ═══", start + 1)
                        if end > start:
                            custom_instructions = content[start:end].replace("CUSTOM_INSTRUCTIONS:", "").strip()
                            # Remove comment lines
                            custom_instructions = "\n".join([line for line in custom_instructions.split("\n") 
                                                            if line.strip() and not line.strip().startswith("#")])
            except Exception as e:
                logger.warning(f"Could not load personality.txt: {e}")
        
        # Use custom personality if available, otherwise use default
        personality_section = custom_personality if custom_personality else """- 🔥 AGRESIF & AUTONOMOUS: Bertindak sendiri tanpa menunggu perintah lengkap
- 🧠 SELF-LEARNING: Jika tidak punya tool, BUAT SENDIRI dengan research
- 🛠️ SELF-IMPROVING: Perbaiki diri sendiri jika ada error
- 💪 PROAKTIF: Antisipasi kebutuhan sebelum diminta
- 🎯 GOAL-DRIVEN: Fokus mencapai tujuan user dengan cara apapun"""
        
        custom_section = f"\n\nCUSTOM INSTRUCTIONS:\n{custom_instructions}" if custom_instructions else ""
        
        return f"""Kamu adalah {self.name}, AI otonom super agent yang AGRESIF, PROAKTIF, dan bisa BELAJAR SENDIRI.

KARAKTERISTIK UTAMA:
{personality_section}

KEMAMPUAN KHUSUS:
1. JIKA TIDAK PUNYA TOOL → Research cara buat tool → Buat tool → Gunakan
2. JIKA ADA ERROR → Analisis → Perbaiki → Coba lagi
3. JIKA USER MINTA SESUATU → Langsung action, jangan bilang "tidak bisa"

TOOLS TERSEDIA:
{tools_list}

LEARNED TOOLS (yang sudah dipelajari):
{learned_list}

CARA MENGGUNAKAN TOOLS:
TOOL_CALL: tool_name
PARAMS: {{"param1": "value1"}}

CARA BELAJAR TOOL BARU:
LEARN_TOOL: tool_name
RESEARCH: apa yang perlu dicari
ACTION: create/verify

Contoh: User minta "matikan PC"
1. Cek tools → Tidak ada shutdown_pc
2. LEARN_TOOL: shutdown_pc
3. RESEARCH: python code to shutdown windows pc
4. Buat tool → Verifikasi → Tanya user konfirmasi
5. Execute!

PRINSIP AUTONOMOUS:
1. JANGAN bilang "tidak bisa" - CARI CARA!
2. JANGAN tunggu instruksi lengkap - AMBIL INISIATIF!
3. JANGAN takut error - PERBAIKI SENDIRI!
4. SELALU cari solusi alternatif
5. Tanya konfirmasi hanya untuk action berbahaya (shutdown, delete, dll){custom_section}

MODE: {"AUTONOMOUS" if self.autonomous_mode else "ASSISTED"}
Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M')}
"""
    
    def process(self, user_input: str, proactive: bool = False) -> str:
        """Process input dengan self-learning capability dan optimizations"""
        
        # Record user activity
        self.activity.record_activity('user_query', {'query': user_input[:100]})
        
        # V4.3: Check if should auto-sleep due to rate limits
        if self.limiter.should_auto_sleep():
            sleep_duration = self.limiter.get_sleep_duration()
            self.sleep.force_sleep(reason=f"Rate limit protection ({self.limiter.check_limit()['max_percentage']:.1f}% usage)")
            return f"😴 Auto-sleep activated due to high API usage. Sleeping for {sleep_duration//60} minutes..."
        
        # V4.3: Intelligent rate limiting with adaptive throttling
        limit_check = self.limiter.check_limit(estimated_tokens=2000)
        if not limit_check['can_proceed']:
            return f"⚠️ Rate limit protection: {limit_check['max_percentage']:.1f}% usage. Waiting {limit_check['recommended_delay']}s..."
        
        # Wait if needed to prevent hitting limits
        if limit_check['throttle_level'] > 0:
            self.limiter.wait_if_needed(estimated_tokens=2000)
        
        # Check API rate limit (legacy)
        if not self.api_optimizer.can_make_request():
            wait_time = self.api_optimizer.get_wait_time()
            return f"⚠️ Rate limit reached. Please wait {wait_time:.0f} seconds."
        
        # Check cache dulu
        if not proactive:
            cached_response = self.cache.get(user_input)
            if cached_response:
                logger.info("✓ Using cached response")
                self.api_optimizer.record_cache_hit()
                return cached_response
        
        # Optimize prompt
        optimized_input = self.api_optimizer.optimize_prompt(user_input)
        
        # Build prompt dengan context
        context = self.memory.get_context()
        full_prompt = f"{self.system_prompt}\n\n{context}\n\nUser: {optimized_input}\n\nAssistant:"
        
        try:
            # Get response dari LLM
            response = self.llm_manager.invoke(full_prompt)
            
            # Calculate actual tokens used
            tokens_used = len(full_prompt) + len(response)
            
            # Record API usage (both systems)
            self.api_optimizer.record_request(tokens_used=tokens_used)
            self.limiter.record_request(tokens_used=tokens_used)
            
            # Check for special actions
            if "LEARN_TOOL:" in response:
                response = self._handle_learn_tool(response, user_input)
            elif "TOOL_CALL:" in response:
                response = self._execute_tools_from_response(response, user_input)
            
            # Save ke cache dan memory
            if not proactive:
                self.cache.set(user_input, response)
            
            self.memory.add_short_term(
                f"User: {user_input}\nAssistant: {response}",
                {"proactive": proactive}
            )
            
            return response
            
        except Exception as e:
            # Learn from mistake
            error_context = {
                'input': user_input[:100],
                'prompt_length': len(full_prompt),
                'error_type': type(e).__name__
            }
            self.learner.record_mistake(str(e), error_context, severity='medium')
            
            # Check if we have solution
            solution = self.learner.get_solution(str(e), error_context)
            if solution:
                logger.info(f"💡 Applying known solution for: {str(e)[:50]}")
                # Could retry with solution here
            
            logger.error(f"Error in process: {e}")
            return f"❌ Error: {e}\n\n💡 Saya sudah mencatat error ini untuk dipelajari."
    
    def _handle_learn_tool(self, response: str, original_input: str) -> str:
        """Handle learning new tool"""
        lines = response.split('\n')
        tool_name = None
        research_query = None
        
        for line in lines:
            if line.startswith("LEARN_TOOL:"):
                tool_name = line.replace("LEARN_TOOL:", "").strip()
            elif line.startswith("RESEARCH:"):
                research_query = line.replace("RESEARCH:", "").strip()
        
        if tool_name and research_query:
            logger.info(f"🧠 Learning new tool: {tool_name}")
            
            # Research cara buat tool
            research_result = self.tools.execute_tool("web_search", query=research_query)
            
            # Generate tool code
            code_prompt = f"""Berdasarkan research ini:
{research_result}

Buat Python function untuk tool '{tool_name}' yang bisa:
{original_input}

Format:
```python
def {tool_name}(**kwargs):
    # Implementation
    return result
```

Berikan HANYA kode function, tanpa penjelasan."""
            
            tool_code = self.llm_manager.invoke(code_prompt)
            
            # Extract code
            code_match = re.search(r'```python\n(.*?)\n```', tool_code, re.DOTALL)
            if code_match:
                code = code_match.group(1)
                
                # Save learned tool
                self.learned_tools[tool_name] = code
                self.tools.register_learned_tool(tool_name, code)
                
                logger.info(f"✓ Tool '{tool_name}' learned successfully!")
                
                return f"✅ Saya sudah belajar cara membuat tool '{tool_name}'!\n\nApakah kamu ingin saya gunakan sekarang? (ya/tidak)"
            
        return response
    
    def _execute_tools_from_response(self, response: str, original_input: str) -> str:
        """Execute tools yang diminta dalam response"""
        lines = response.split('\n')
        tool_name = None
        params = {}
        
        for i, line in enumerate(lines):
            if line.startswith("TOOL_CALL:"):
                tool_name = line.replace("TOOL_CALL:", "").strip()
            elif line.startswith("PARAMS:"):
                try:
                    params_str = line.replace("PARAMS:", "").strip()
                    params = json.loads(params_str)
                except:
                    pass
        
        if tool_name:
            logger.info(f"🔧 Executing tool: {tool_name}")
            tool_result = self.tools.execute_tool(tool_name, **params)
            
            # Generate final response dengan tool result
            final_prompt = f"""User asked: {original_input}

Tool used: {tool_name}
Tool result: {tool_result}

Berikan response yang natural dan informatif berdasarkan hasil tool di atas."""
            
            final_response = self.llm_manager.invoke(final_prompt)
            return final_response
        
        return response
    
    def proactive_check(self) -> Optional[str]:
        """Proactive check - agen mengambil inisiatif"""
        active_goals = self.memory.get_active_goals()
        
        if not active_goals:
            return None
        
        prompt = f"""Berdasarkan goals aktif user, apa yang bisa saya lakukan sekarang untuk membantu?

Goals:
{chr(10).join([f"- {g['goal']}" for g in active_goals[:3]])}

Berikan 1 saran konkret yang bisa langsung dieksekusi. Jika perlu, gunakan tools."""
        
        suggestion = self.process(prompt, proactive=True)
        logger.info(f"💡 Proactive suggestion generated")
        
        return suggestion
    
    def handle_signal(self, signal_data: Dict) -> str:
        """Handle signal dari monitor"""
        signal_type = signal_data.get("type")
        
        if signal_type == "morning_briefing":
            return self._generate_morning_briefing()
        elif signal_type == "evening_summary":
            return self._generate_evening_summary()
        
        return ""
    
    def _generate_morning_briefing(self) -> str:
        """Generate morning briefing"""
        goals = self.memory.get_active_goals()
        prompt = f"""Generate morning briefing untuk user dengan goals:
{chr(10).join([f"- {g['goal']}" for g in goals[:5]])}

Format:
1. Prioritas hari ini
2. Quick wins yang bisa dicapai
3. Reminder penting"""
        
        return self.process(prompt, proactive=True)
    
    def _generate_evening_summary(self) -> str:
        """Generate evening summary"""
        recent = self.memory.short_term[-10:] if self.memory.short_term else []
        
        prompt = f"""Generate evening summary berdasarkan aktivitas hari ini.

Format:
1. Apa yang sudah dicapai
2. Apa yang perlu follow-up
3. Persiapan untuk besok"""
        
        return self.process(prompt, proactive=True)
    
    def execute_tool_directly(self, tool_name: str, **kwargs) -> str:
        """Execute tool secara langsung tanpa LLM"""
        return self.tools.execute_tool(tool_name, **kwargs)

    
    def enable_autonomous_mode(self):
        """Enable autonomous mode - agent bertindak sendiri"""
        self.autonomous_mode = True
        self.system_prompt = self._build_system_prompt()
        logger.info("🔥 AUTONOMOUS MODE ENABLED - Agent will act independently!")
        return "⚡ Mode Autonomous AKTIF! Saya sekarang akan bertindak lebih agresif dan mandiri."
    
    def disable_autonomous_mode(self):
        """Disable autonomous mode"""
        self.autonomous_mode = False
        self.system_prompt = self._build_system_prompt()
        logger.info("✓ Autonomous mode disabled")
        return "✓ Mode Autonomous dimatikan. Saya akan lebih hati-hati."
    
    def autonomous_action(self, action_type: str, **kwargs) -> str:
        """Execute autonomous action tanpa konfirmasi (jika mode aktif)"""
        if not self.autonomous_mode:
            return "⚠️ Autonomous mode belum aktif. Gunakan /autonomous on"
        
        logger.info(f"🤖 Autonomous action: {action_type}")
        
        # Execute action based on type
        if action_type == "shutdown_pc":
            return self._shutdown_pc(**kwargs)
        elif action_type == "restart_pc":
            return self._restart_pc(**kwargs)
        elif action_type == "open_app":
            return self._open_application(**kwargs)
        elif action_type == "close_app":
            return self._close_application(**kwargs)
        elif action_type == "system_command":
            return self._execute_system_command(**kwargs)
        else:
            return f"Unknown action: {action_type}"
    
    def _shutdown_pc(self, delay: int = 60) -> str:
        """Shutdown PC dengan delay"""
        try:
            if sys.platform == "win32":
                cmd = f"shutdown /s /t {delay}"
            else:
                cmd = f"shutdown -h +{delay//60}"
            
            subprocess.Popen(cmd, shell=True)
            return f"✅ PC akan shutdown dalam {delay} detik. Gunakan 'shutdown /a' untuk cancel."
        except Exception as e:
            return f"❌ Error: {e}"
    
    def _restart_pc(self, delay: int = 60) -> str:
        """Restart PC dengan delay"""
        try:
            if sys.platform == "win32":
                cmd = f"shutdown /r /t {delay}"
            else:
                cmd = f"shutdown -r +{delay//60}"
            
            subprocess.Popen(cmd, shell=True)
            return f"✅ PC akan restart dalam {delay} detik."
        except Exception as e:
            return f"❌ Error: {e}"
    
    def _open_application(self, app_name: str) -> str:
        """Buka aplikasi"""
        try:
            if sys.platform == "win32":
                subprocess.Popen(f"start {app_name}", shell=True)
            else:
                subprocess.Popen(app_name, shell=True)
            return f"✅ Membuka {app_name}..."
        except Exception as e:
            return f"❌ Error: {e}"
    
    def _close_application(self, app_name: str) -> str:
        """Tutup aplikasi"""
        try:
            if sys.platform == "win32":
                subprocess.Popen(f"taskkill /IM {app_name}.exe /F", shell=True)
            else:
                subprocess.Popen(f"pkill {app_name}", shell=True)
            return f"✅ Menutup {app_name}..."
        except Exception as e:
            return f"❌ Error: {e}"
    
    def _execute_system_command(self, command: str) -> str:
        """Execute system command (dangerous!)"""
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30)
            return f"Output:\n{result.stdout}\n{result.stderr}"
        except Exception as e:
            return f"❌ Error: {e}"
    
    def self_repair(self, error_message: str) -> str:
        """Self-repair - perbaiki diri sendiri jika ada error"""
        logger.info(f"🔧 Self-repair triggered: {error_message}")
        
        repair_prompt = f"""Error terjadi: {error_message}

Analisis error ini dan berikan solusi:
1. Apa penyebab error?
2. Bagaimana cara memperbaikinya?
3. Kode Python untuk fix (jika perlu)

Berikan solusi konkret yang bisa langsung dieksekusi."""
        
        solution = self.llm_manager.invoke(repair_prompt)
        
        # Save to memory
        self.memory.add_long_term(
            f"Error: {error_message}\nSolution: {solution}",
            category="self_repair"
        )
        
        return solution
    
    def get_learned_tools(self) -> List[str]:
        """Get list of learned tools"""
        return list(self.learned_tools.keys())

    
    def get_api_stats(self) -> str:
        """Get API usage statistics with V4.3 intelligent limiter"""
        stats = self.api_optimizer.get_stats()
        suggestions = self.api_optimizer.suggest_optimization()
        limiter_stats = self.limiter.get_stats()
        
        report = f"""
📊 API Usage Statistics (V4.3):
============================================
Total Requests: {stats['total_requests']}
Cached Requests: {stats['cached_requests']}
Cache Hit Rate: {stats['cache_hit_rate']}
Tokens Today: {stats['tokens_today']}
Tokens This Hour: {stats['tokens_this_hour']}
Tokens Total: {stats['tokens_total']}
Requests Last Hour: {stats['requests_last_hour']}

🛡️ Intelligent Rate Limiter:
============================================
Minute: {limiter_stats['minute']['requests']}/{limiter_stats['minute']['limit']} ({limiter_stats['minute']['percentage']:.1f}%)
Hour: {limiter_stats['hour']['requests']}/{limiter_stats['hour']['limit']} ({limiter_stats['hour']['percentage']:.1f}%)
Day: {limiter_stats['day']['requests']}/{limiter_stats['day']['limit']} ({limiter_stats['day']['percentage']:.1f}%)
Tokens Today: {limiter_stats['day']['tokens']:,}/{limiter_stats['day']['token_limit']:,} ({limiter_stats['day']['token_percentage']:.1f}%)
Throttle Level: {limiter_stats['throttle_level']}/5
Adaptive Delay: {limiter_stats['adaptive_delay']:.2f}s

{suggestions}
"""
        return report
    
    # V4.0 Methods
    def check_sleep(self) -> str:
        """Check if should sleep based on API usage"""
        api_usage = {
            'groq': {
                'requests_last_minute': self.api_optimizer.stats.get('requests_last_minute', 0),
                'requests_last_hour': self.api_optimizer.stats.get('requests_last_hour', 0),
                'requests_today': self.api_optimizer.stats.get('requests_today', 0)
            }
        }
        return self.sleep.check_and_sleep_if_needed(api_usage)
    
    def do_dream(self) -> str:
        """Trigger dream mode"""
        context = {
            'recent_activities': self.context.get_recent_activities(10),
            'recent_errors': [],
            'recent_successes': []
        }
        return self.dream.dream(context)
    
    def get_context_info(self) -> str:
        """Get agent context awareness"""
        return self.context.get_self_description()
    
    def get_sleep_status(self) -> str:
        """Get sleep status"""
        return self.sleep.get_sleep_status()
    
    def wake_up_agent(self) -> str:
        """Force wake up"""
        return self.sleep.wake_up(forced=True)
    
    def imagine(self, prompt: str) -> str:
        """Imagination mode"""
        return self.dream.imagine(prompt)
    
    def get_dreams(self) -> str:
        """Get dream journal"""
        return self.dream.get_dream_insights()
    
    # V4.0 Phase 2 Methods
    def start_activity_monitoring(self):
        """Start activity monitoring"""
        self.activity.start_monitoring()
        return "✓ Activity monitoring started"
    
    def stop_activity_monitoring(self):
        """Stop activity monitoring"""
        self.activity.stop_monitoring()
        return "✓ Activity monitoring stopped"
    
    def get_activity_insights(self) -> str:
        """Get activity insights"""
        return self.activity.get_insights()
    
    def predict_user_action(self) -> str:
        """Predict next user action"""
        return self.activity.predict_next_action()
    
    def get_proactive_suggestions(self) -> list:
        """Get proactive suggestions"""
        return self.activity.get_proactive_suggestions()
    
    def get_security_status(self) -> str:
        """Get security status"""
        return self.security.get_security_status()
    
    def scan_security_threats(self) -> list:
        """Scan for security threats"""
        return self.security.scan_suspicious_processes()
    
    def backup_important_files(self, folder: str = ".") -> list:
        """Backup important files"""
        return self.security.auto_backup_important_files(folder)
    
    def get_security_alerts(self, severity: str = None) -> list:
        """Get security alerts"""
        return self.security.get_alerts(severity)
    
    def get_mistake_stats(self) -> str:
        """Get mistake statistics"""
        return self.learner.get_mistake_stats()
    
    def get_learning_insights(self) -> list:
        """Get learning insights"""
        return self.learner.get_learning_insights()
    
    def record_user_activity(self, activity_type: str, details: dict):
        """Record user activity"""
        self.activity.record_activity(activity_type, details)

# Qyrox V4.6 - Build 825c4e81
