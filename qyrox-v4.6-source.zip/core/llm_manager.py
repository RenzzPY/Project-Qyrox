"""
LLM Manager - Mengelola multiple model
"""
from langchain_groq import ChatGroq
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))
from config import Config
import logging

logger = logging.getLogger(__name__)

class LLMManager:
    def __init__(self):
        self.models = self._initialize_models()
        self.current_model = "groq"
    
    def _initialize_models(self):
        """Inisialisasi semua model yang tersedia"""
        models = {}
        
        try:
            if Config.GROQ_API_KEY:
                models["groq"] = ChatGroq(
                    api_key=Config.GROQ_API_KEY,
                    model_name=Config.PRIMARY_MODEL,
                    temperature=0.7,
                    max_tokens=4096
                )
                logger.info("✓ Groq model initialized")
        except Exception as e:
            logger.warning(f"Groq initialization failed: {e}")
        
        try:
            if Config.GOOGLE_API_KEY:
                models["google"] = ChatGoogleGenerativeAI(
                    api_key=Config.GOOGLE_API_KEY,
                    model=Config.FALLBACK_MODEL,
                    temperature=0.7
                )
                logger.info("✓ Google Gemini model initialized")
        except Exception as e:
            logger.warning(f"Google initialization failed: {e}")
        
        return models
    
    def get_model(self, model_name=None):
        """Dapatkan model LLM"""
        if model_name and model_name in self.models:
            return self.models[model_name]
        return self.models.get(self.current_model) or next(iter(self.models.values()))
    
    def invoke(self, prompt, model_name=None):
        """Invoke model dengan fallback otomatis"""
        model = self.get_model(model_name)
        try:
            response = model.invoke(prompt)
            return response.content
        except Exception as e:
            logger.error(f"Model invocation failed: {e}")
            # Fallback ke model lain
            for name, fallback_model in self.models.items():
                if name != (model_name or self.current_model):
                    try:
                        response = fallback_model.invoke(prompt)
                        logger.info(f"Fallback to {name} successful")
                        return response.content
                    except:
                        continue
            raise Exception("All models failed")

# Qyrox V4.6 - Build 1394cc3b
