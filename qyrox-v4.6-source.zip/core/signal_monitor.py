"""
Signal Monitor - Lapisan Indra untuk mendeteksi trigger proaktif
"""
import schedule
import time
from datetime import datetime
from typing import List, Dict, Callable
import logging

logger = logging.getLogger(__name__)

class SignalMonitor:
    def __init__(self):
        self.signals = []
        self.handlers = {}
    
    def register_signal(self, name: str, check_function: Callable, interval_minutes: int = 5):
        """Register signal baru untuk dimonitor"""
        self.signals.append({
            "name": name,
            "check_function": check_function,
            "interval": interval_minutes
        })
        
        # Schedule periodic check
        schedule.every(interval_minutes).minutes.do(
            self._check_signal, name, check_function
        )
        
        logger.info(f"✓ Registered signal: {name} (every {interval_minutes}m)")
    
    def _check_signal(self, name: str, check_function: Callable):
        """Check signal dan trigger handler jika ada perubahan"""
        try:
            result = check_function()
            if result:
                logger.info(f"🔔 Signal detected: {name}")
                self._trigger_handlers(name, result)
        except Exception as e:
            logger.error(f"Error checking signal {name}: {e}")
    
    def register_handler(self, signal_name: str, handler: Callable):
        """Register handler untuk signal tertentu"""
        if signal_name not in self.handlers:
            self.handlers[signal_name] = []
        self.handlers[signal_name].append(handler)
        logger.info(f"✓ Handler registered for: {signal_name}")
    
    def _trigger_handlers(self, signal_name: str, data: Dict):
        """Trigger semua handler untuk signal"""
        if signal_name in self.handlers:
            for handler in self.handlers[signal_name]:
                try:
                    handler(data)
                except Exception as e:
                    logger.error(f"Handler error for {signal_name}: {e}")
    
    def start(self):
        """Mulai monitoring (blocking)"""
        logger.info("🚀 Signal Monitor started")
        while True:
            schedule.run_pending()
            time.sleep(1)

# Built-in Signal Checkers
class SignalCheckers:
    @staticmethod
    def check_time_based():
        """Check waktu untuk reminder harian"""
        now = datetime.now()
        
        # Morning briefing (08:00)
        if now.hour == 8 and now.minute == 0:
            return {
                "type": "morning_briefing",
                "message": "Saatnya morning briefing!"
            }
        
        # Evening summary (18:00)
        if now.hour == 18 and now.minute == 0:
            return {
                "type": "evening_summary",
                "message": "Saatnya review harian!"
            }
        
        return None

# Qyrox V4.6 - Build ceb2ce31
