"""
Context Awareness - Agent Self-Awareness System
Agent tahu tentang dirinya, user, dan lingkungannya
"""
import os
import platform
import socket
import psutil
from datetime import datetime
from pathlib import Path
import json
import logging

logger = logging.getLogger(__name__)

class ContextAwareness:
    """Agent self-awareness and context understanding"""
    
    def __init__(self):
        self.context_file = Path(__file__).parent.parent / "data" / "context.json"
        self.context = self._load_context()
        self._update_context()
    
    def _load_context(self) -> dict:
        """Load saved context"""
        if self.context_file.exists():
            try:
                with open(self.context_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def _save_context(self):
        """Save context to file"""
        try:
            self.context_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.context_file, 'w', encoding='utf-8') as f:
                json.dump(self.context, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save context: {e}")
    
    def _update_context(self):
        """Update context with current information"""
        # System info
        self.context['system'] = {
            'os': platform.system(),
            'os_version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'hostname': socket.gethostname(),
            'python_version': platform.python_version()
        }
        
        # User info
        self.context['user'] = {
            'username': os.getenv('USERNAME') or os.getenv('USER') or 'Unknown',
            'home_dir': str(Path.home()),
            'current_dir': str(Path.cwd())
        }
        
        # Agent info
        self.context['agent'] = {
            'location': str(Path(__file__).parent.parent),
            'started_at': self.context.get('agent', {}).get('started_at', datetime.now().isoformat()),
            'last_active': datetime.now().isoformat(),
            'total_runs': self.context.get('agent', {}).get('total_runs', 0) + 1
        }
        
        # Hardware info
        try:
            self.context['hardware'] = {
                'cpu_count': psutil.cpu_count(),
                'memory_total_gb': round(psutil.virtual_memory().total / (1024**3), 2),
                'disk_total_gb': round(psutil.disk_usage('/').total / (1024**3), 2)
            }
        except:
            self.context['hardware'] = {}
        
        self._save_context()
        logger.info("✓ Context awareness updated")
    
    def get_self_description(self) -> str:
        """Get agent's self-description"""
        user = self.context.get('user', {})
        system = self.context.get('system', {})
        agent = self.context.get('agent', {})
        
        return f"""SELF-AWARENESS CONTEXT:
Saya adalah AI agent yang berjalan di:
- Komputer: {system.get('hostname', 'Unknown')}
- OS: {system.get('os', 'Unknown')} {system.get('os_version', '')}
- User: {user.get('username', 'Unknown')}
- Lokasi: {agent.get('location', 'Unknown')}
- Total runs: {agent.get('total_runs', 0)}

Saya memiliki akses ke:
- Home directory: {user.get('home_dir', 'Unknown')}
- Current directory: {user.get('current_dir', 'Unknown')}
- System resources: CPU, Memory, Disk

Saya sadar bahwa saya adalah AI assistant yang membantu {user.get('username', 'user')} dalam berbagai tugas.
"""
    
    def get_context_summary(self) -> dict:
        """Get context summary for system prompt"""
        return {
            'username': self.context.get('user', {}).get('username', 'Unknown'),
            'os': self.context.get('system', {}).get('os', 'Unknown'),
            'hostname': self.context.get('system', {}).get('hostname', 'Unknown'),
            'location': self.context.get('agent', {}).get('location', 'Unknown'),
            'total_runs': self.context.get('agent', {}).get('total_runs', 0)
        }
    
    def update_activity(self, activity: str):
        """Update last activity"""
        if 'activities' not in self.context:
            self.context['activities'] = []
        
        self.context['activities'].append({
            'timestamp': datetime.now().isoformat(),
            'activity': activity
        })
        
        # Keep only last 100 activities
        self.context['activities'] = self.context['activities'][-100:]
        self._save_context()
    
    def get_recent_activities(self, limit: int = 10) -> list:
        """Get recent activities"""
        return self.context.get('activities', [])[-limit:]

# Qyrox V4.6 - Build b2f4105b
