import asyncio
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import hashlib
import json
from pathlib import Path

class Priority(Enum):
    """Request priority levels"""
    URGENT = 5
    HIGH = 4
    NORMAL = 3
    LOW = 2
    BACKGROUND = 1

@dataclass
class Request:
    """A single request"""
    request_id: str
    content: str
    priority: Priority
    context: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    callback: Optional[Callable] = None
    result: Optional[Any] = None
    status: str = "pending"  # pending, batched, processing, completed, failed
    batch_id: Optional[str] = None
    
    def __hash__(self):
        return hash(self.request_id)

@dataclass
class Batch:
    """A batch of similar requests"""
    batch_id: str
    requests: List[Request] = field(default_factory=list)
    combined_content: str = ""
    priority: Priority = Priority.NORMAL
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    status: str = "pending"
    result: Optional[Any] = None

class RequestBatcher:
    """Intelligent request batching and queue management"""
    
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.stats_file = data_dir / "batcher_stats.json"
        
        # Queues by priority
        self.queues: Dict[Priority, List[Request]] = {
            priority: [] for priority in Priority
        }
        
        # Batches
        self.batches: List[Batch] = []
        self.completed_batches: List[Batch] = []
        
        # Configuration
        self.batch_size = 5  # Max requests per batch
        self.batch_timeout = 2.0  # seconds
        self.similarity_threshold = 0.7
        
        # Statistics
        self.stats = {
            "total_requests": 0,
            "batched_requests": 0,
            "api_calls_saved": 0,
            "total_batches": 0
        }
        
        self._load_stats()
    
    def _load_stats(self):
        """Load statistics"""
        if self.stats_file.exists():
            try:
                with open(self.stats_file, 'r') as f:
                    self.stats = json.load(f)
            except:
                pass
    
    def _save_stats(self):
        """Save statistics"""
        try:
            with open(self.stats_file, 'w') as f:
                json.dump(self.stats, f, indent=2)
        except:
            pass
    
    def add_request(self, content: str, priority: Priority = Priority.NORMAL,
                   context: Dict[str, Any] = None, callback: Callable = None) -> Request:
        """Add a new request to the queue"""
        request = Request(
            request_id=f"req_{datetime.now().timestamp()}_{hashlib.md5(content.encode()).hexdigest()[:8]}",
            content=content,
            priority=priority,
            context=context or {},
            callback=callback
        )
        
        self.queues[priority].append(request)
        self.stats["total_requests"] += 1
        self._save_stats()
        
        return request
    
    def _calculate_similarity(self, req1: Request, req2: Request) -> float:
        """Calculate similarity between two requests"""
        # Simple word overlap for now
        # In production, use embeddings
        
        words1 = set(req1.content.lower().split())
        words2 = set(req2.content.lower().split())
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union) if union else 0
    
    def _can_batch(self, req1: Request, req2: Request) -> bool:
        """Check if two requests can be batched"""
        # Same priority
        if req1.priority != req2.priority:
            return False
        
        # Similar content
        similarity = self._calculate_similarity(req1, req2)
        if similarity < self.similarity_threshold:
            return False
        
        return True
    
    def create_batches(self) -> List[Batch]:
        """Create batches from queued requests"""
        new_batches = []
        
        # Process each priority queue
        for priority in sorted(Priority, key=lambda p: p.value, reverse=True):
            queue = self.queues[priority]
            
            if not queue:
                continue
            
            # Group similar requests
            while queue:
                # Start new batch with first request
                current_request = queue.pop(0)
                batch_requests = [current_request]
                
                # Find similar requests
                remaining = []
                for req in queue:
                    if len(batch_requests) < self.batch_size and self._can_batch(current_request, req):
                        batch_requests.append(req)
                        self.stats["batched_requests"] += 1
                    else:
                        remaining.append(req)
                
                queue = remaining
                
                # Create batch
                batch = Batch(
                    batch_id=f"batch_{datetime.now().timestamp()}_{len(self.batches)}",
                    requests=batch_requests,
                    priority=priority
                )
                
                # Combine content
                batch.combined_content = self._combine_requests(batch_requests)
                
                # Update request status
                for req in batch_requests:
                    req.status = "batched"
                    req.batch_id = batch.batch_id
                
                new_batches.append(batch)
                self.batches.append(batch)
                self.stats["total_batches"] += 1
                
                # Calculate API calls saved
                if len(batch_requests) > 1:
                    self.stats["api_calls_saved"] += len(batch_requests) - 1
            
            # Update queue
            self.queues[priority] = queue
        
        self._save_stats()
        return new_batches
    
    def _combine_requests(self, requests: List[Request]) -> str:
        """Combine multiple requests into one"""
        if len(requests) == 1:
            return requests[0].content
        
        combined = "I have multiple related requests:\n\n"
        for i, req in enumerate(requests, 1):
            combined += f"{i}. {req.content}\n"
        
        combined += "\nPlease provide comprehensive answers for all requests."
        return combined
    
    async def process_batch(self, batch: Batch, executor: Callable) -> Batch:
        """Process a batch with the provided executor"""
        batch.status = "processing"
        
        for req in batch.requests:
            req.status = "processing"
        
        try:
            # Execute combined request
            result = await executor(batch.combined_content)
            
            batch.result = result
            batch.status = "completed"
            
            # Distribute results to individual requests
            self._distribute_results(batch, result)
            
            # Move to completed
            self.completed_batches.append(batch)
            self.batches.remove(batch)
            
        except Exception as e:
            batch.status = "failed"
            for req in batch.requests:
                req.status = "failed"
                req.result = {"error": str(e)}
        
        return batch
    
    def _distribute_results(self, batch: Batch, result: Any):
        """Distribute batch result to individual requests"""
        # Simple distribution: same result for all
        # In production, parse result and distribute appropriately
        
        for req in batch.requests:
            req.result = result
            req.status = "completed"
            
            # Call callback if provided
            if req.callback:
                try:
                    req.callback(req.result)
                except:
                    pass
    
    def get_request_status(self, request_id: str) -> Optional[Request]:
        """Get status of a specific request"""
        # Check all queues
        for queue in self.queues.values():
            for req in queue:
                if req.request_id == request_id:
                    return req
        
        # Check batches
        for batch in self.batches + self.completed_batches:
            for req in batch.requests:
                if req.request_id == request_id:
                    return req
        
        return None
    
    def get_queue_stats(self) -> Dict[str, Any]:
        """Get queue statistics"""
        queue_sizes = {
            priority.name: len(queue)
            for priority, queue in self.queues.items()
        }
        
        pending_batches = len([b for b in self.batches if b.status == "pending"])
        processing_batches = len([b for b in self.batches if b.status == "processing"])
        
        savings_percentage = 0
        if self.stats["total_requests"] > 0:
            savings_percentage = (self.stats["api_calls_saved"] / self.stats["total_requests"]) * 100
        
        return {
            "queue_sizes": queue_sizes,
            "total_queued": sum(queue_sizes.values()),
            "pending_batches": pending_batches,
            "processing_batches": processing_batches,
            "completed_batches": len(self.completed_batches),
            "statistics": self.stats,
            "savings_percentage": savings_percentage
        }
    
    def clear_completed(self, older_than_hours: int = 24):
        """Clear old completed batches"""
        cutoff = datetime.now().timestamp() - (older_than_hours * 3600)
        
        self.completed_batches = [
            batch for batch in self.completed_batches
            if datetime.fromisoformat(batch.created_at).timestamp() > cutoff
        ]
    
    def get_next_batch(self) -> Optional[Batch]:
        """Get next batch to process (highest priority)"""
        pending = [b for b in self.batches if b.status == "pending"]
        
        if not pending:
            return None
        
        # Sort by priority
        pending.sort(key=lambda b: b.priority.value, reverse=True)
        return pending[0]
    
    def deduplicate_requests(self):
        """Remove duplicate requests from queues"""
        for priority, queue in self.queues.items():
            seen = set()
            unique = []
            
            for req in queue:
                content_hash = hashlib.md5(req.content.encode()).hexdigest()
                if content_hash not in seen:
                    seen.add(content_hash)
                    unique.append(req)
            
            self.queues[priority] = unique

# Qyrox V4.6 - Build 422b74db
