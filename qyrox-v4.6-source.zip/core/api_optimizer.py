"""
API Optimizer - Optimasi penggunaan API agar tidak cepat limit
"""
import time
from datetime import datetime, timedelta
from collections import deque
import logging

logger = logging.getLogger(__name__)

class APIOptimizer:
    """Optimizer untuk mengelola API usage dan rate limiting"""
    
    def __init__(self):
        # Rate limiting
        self.request_history = deque(maxlen=100)
        self.rate_limit_per_minute = 60  # Max requests per minute
        self.rate_limit_per_hour = 500   # Max requests per hour
        
        # Token usage tracking
        self.token_usage = {
            'total': 0,
            'today': 0,
            'this_hour': 0
        }
        self.last_reset = datetime.now()
        
        # Response compression
        self.max_response_length = 1000  # Chars
        
        # Smart caching
        self.cache_hit_rate = 0.0
        self.total_requests = 0
        self.cached_requests = 0
    
    def can_make_request(self) -> bool:
        """Check if we can make a request without hitting rate limit"""
        now = time.time()
        
        # Remove old requests (older than 1 hour)
        while self.request_history and now - self.request_history[0] > 3600:
            self.request_history.popleft()
        
        # Check per-minute limit
        recent_requests = sum(1 for t in self.request_history if now - t < 60)
        if recent_requests >= self.rate_limit_per_minute:
            logger.warning("⚠️ Rate limit per minute reached")
            return False
        
        # Check per-hour limit
        if len(self.request_history) >= self.rate_limit_per_hour:
            logger.warning("⚠️ Rate limit per hour reached")
            return False
        
        return True
    
    def record_request(self, tokens_used: int = 0):
        """Record a request"""
        now = time.time()
        self.request_history.append(now)
        
        # Update token usage
        self.token_usage['total'] += tokens_used
        self.token_usage['today'] += tokens_used
        self.token_usage['this_hour'] += tokens_used
        
        # Reset counters if needed
        self._reset_counters()
        
        self.total_requests += 1
    
    def record_cache_hit(self):
        """Record a cache hit"""
        self.cached_requests += 1
        self.cache_hit_rate = self.cached_requests / max(self.total_requests, 1)
        logger.info(f"💾 Cache hit rate: {self.cache_hit_rate:.1%}")
    
    def _reset_counters(self):
        """Reset counters based on time"""
        now = datetime.now()
        
        # Reset hourly counter
        if now.hour != self.last_reset.hour:
            self.token_usage['this_hour'] = 0
        
        # Reset daily counter
        if now.date() != self.last_reset.date():
            self.token_usage['today'] = 0
        
        self.last_reset = now
    
    def get_wait_time(self) -> float:
        """Get recommended wait time before next request"""
        if not self.request_history:
            return 0.0
        
        now = time.time()
        recent_requests = [t for t in self.request_history if now - t < 60]
        
        if len(recent_requests) >= self.rate_limit_per_minute:
            # Wait until oldest request is > 1 minute old
            oldest = min(recent_requests)
            wait_time = 60 - (now - oldest)
            return max(0, wait_time)
        
        return 0.0
    
    def optimize_prompt(self, prompt: str) -> str:
        """Optimize prompt to reduce tokens"""
        # Remove excessive whitespace
        prompt = ' '.join(prompt.split())
        
        # Truncate if too long
        if len(prompt) > 4000:
            prompt = prompt[:4000] + "..."
        
        return prompt
    
    def compress_response(self, response: str) -> str:
        """Compress response to save tokens"""
        if len(response) <= self.max_response_length:
            return response
        
        # Truncate with summary
        return response[:self.max_response_length] + "\n\n[Response truncated for optimization]"
    
    def get_stats(self) -> dict:
        """Get usage statistics"""
        return {
            'total_requests': self.total_requests,
            'cached_requests': self.cached_requests,
            'cache_hit_rate': f"{self.cache_hit_rate:.1%}",
            'tokens_today': self.token_usage['today'],
            'tokens_this_hour': self.token_usage['this_hour'],
            'tokens_total': self.token_usage['total'],
            'requests_last_hour': len(self.request_history)
        }
    
    def suggest_optimization(self) -> str:
        """Suggest optimization strategies"""
        suggestions = []
        
        if self.cache_hit_rate < 0.5:
            suggestions.append("💡 Cache hit rate rendah. Pertimbangkan semantic cache threshold lebih tinggi.")
        
        if len(self.request_history) > self.rate_limit_per_hour * 0.8:
            suggestions.append("⚠️ Mendekati rate limit. Gunakan cache lebih agresif.")
        
        if self.token_usage['this_hour'] > 10000:
            suggestions.append("💰 Token usage tinggi. Pertimbangkan response compression.")
        
        if not suggestions:
            suggestions.append("✅ API usage optimal!")
        
        return "\n".join(suggestions)

# Qyrox V4.6 - Build 48a19bb4
