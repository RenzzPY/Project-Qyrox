import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum
import json
from datetime import datetime
from pathlib import Path

class AgentRole(Enum):
    """Specialized agent roles"""
    RESEARCHER = "researcher"  # Web search, data gathering
    CODER = "coder"           # Code generation, debugging
    ANALYST = "analyst"       # Data analysis, insights
    PLANNER = "planner"       # Task planning, orchestration
    REVIEWER = "reviewer"     # Quality control, validation

@dataclass
class AgentTask:
    """Task for an agent"""
    task_id: str
    role: AgentRole
    description: str
    priority: int  # 1-5, 5 is highest
    dependencies: List[str]  # Task IDs this depends on
    context: Dict[str, Any]
    status: str = "pending"  # pending, running, completed, failed
    result: Optional[Any] = None
    error: Optional[str] = None
    created_at: str = None
    completed_at: Optional[str] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()

@dataclass
class AgentMessage:
    """Message between agents"""
    from_agent: AgentRole
    to_agent: AgentRole
    message_type: str  # request, response, notification
    content: Dict[str, Any]
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()

class SpecializedAgent:
    """Base class for specialized agents"""
    
    def __init__(self, role: AgentRole, llm_manager):
        self.role = role
        self.llm_manager = llm_manager
        self.capabilities = self._define_capabilities()
        self.task_history: List[AgentTask] = []
        
    def _define_capabilities(self) -> List[str]:
        """Define what this agent can do"""
        capabilities_map = {
            AgentRole.RESEARCHER: [
                "web_search", "data_gathering", "fact_checking",
                "source_validation", "information_synthesis"
            ],
            AgentRole.CODER: [
                "code_generation", "code_review", "debugging",
                "refactoring", "testing", "documentation"
            ],
            AgentRole.ANALYST: [
                "data_analysis", "pattern_recognition", "insights",
                "visualization", "reporting", "predictions"
            ],
            AgentRole.PLANNER: [
                "task_decomposition", "scheduling", "resource_allocation",
                "dependency_management", "progress_tracking"
            ],
            AgentRole.REVIEWER: [
                "quality_check", "validation", "error_detection",
                "improvement_suggestions", "compliance_check"
            ]
        }
        return capabilities_map.get(self.role, [])
    
    def can_handle(self, task: AgentTask) -> bool:
        """Check if this agent can handle the task"""
        return task.role == self.role
    
    async def execute(self, task: AgentTask) -> AgentTask:
        """Execute a task"""
        task.status = "running"
        
        try:
            # Build specialized prompt based on role
            prompt = self._build_prompt(task)
            
            # Execute with LLM
            result = await self._execute_with_llm(prompt, task)
            
            task.result = result
            task.status = "completed"
            task.completed_at = datetime.now().isoformat()
            
        except Exception as e:
            task.status = "failed"
            task.error = str(e)
            task.completed_at = datetime.now().isoformat()
        
        self.task_history.append(task)
        return task
    
    def _build_prompt(self, task: AgentTask) -> str:
        """Build specialized prompt for this agent role"""
        role_prompts = {
            AgentRole.RESEARCHER: f"""You are a Research Specialist Agent.
Your capabilities: {', '.join(self.capabilities)}

Task: {task.description}
Context: {json.dumps(task.context, indent=2)}

Provide comprehensive research results with sources and validation.""",
            
            AgentRole.CODER: f"""You are a Code Specialist Agent.
Your capabilities: {', '.join(self.capabilities)}

Task: {task.description}
Context: {json.dumps(task.context, indent=2)}

Provide clean, tested, well-documented code with explanations.""",
            
            AgentRole.ANALYST: f"""You are a Data Analysis Specialist Agent.
Your capabilities: {', '.join(self.capabilities)}

Task: {task.description}
Context: {json.dumps(task.context, indent=2)}

Provide detailed analysis with insights, patterns, and actionable recommendations.""",
            
            AgentRole.PLANNER: f"""You are a Planning Specialist Agent.
Your capabilities: {', '.join(self.capabilities)}

Task: {task.description}
Context: {json.dumps(task.context, indent=2)}

Create a detailed execution plan with steps, dependencies, and timeline.""",
            
            AgentRole.REVIEWER: f"""You are a Quality Review Specialist Agent.
Your capabilities: {', '.join(self.capabilities)}

Task: {task.description}
Context: {json.dumps(task.context, indent=2)}

Provide thorough review with quality score, issues found, and improvement suggestions."""
        }
        
        return role_prompts.get(self.role, f"Task: {task.description}")
    
    async def _execute_with_llm(self, prompt: str, task: AgentTask) -> Dict[str, Any]:
        """Execute task with LLM"""
        # This will be implemented with actual LLM call
        # For now, return structured result
        response = self.llm_manager.invoke(prompt)
        
        return {
            "agent": self.role.value,
            "task_id": task.task_id,
            "output": response,
            "confidence": 0.9,
            "timestamp": datetime.now().isoformat()
        }

class MultiAgentSystem:
    """Orchestrates multiple specialized agents"""
    
    def __init__(self, llm_manager, data_dir: Path):
        self.llm_manager = llm_manager
        self.data_dir = data_dir
        self.agents: Dict[AgentRole, SpecializedAgent] = {}
        self.task_queue: List[AgentTask] = []
        self.completed_tasks: List[AgentTask] = []
        self.messages: List[AgentMessage] = []
        
        # Initialize all specialized agents
        self._initialize_agents()
    
    def _initialize_agents(self):
        """Initialize all specialized agents"""
        for role in AgentRole:
            self.agents[role] = SpecializedAgent(role, self.llm_manager)
    
    def create_task(self, role: AgentRole, description: str, 
                   priority: int = 3, dependencies: List[str] = None,
                   context: Dict[str, Any] = None) -> AgentTask:
        """Create a new task for an agent"""
        task = AgentTask(
            task_id=f"task_{len(self.task_queue)}_{datetime.now().timestamp()}",
            role=role,
            description=description,
            priority=priority,
            dependencies=dependencies or [],
            context=context or {}
        )
        self.task_queue.append(task)
        return task
    
    async def execute_task(self, task: AgentTask) -> AgentTask:
        """Execute a single task"""
        # Check dependencies
        if not self._check_dependencies(task):
            task.status = "waiting"
            return task
        
        # Find appropriate agent
        agent = self.agents.get(task.role)
        if not agent:
            task.status = "failed"
            task.error = f"No agent available for role: {task.role}"
            return task
        
        # Execute
        result = await agent.execute(task)
        self.completed_tasks.append(result)
        
        return result
    
    def _check_dependencies(self, task: AgentTask) -> bool:
        """Check if all dependencies are completed"""
        if not task.dependencies:
            return True
        
        completed_ids = {t.task_id for t in self.completed_tasks if t.status == "completed"}
        return all(dep_id in completed_ids for dep_id in task.dependencies)
    
    async def execute_parallel(self, tasks: List[AgentTask]) -> List[AgentTask]:
        """Execute multiple tasks in parallel"""
        # Group by dependencies
        independent_tasks = [t for t in tasks if not t.dependencies]
        dependent_tasks = [t for t in tasks if t.dependencies]
        
        # Execute independent tasks in parallel
        results = []
        if independent_tasks:
            parallel_results = await asyncio.gather(
                *[self.execute_task(t) for t in independent_tasks],
                return_exceptions=True
            )
            results.extend([r for r in parallel_results if isinstance(r, AgentTask)])
        
        # Execute dependent tasks after dependencies complete
        for task in dependent_tasks:
            if self._check_dependencies(task):
                result = await self.execute_task(task)
                results.append(result)
        
        return results
    
    def send_message(self, from_agent: AgentRole, to_agent: AgentRole,
                    message_type: str, content: Dict[str, Any]):
        """Send message between agents"""
        message = AgentMessage(
            from_agent=from_agent,
            to_agent=to_agent,
            message_type=message_type,
            content=content
        )
        self.messages.append(message)
    
    def get_agent_stats(self) -> Dict[str, Any]:
        """Get statistics for all agents"""
        stats = {}
        for role, agent in self.agents.items():
            completed = len([t for t in agent.task_history if t.status == "completed"])
            failed = len([t for t in agent.task_history if t.status == "failed"])
            
            stats[role.value] = {
                "total_tasks": len(agent.task_history),
                "completed": completed,
                "failed": failed,
                "success_rate": completed / len(agent.task_history) if agent.task_history else 0,
                "capabilities": agent.capabilities
            }
        
        return stats
    
    def get_task_status(self, task_id: str) -> Optional[AgentTask]:
        """Get status of a specific task"""
        for task in self.task_queue + self.completed_tasks:
            if task.task_id == task_id:
                return task
        return None
    
    async def collaborate(self, goal: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Multi-agent collaboration to achieve a goal"""
        # Step 1: Planner creates execution plan
        plan_task = self.create_task(
            role=AgentRole.PLANNER,
            description=f"Create execution plan for: {goal}",
            priority=5,
            context=context or {}
        )
        plan_result = await self.execute_task(plan_task)
        
        if plan_result.status != "completed":
            return {"error": "Planning failed", "details": plan_result.error}
        
        # Step 2: Execute plan with appropriate agents
        # (This would parse the plan and create tasks)
        # For now, return the plan
        
        return {
            "goal": goal,
            "plan": plan_result.result,
            "status": "planned",
            "next_steps": "Execute individual tasks"
        }

# Qyrox V4.6 - Build aafacfc0
