import os
import json
from pathlib import Path

BASE_DIR = Path(__file__).parent

class Config:
    @staticmethod
    def load_user_config():
        config_file = BASE_DIR / "user_config.json"
        if config_file.exists():
            with open(config_file, 'r') as f:
                return json.load(f)
        return {}
    
    @staticmethod
    def load_api_keys():
        api_file = BASE_DIR / "api_key.txt"
        keys = {}
        if api_file.exists():
            with open(api_file, 'r') as f:
                content = f.read()
                for line in content.split('\n'):
                    if ':' in line:
                        key, value = line.split(':', 1)
                        key = key.strip().strip('"')
                        value = value.strip().strip('",')
                        keys[key] = value
        return keys
    
    user_config = load_user_config.__func__()
    KEYS = load_api_keys.__func__()
    
    GROQ_API_KEY = KEYS.get("groq", "")
    GOOGLE_API_KEY = KEYS.get("google", "")
    OPENAI_API_KEY = KEYS.get("openai", "")
    OPENROUTER_API_KEY = KEYS.get("openrouter", "")
    
    AGENT_NAME = user_config.get("agent_name", "Qyrox V4.6")
    AGENT_MODE = "autonomous"
    AUTONOMOUS_ENABLED = user_config.get("autonomous_enabled", False)
    
    MULTI_AGENT_ENABLED = user_config.get("multi_agent_enabled", True)
    ADVANCED_CONTEXT_ENABLED = user_config.get("context_management_enabled", True)
    REQUEST_BATCHING_ENABLED = user_config.get("batching_enabled", True)
    CONTEXT_MAX_TOKENS = 4000
    BATCH_SIZE = 5
    BATCH_TIMEOUT = 2.0
    
    AUTONOMOUS_SAFETY_MODE = user_config.get("safety_mode", "safe")
    AUTONOMOUS_REQUIRE_APPROVAL = True
    AUTONOMOUS_MAX_ACTIONS_PER_HOUR = 10
    AUTONOMOUS_ACTION_COOLDOWN = 300
    
    rate_limits = user_config.get("rate_limits", {})
    RATE_LIMITS = {
        "requests_per_minute": rate_limits.get("requests_per_minute", 50),
        "requests_per_hour": rate_limits.get("requests_per_hour", 1000),
        "requests_per_day": rate_limits.get("requests_per_day", 10000),
        "tokens_per_minute": rate_limits.get("tokens_per_minute", 90000),
        "tokens_per_day": rate_limits.get("tokens_per_day", 2000000)
    }
    
    THROTTLE_THRESHOLDS = {0: 50, 1: 60, 2: 70, 3: 80, 4: 90, 5: 100}
    
    AUTO_SLEEP_ON_LIMIT = True
    AUTO_SLEEP_THRESHOLD = 85
    
    PRIMARY_MODEL = user_config.get("primary_model", "llama-3.1-8b-instant")
    FALLBACK_MODEL = "gemini-1.5-flash"
    
    CACHE_ENABLED = True
    SEMANTIC_CACHE_THRESHOLD = 0.85
    CACHE_DIR = BASE_DIR / "data" / "cache"
    
    SIGNAL_CHECK_INTERVAL = 300
    PROACTIVE_CHECK_INTERVAL = 900
    
    DATA_DIR = BASE_DIR / "data"
    MEMORY_DIR = DATA_DIR / "memory"
    LOGS_DIR = DATA_DIR / "logs"
    TOOLS_DIR = BASE_DIR / "tools"
    
    @staticmethod
    def init_dirs():
        for dir_path in [Config.DATA_DIR, Config.MEMORY_DIR, 
                         Config.LOGS_DIR, Config.CACHE_DIR, Config.TOOLS_DIR]:
            dir_path.mkdir(parents=True, exist_ok=True)

# Qyrox V4.6 - Build 11a95ec1
