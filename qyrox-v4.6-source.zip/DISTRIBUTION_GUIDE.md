# Qyrox V4.6 - Distribution Guide

## Cara Melindungi Code di GitHub

### 1. License Protection

File `LICENSE` sudah dibuat dengan:
- MIT License dengan Attribution Requirement
- Larangan penggunaan komersial tanpa izin
- Watermarking notice
- Anti-plagiarism clause

### 2. Build Protected Distribution

Jalankan build script untuk membuat distribusi yang dilindungi:

```bash
python build_protected.py
```

Ini akan membuat:
- `qyrox-v4.6-source.zip` - Source code dengan watermark
- `qyrox-v4.6-bytecode.zip` - Bytecode (.pyc) yang sulit dimodifikasi
- `install.py` - Installer script untuk one-line install
- `DISTRIBUTION_README.md` - Panduan untuk user

### 3. Upload ke GitHub

#### A. Upload Source Code (Public Repository)

```bash
# Initialize git (jika belum)
git init
git add .
git commit -m "Initial commit - Qyrox V4.6"

# Create GitHub repository dan push
git remote add origin https://github.com/[your-username]/qyrox.git
git branch -M main
git push -u origin main
```

#### B. Create Release dengan Protected Files

1. Jalankan build:
   ```bash
   python build_protected.py
   ```

2. Di GitHub:
   - Go to "Releases" → "Create a new release"
   - Tag: `v4.6.0`
   - Title: `Qyrox V4.6 - Production Ready`
   - Upload files dari folder `dist/`:
     - `qyrox-v4.6-source.zip`
     - `qyrox-v4.6-bytecode.zip`
     - `install.py`

3. Update `install.py` dengan URL yang benar:
   ```python
   DOWNLOAD_URL = "https://github.com/[your-username]/qyrox/releases/download/v4.6.0/qyrox-v4.6-source.zip"
   ```

### 4. Installation Methods untuk User

#### Method 1: One-Line Install (Seperti OpenClaw)

```bash
python -c "$(curl -fsSL https://raw.githubusercontent.com/[your-username]/qyrox/main/install.py)"
```

atau di Windows PowerShell:

```powershell
(Invoke-WebRequest -Uri "https://raw.githubusercontent.com/[your-username]/qyrox/main/install.py").Content | python
```

#### Method 2: Manual Install

```bash
# Download release
wget https://github.com/[your-username]/qyrox/releases/download/v4.6.0/qyrox-v4.6-source.zip

# Extract
unzip qyrox-v4.6-source.zip
cd qyrox-v4.6-source

# Install
pip install -r requirements.txt
python setup.py
python main.py
```

### 5. Proteksi yang Diterapkan

#### A. License Protection
- MIT License dengan attribution requirement
- Commercial use requires permission
- Trademark protection untuk nama "Qyrox"

#### B. Watermarking
- Setiap file Python diberi watermark unik
- Build ID untuk tracking
- Timestamp untuk verifikasi

#### C. Bytecode Distribution
- File .pyc sulit dibaca dan dimodifikasi
- Tidak ada source code yang mudah diedit
- Tetap bisa dijalankan normal

#### D. GitHub Protection
- `.gitignore` mencegah upload file sensitif
- API keys tidak pernah di-commit
- User config tidak di-track

### 6. Perbandingan dengan OpenClaw

```
Feature                 Qyrox V4.6         OpenClaw
Installation            One-line install   One-line install
Source Protection       Watermark + .pyc   Open source
License                 MIT + Attribution  Apache 2.0
Modification Tracking   Yes (watermark)    No
Commercial Use          Requires permission Free
Code Quality            50 files           100+ files
```

### 7. Enforcement

Jika ada yang copy/plagiarize:

1. **Watermark Detection**
   - Setiap file punya unique build ID
   - Bisa trace kembali ke original

2. **GitHub DMCA**
   - File DMCA takedown jika ada plagiarism
   - GitHub akan remove repository yang melanggar

3. **License Violation**
   - MIT License requires attribution
   - Bisa legal action jika tidak comply

4. **Trademark**
   - Nama "Qyrox" adalah trademark
   - Tidak boleh digunakan tanpa izin

### 8. Best Practices

#### Untuk GitHub Public Repo:

1. **Jangan upload:**
   - `api_key.txt`
   - `user_config.json`
   - `data/memory/`
   - `data/cache/`
   - `__pycache__/`

2. **Upload:**
   - Source code dengan watermark
   - Documentation
   - LICENSE file
   - `.gitignore` yang proper

3. **Releases:**
   - Upload protected distributions
   - Bytecode version untuk extra protection
   - Installer script

#### Untuk Private Distribution:

Jika mau lebih protected, bisa:

1. **Private Repository**
   - GitHub private repo (gratis untuk personal)
   - Invite-only access

2. **PyPI Package**
   - Upload ke PyPI sebagai package
   - Install via `pip install qyrox`
   - Lebih professional

3. **Executable**
   - Compile dengan PyInstaller
   - Distribusi sebagai .exe (Windows) atau binary (Linux/Mac)
   - Paling sulit di-reverse engineer

### 9. Membuat Executable (Optional)

Untuk proteksi maksimal:

```bash
# Install PyInstaller
pip install pyinstaller

# Build executable
pyinstaller --onefile --name qyrox main.py

# Hasil di folder dist/
# qyrox.exe (Windows) atau qyrox (Linux/Mac)
```

User tinggal download dan run executable, tidak perlu Python.

### 10. Recommended Strategy

Untuk Qyrox V4.6, saya rekomendasikan:

1. **Public GitHub Repo** dengan:
   - Source code (watermarked)
   - Full documentation
   - MIT License dengan attribution
   - Proper .gitignore

2. **GitHub Releases** dengan:
   - Source distribution (watermarked)
   - Bytecode distribution (.pyc)
   - Installer script

3. **Installation Methods**:
   - One-line install (primary)
   - Manual install (alternative)
   - Bytecode version (for extra protection)

Ini balance antara:
- ✓ Open source (good for community)
- ✓ Protected (watermark + license)
- ✓ Professional (proper distribution)
- ✓ Easy to install (one-line command)

## Quick Start untuk Upload

```bash
# 1. Build protected distributions
python build_protected.py

# 2. Initialize git
git init
git add .
git commit -m "Qyrox V4.6 - Production Ready"

# 3. Create GitHub repo dan push
git remote add origin https://github.com/[your-username]/qyrox.git
git push -u origin main

# 4. Create release di GitHub
# Upload files dari dist/ folder

# 5. Update install.py dengan correct URL

# 6. Share installation command:
# python -c "$(curl -fsSL https://raw.githubusercontent.com/[your-username]/qyrox/main/install.py)"
```

---

Qyrox V4.6 - Protected Distribution System
