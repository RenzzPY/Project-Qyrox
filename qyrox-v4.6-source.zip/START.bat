@echo off
chcp 65001 >nul
cls

echo ============================================================
echo   🤖 QYROX V4.1 - ULTIMATE AUTONOMOUS AI ASSISTANT
echo ============================================================
echo.
echo   Version: V4.1
echo   Rating: 8.75/10 ⭐
echo   Status: Production-Ready
echo.
echo ============================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ ERROR: Python not found!
    echo.
    echo Please install Python 3.8+ from:
    echo https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)

REM Check if dependencies are installed
python -c "import langchain" >nul 2>&1
if errorlevel 1 (
    echo ⚠️  Dependencies not installed!
    echo.
    echo Installing dependencies...
    pip install -r requirements.txt
    echo.
    if errorlevel 1 (
        echo ❌ Failed to install dependencies!
        pause
        exit /b 1
    )
)

REM Check for API keys
if not exist "api_key.txt" (
    if not defined GROQ_API_KEY (
        echo ⚠️  WARNING: No API keys found!
        echo.
        echo Please setup API keys:
        echo   1. Create api_key.txt, OR
        echo   2. Set environment variables:
        echo      set GROQ_API_KEY=your_key
        echo      set GOOGLE_API_KEY=your_key
        echo.
        echo See DOCUMENTATION.md for details.
        echo.
        pause
    )
)

echo 🚀 Starting Qyrox...
echo.

REM Run the agent
python main.py

if errorlevel 1 (
    echo.
    echo ❌ Error occurred!
    echo Check data/logs/agent.log for details.
    echo.
    pause
)
